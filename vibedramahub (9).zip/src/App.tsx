import React, { useState, useEffect, useMemo, lazy, Suspense, useRef } from 'react';
import { 
  Film, Users, Play, Heart, FolderPlus, Trash2, History, Bell, User, Plus, 
  Search, LogOut, Lock, ShieldAlert, Scale, Copyright, Globe, FileText, 
  Copy, Check, CheckCircle2, Settings, Edit, Eye, Clock, X, Info, Star, SkipForward, HelpCircle, Loader2, Minus,
  ChevronLeft, ChevronRight, CloudUpload, RotateCw, FolderOpen, Mail, Sparkles, Wifi, WifiOff, Download, ThumbsUp, Menu,
  Calendar, Headphones, Languages, Share, MessageSquare
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { CinematicIntro } from './components/CinematicIntro';
import { FloatingProfileButton } from './components/FloatingProfileButton';

// Lazy-loaded components
const FirebaseStorageManager = lazy(() => import('./components/FirebaseStorageManager').then(m => ({ default: m.FirebaseStorageManager })));

// Firebase Integrations
import { db, auth, storage, seedDatabaseIfEmpty, handleFirestoreError, OperationType } from './lib/firebase';
import { 
  collection, 
  onSnapshot, 
  doc, 
  setDoc, 
  addDoc, 
  deleteDoc, 
  query, 
  where, 
  getDocs,
  getDoc
} from 'firebase/firestore';
import { 
  signInWithEmailAndPassword, 
  signOut, 
  onAuthStateChanged,
  createUserWithEmailAndPassword,
  sendPasswordResetEmail,
  GoogleAuthProvider,
  signInWithPopup,
  signInWithCredential,
  setPersistence,
  browserLocalPersistence
} from 'firebase/auth';
import { 
  ref, 
  uploadBytesResumable, 
  getDownloadURL 
} from 'firebase/storage';

// --------------------------------------------------------
// Types & Interfaces
// --------------------------------------------------------
interface Drama {
  id: number;
  title: string;
  description: string;
  poster_url: string;
  banner_url: string;
  trailer_url: string;
  genre: string;
  country: string;
  release_year: number;
  status: string;
  cast: string;
  download_url?: string;
  createdAt?: string;
}

interface Episode {
  id: number;
  drama_id: number;
  episode_number: number;
  title: string;
  streamtape_url: string;
  subtitle_url?: string;
  download_url?: string;
  createdAt?: string;
}

interface Playlist {
  id: number;
  name: string;
  isPrivate: boolean;
  dramaIds: number[];
}

interface WatchHistoryItem {
  dramaId: number;
  episodeId: number;
  progressSeconds: number;
  completed: boolean;
  updatedAt: string;
}

interface Review {
  dramaId: number;
  username: string;
  fullname: string;
  text: string;
  rating: number;
  createdAt: string;
}

interface PlatformUser {
  id: string | number;
  fullname: string;
  username: string;
  email: string;
  status: 'active' | 'suspended' | 'banned';
  createdAt: string;
  password?: string;
  role?: string;
  favorites?: number[];
  playlists?: Playlist[];
  watchHistory?: WatchHistoryItem[];
  photoURL?: string;
  bio?: string;
}

interface Rating {
  id?: string;
  dramaId: number;
  userId: string;
  rating: number;
  createdAt: string;
}

interface PlatformNotification {
  id: string;
  title: string;
  description: string;
  createdAt: string;
  read?: boolean;
}

// --------------------------------------------------------
// Initial Seed Data
// --------------------------------------------------------
const initialDramas: Drama[] = [
  {
    id: 1,
    title: 'Hidden Love',
    description: 'A beautiful story about a young girl who falls in love with her older brother\'s roommate, which develops into an endearing romance over several years of growth and support.',
    poster_url: 'https://images.unsplash.com/photo-1522075469751-3a6694fb2f61?q=80&w=600',
    banner_url: 'https://images.unsplash.com/photo-1517604931442-7e0c8ed2963c?q=80&w=1200',
    trailer_url: 'https://www.youtube.com/embed/9Z3f0vU_y2U',
    genre: 'Romance, Comedy',
    country: 'China',
    release_year: 2023,
    status: 'Completed',
    cast: 'Zhao Lusi, Chen Zheyuan, Victor Ma'
  },
  {
    id: 2,
    title: 'The King: Eternal Monarch',
    description: 'A modern-day Korean emperor passes through a mysterious portal and into a parallel world, where he encounters a feisty police detective to solve a historical conspiracy.',
    poster_url: 'https://images.unsplash.com/photo-1536440136628-849c177e76a1?q=80&w=600',
    banner_url: 'https://images.unsplash.com/photo-1535016120720-40c646be5580?q=80&w=1200',
    trailer_url: 'https://www.youtube.com/embed/g8fS3kpxhio',
    genre: 'Mystery, Romance, Action',
    country: 'South Korea',
    release_year: 2020,
    status: 'Completed',
    cast: 'Lee Min-ho, Kim Go-eun, Woo Do-hwan'
  },
  {
    id: 3,
    title: 'Sweet Home',
    description: 'As humans turn into savage monsters and wreak terror, one troubled teenager and his neighbors fight to survive and to hold on to their humanity.',
    poster_url: 'https://images.unsplash.com/photo-1618336753974-aae8e04506aa?q=80&w=600',
    banner_url: 'https://images.unsplash.com/photo-1509198397868-475647b2a1e5?q=80&w=1200',
    trailer_url: 'https://www.youtube.com/embed/4O6S839N4p4',
    genre: 'Action, Mystery',
    country: 'South Korea',
    release_year: 2020,
    status: 'Ongoing',
    cast: 'Song Kang, Lee Jin-wook, Lee Si-young'
  }
];

const initialEpisodes: Episode[] = [
  { id: 101, drama_id: 1, episode_number: 1, title: 'First Meeting', streamtape_url: 'https://streamtape.com/e/abc123first_ep' },
  { id: 102, drama_id: 1, episode_number: 2, title: 'The Growing Friendship', streamtape_url: 'https://streamtape.com/e/abc123second_ep' },
  { id: 103, drama_id: 1, episode_number: 3, title: 'The Silent Supporter', streamtape_url: 'https://streamtape.com/e/abc123third_ep' },
  { id: 201, drama_id: 2, episode_number: 1, title: 'A Parallel Universe', streamtape_url: 'https://streamtape.com/e/theking_ep1' },
  { id: 202, drama_id: 2, episode_number: 2, title: 'Meeting the Detective', streamtape_url: 'https://streamtape.com/e/theking_ep2' },
  { id: 301, drama_id: 3, episode_number: 1, title: 'The Green Home Monster', streamtape_url: 'https://streamtape.com/e/sweethome_ep1' }
];

const initialReviews: Review[] = [
  { dramaId: 1, username: 'klove99', fullname: 'Sarah Lin', text: 'Absolutely adorable drama! The chemistry between the leads is incredible. Must watch for romance fans!', rating: 10, createdAt: '2026-07-08' },
  { dramaId: 2, username: 'mysteryguy', fullname: 'Alex Carter', text: 'Intriguing plot and parallel worlds. Lee Min-ho delivers an amazing performance.', rating: 9, createdAt: '2026-07-09' }
];

const initialUsers: PlatformUser[] = [
  { id: 1, fullname: 'Rahul (Admin)', username: 'Rahul', email: 'rahul@vibedramahub.com', status: 'active', createdAt: '2026-01-01' },
  { id: 2, fullname: 'John Doe', username: 'johndoe', email: 'john@example.com', status: 'active', createdAt: '2026-06-15' },
  { id: 3, fullname: 'Jane Smith', username: 'janesmith', email: 'jane@example.com', status: 'suspended', createdAt: '2026-06-20' },
  { id: 4, fullname: 'Troublemaker', username: 'banneduser', email: 'spam@spam.com', status: 'banned', createdAt: '2026-07-01' }
];

const getBunnyPreviewUrl = (videoUrl: string | undefined, fallbackUrl: string): string => {
  if (!videoUrl) return fallbackUrl;
  const url = videoUrl.trim();
  
  // 1. iframe.mediadelivery.net (embed or play)
  const mediaDeliveryRegex = /iframe\.mediadelivery\.net\/(embed|play)\/([a-zA-Z0-9\-]+)\/([a-zA-Z0-9\-]+)/i;
  const match = url.match(mediaDeliveryRegex);
  if (match) {
    const libraryId = match[2];
    const videoId = match[3];
    return `https://iframe.mediadelivery.net/play/${libraryId}/${videoId}/preview.webp`;
  }
  
  // 2. Direct Bunny CDN hostnames
  const bCdnRegex = /(vz-[a-zA-Z0-9\-]+\.b-cdn\.net)\/([a-zA-Z0-9\-]+)/i;
  const bCdnMatch = url.match(bCdnRegex);
  if (bCdnMatch) {
    const host = bCdnMatch[1];
    const videoId = bCdnMatch[2];
    return `https://${host}/${videoId}/preview.webp`;
  }

  // Fallback to the drama's poster URL
  return fallbackUrl;
};

// --------------------------------------------------------
// Bunny Stream Multi-Audio Helpers & Mappings
// --------------------------------------------------------
const languageMap: Record<string, string> = {
  'hi': 'Hindi',
  'en': 'English',
  'ko': 'Korean',
  'zh': 'Mandarin',
  'ja': 'Japanese',
  'th': 'Thai',
  'es': 'Spanish',
  'fr': 'French',
  'vi': 'Vietnamese',
  'id': 'Indonesian',
  'ms': 'Malay',
  'ta': 'Tamil',
  'te': 'Telugu',
  'bn': 'Bengali',
  'pt': 'Portuguese',
  'ru': 'Russian',
  'ar': 'Arabic',
  'tr': 'Turkish',
  'de': 'German',
  'it': 'Italian'
};

const getFriendlyLanguageName = (code: string, originalName?: string): string => {
  const normalized = code.toLowerCase().trim();
  if (languageMap[normalized]) {
    return languageMap[normalized];
  }
  if (originalName) {
    return originalName;
  }
  return code.toUpperCase();
};

const getEmbedUrlWithLang = (url: string, langCode: string | null, progressSeconds?: number): string => {
  if (!url) return url;
  try {
    const hasProtocol = url.startsWith('http://') || url.startsWith('https://') || url.startsWith('//');
    const parseUrl = hasProtocol ? (url.startsWith('//') ? 'https:' + url : url) : 'https://' + url;
    const urlObj = new URL(parseUrl);
    if (langCode && langCode !== 'original') {
      urlObj.searchParams.set('lang', langCode);
      urlObj.searchParams.set('defaultAudioLanguage', langCode);
      urlObj.searchParams.set('audio', langCode);
    }
    if (progressSeconds && progressSeconds > 0) {
      urlObj.searchParams.set('t', progressSeconds.toString());
      urlObj.searchParams.set('time', progressSeconds.toString());
    }
    
    let result = urlObj.toString();
    if (url.startsWith('//')) {
      result = result.replace(/^https:/, '');
    } else if (!hasProtocol) {
      result = result.replace(/^https:\/\//, '');
    }
    return result;
  } catch (e) {
    let result = url;
    const connector = result.includes('?') ? '&' : '?';
    if (langCode && langCode !== 'original') {
      result += `${connector}lang=${langCode}&defaultAudioLanguage=${langCode}&audio=${langCode}`;
    }
    if (progressSeconds && progressSeconds > 0) {
      const conn = result.includes('?') ? '&' : '?';
      result += `${conn}t=${progressSeconds}&time=${progressSeconds}`;
    }
    return result;
  }
};

const getPathForState = (tab: string, dramaId: number | null, episodeId: number | null): string => {
  if (tab === 'admin_dash' || tab === 'admin_login') {
    return '/admin';
  } else if (tab === 'profile') {
    return '/profile';
  } else if (tab === 'playlists') {
    return '/playlists';
  } else if (tab === 'mylist') {
    return '/mylist';
  } else if (tab === 'history') {
    return '/history';
  } else if (tab === 'copyright') {
    return '/copyright';
  } else if (tab === 'legal') {
    return '/legal';
  } else if (tab === 'brand') {
    return '/brand';
  } else if (tab === 'support') {
    return '/support';
  } else if (tab === 'contact') {
    return '/contact';
  } else if (tab === 'player' && episodeId) {
    let p = `/episode/${episodeId}`;
    if (dramaId) p += `?dramaId=${dramaId}`;
    return p;
  } else if (dramaId) {
    return `/drama/${dramaId}`;
  }
  return '/';
};

const safeLocalStorage = {
  getItem: (key: string): string | null => {
    try {
      return localStorage.getItem(key);
    } catch (e) {
      console.warn("localStorage is not available:", e);
      return null;
    }
  },
  setItem: (key: string, value: string): void => {
    try {
      localStorage.setItem(key, value);
    } catch (e) {
      console.warn("localStorage setItem failed:", e);
    }
  },
  removeItem: (key: string): void => {
    try {
      localStorage.removeItem(key);
    } catch (e) {
      console.warn("localStorage removeItem failed:", e);
    }
  }
};

const safeSessionStorage = {
  getItem: (key: string): string | null => {
    try {
      return sessionStorage.getItem(key);
    } catch (e) {
      console.warn("sessionStorage is not available:", e);
      return null;
    }
  },
  setItem: (key: string, value: string): void => {
    try {
      sessionStorage.setItem(key, value);
    } catch (e) {
      console.warn("sessionStorage setItem failed:", e);
    }
  },
  removeItem: (key: string): void => {
    try {
      sessionStorage.removeItem(key);
    } catch (e) {
      console.warn("sessionStorage removeItem failed:", e);
    }
  }
};

export default function App() {
  // --------------------------------------------------------
  // State Definitions
  // --------------------------------------------------------
  const [currentUser, setCurrentUser] = useState<PlatformUser | null>(() => {
    const saved = safeLocalStorage.getItem('vibe_user');
    return saved ? JSON.parse(saved) : null;
  });

  const [showIntro, setShowIntro] = useState<boolean>(() => {
    return safeSessionStorage.getItem('vibe_intro_watched') !== 'true';
  });

  const [isAdminLogged, setIsAdminLogged] = useState<boolean>(false);

  // Security Lockout Simulator state
  const [failedAttempts, setFailedAttempts] = useState<number>(0);
  const [lockoutTime, setLockoutTime] = useState<number | null>(null);

  // Active Routing/Views
  const [activeTab, setActiveTab] = useState<string>(() => {
    return safeLocalStorage.getItem('vibe_active_tab') || 'home';
  });
  const [authLoading, setAuthLoading] = useState<boolean>(true);
  const [selectedDrama, setSelectedDrama] = useState<Drama | null>(null);
  const [selectedEpisode, setSelectedEpisode] = useState<Episode | null>(null);
  const [navStack, setNavStack] = useState<{
    tab: string;
    dramaId: number | null;
    episodeId: number | null;
  }[]>([]);
  const [videoUnavailable, setVideoUnavailable] = useState<boolean>(false);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [showMobileSearch, setShowMobileSearch] = useState<boolean>(false);
  const [showMobileMenu, setShowMobileMenu] = useState<boolean>(false);
  const [selectedGenre, setSelectedGenre] = useState<string>('');

  const clearSearch = () => {
    setSearchQuery('');
  };

  // Contact Form & Support States
  const [contactName, setContactName] = useState('');
  const [contactEmail, setContactEmail] = useState('');
  const [contactSubject, setContactSubject] = useState('');
  const [contactMessage, setContactMessage] = useState('');
  const [contactSubmitted, setContactSubmitted] = useState(false);

  // App Data State (Real-time Firestore sync)
  const [dramas, setDramas] = useState<Drama[]>([]);
  const [episodes, setEpisodes] = useState<Episode[]>([]);
  const [reviews, setReviews] = useState<Review[]>([]);
  const [registeredUsers, setRegisteredUsers] = useState<PlatformUser[]>([]);

  // Real-time Presence, Views, Likes, Favorites, and Ratings States
  const [onlineCount, setOnlineCount] = useState<number>(1);
  const [allViews, setAllViews] = useState<{dramaId: number, userId: string}[]>([]);
  const [allLikes, setAllLikes] = useState<{dramaId: number, userId: string}[]>([]);
  const [allFavorites, setAllFavorites] = useState<{dramaId: number, userId: string}[]>([]);
  const [ratings, setRatings] = useState<Rating[]>([]);
  const [initialDataLoaded, setInitialDataLoaded] = useState<boolean>(false);
  const [notifications, setNotifications] = useState<PlatformNotification[]>([]);
  
  // Premium Rating System States
  const [ratingSliderVal, setRatingSliderVal] = useState<number>(8.5);
  const [isSavingRating, setIsSavingRating] = useState<boolean>(false);
  const [ratingSaveSuccess, setRatingSaveSuccess] = useState<boolean>(false);
  
  // Profile rating editor states
  const [editingProfileRatingId, setEditingProfileRatingId] = useState<number | null>(null);
  const [tempProfileRatingVal, setTempProfileRatingVal] = useState<number>(8.5);
  const [isSavingProfileRating, setIsSavingProfileRating] = useState<boolean>(false);
  
  // Auth Popup state
  const [showLoginPopup, setShowLoginPopup] = useState<boolean>(false);
  const [pendingAction, setPendingAction] = useState<(() => void) | null>(null);

  // Sync active rating selection with current drama and user state
  useEffect(() => {
    if (selectedDrama) {
      const myRatingObj = ratings.find(r => r.dramaId === selectedDrama.id && r.userId === auth.currentUser?.uid);
      if (myRatingObj) {
        setRatingSliderVal(myRatingObj.rating);
      } else {
        setRatingSliderVal(8.5); // default
      }
      setRatingSaveSuccess(false);
    }
  }, [selectedDrama, ratings, currentUser]);

  // Profile editing state
  const [isEditingProfile, setIsEditingProfile] = useState<boolean>(false);
  const [editFullName, setEditFullName] = useState<string>('');
  const [editUsername, setEditUsername] = useState<string>('');
  const [editBio, setEditBio] = useState<string>('');
  const [editPhotoURL, setEditPhotoURL] = useState<string>('');
  const [profileScrollAnchor, setProfileScrollAnchor] = useState<string | null>(null);

  // Dynamic automatic smooth scroll to profile sections when navigated from Quick Menu
  useEffect(() => {
    if (activeTab === 'profile' && profileScrollAnchor) {
      const timer = setTimeout(() => {
        const el = document.getElementById(profileScrollAnchor);
        if (el) {
          el.scrollIntoView({ behavior: 'smooth', block: 'center' });
        }
        setProfileScrollAnchor(null);
      }, 350);
      return () => clearTimeout(timer);
    }
  }, [activeTab, profileScrollAnchor]);

  // Sync activeTab to localStorage to persist navigation across refreshes
  useEffect(() => {
    if (activeTab && activeTab !== 'player') {
      safeLocalStorage.setItem('vibe_previous_tab', activeTab);
    }
    safeLocalStorage.setItem('vibe_active_tab', activeTab);
  }, [activeTab]);

  // Memoized dynamic real-time Recently Added dramas (newest dramas added)
  const recentlyAddedDramas = useMemo(() => {
    return dramas.slice(0, 4);
  }, [dramas]);

  // The latest drama available in Cloud Firestore to be displayed as the homepage hero banner
  const heroDrama = dramas[0];

  const bannerVariants = {
    enter: (dir: number) => ({
      opacity: 0,
      x: dir > 0 ? 50 : -50
    }),
    center: {
      opacity: 1,
      x: 0,
      transition: {
        duration: 0.5,
        ease: "easeInOut"
      }
    },
    exit: (dir: number) => ({
      opacity: 0,
      x: dir > 0 ? -50 : 50,
      transition: {
        duration: 0.5,
        ease: "easeInOut"
      }
    })
  };

  // Carousel Hero Slider States
  const [currentBannerIndex, setCurrentBannerIndex] = useState<number>(0);
  const [direction, setDirection] = useState<number>(1); // 1 = right/next, -1 = left/prev
  const [isHovering, setIsHovering] = useState<boolean>(false);
  const [touchStartX, setTouchStartX] = useState<number | null>(null);
  const [touchEndX, setTouchEndX] = useState<number | null>(null);

  const nextBanner = () => {
    if (dramas.length <= 1) return;
    setDirection(1);
    setCurrentBannerIndex((prev) => (prev + 1) % dramas.length);
  };

  const prevBanner = () => {
    if (dramas.length <= 1) return;
    setDirection(-1);
    setCurrentBannerIndex((prev) => (prev - 1 + dramas.length) % dramas.length);
  };

  const onTouchStart = (e: React.TouchEvent) => {
    setTouchEndX(null);
    setTouchStartX(e.targetTouches[0].clientX);
  };

  const onTouchMove = (e: React.TouchEvent) => {
    setTouchEndX(e.targetTouches[0].clientX);
  };

  const onTouchEnd = () => {
    if (touchStartX === null || touchEndX === null) return;
    const distance = touchStartX - touchEndX;
    const minSwipeDistance = 50;
    if (distance > minSwipeDistance) {
      nextBanner();
    } else if (distance < -minSwipeDistance) {
      prevBanner();
    }
  };

  // Automatically switch to the next drama every 5 seconds, unless hovering
  useEffect(() => {
    if (isHovering) return;
    if (dramas.length <= 1) return;

    const interval = setInterval(() => {
      nextBanner();
    }, 5000);

    return () => clearInterval(interval);
  }, [dramas.length, isHovering]);

  // Robust boundary check in case a drama is deleted in real-time
  useEffect(() => {
    if (dramas.length === 0) {
      setCurrentBannerIndex(0);
    } else if (currentBannerIndex >= dramas.length) {
      setCurrentBannerIndex(0);
    }
  }, [dramas.length, currentBannerIndex]);

  // Memoized dynamic real-time Live Trending dramas (sorted by average rating descending)
  const trendingDramas = useMemo(() => {
    return [...dramas]
      .map(d => {
        const dramaRatings = ratings.filter(r => r.dramaId === d.id);
        const avg = dramaRatings.length > 0 
          ? dramaRatings.reduce((sum, r) => sum + r.rating, 0) / dramaRatings.length 
          : 0;
        return { drama: d, rating: avg, ratingCount: dramaRatings.length };
      })
      .sort((a, b) => {
        if (b.rating !== a.rating) return b.rating - a.rating;
        return b.ratingCount - a.ratingCount;
      })
      .map(item => item.drama)
      .slice(0, 4);
  }, [dramas, ratings]);

  const [favorites, setFavorites] = useState<number[]>(() => {
    try {
      const saved = localStorage.getItem('vibe_favorites');
      return saved ? JSON.parse(saved) : [1];
    } catch (e) {
      console.error("Failed to parse vibe_favorites from localStorage", e);
      return [1];
    }
  });

  const [playlists, setPlaylists] = useState<Playlist[]>(() => {
    try {
      const saved = localStorage.getItem('vibe_playlists');
      return saved ? JSON.parse(saved) : [
        { id: 1, name: 'Rom-Com Binge', isPrivate: true, dramaIds: [1] }
      ];
    } catch (e) {
      console.error("Failed to parse vibe_playlists from localStorage", e);
      return [
        { id: 1, name: 'Rom-Com Binge', isPrivate: true, dramaIds: [1] }
      ];
    }
  });

  const [watchHistory, setWatchHistory] = useState<WatchHistoryItem[]>(() => {
    try {
      const saved = localStorage.getItem('vibe_history');
      return saved ? JSON.parse(saved) : [
        { dramaId: 1, episodeId: 101, progressSeconds: 420, completed: false, updatedAt: '2026-07-09T12:00:00' }
      ];
    } catch (e) {
      console.error("Failed to parse vibe_history from localStorage", e);
      return [
        { dramaId: 1, episodeId: 101, progressSeconds: 420, completed: false, updatedAt: '2026-07-09T12:00:00' }
      ];
    }
  });

  // UI state variables
  const [authMode, setAuthMode] = useState<'login' | 'signup' | 'forgot'>('login');
  const [fullnameInput, setFullnameInput] = useState<string>('');
  const [usernameInput, setUsernameInput] = useState<string>('');
  const [emailInput, setEmailInput] = useState<string>('');
  const [passwordInput, setPasswordInput] = useState<string>('');
  const [confirmPasswordInput, setConfirmPasswordInput] = useState<string>('');
  const [rememberMe, setRememberMe] = useState<boolean>(true);
  const [authError, setAuthError] = useState<string>('');
  const [authSuccess, setAuthSuccess] = useState<string>('');

  // Player configurations
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [currentTime, setCurrentTime] = useState<number>(0);
  const [playbackSpeed, setPlaybackSpeed] = useState<number>(1);
  const [autoNext, setAutoNext] = useState<boolean>(true);
  const [subtitlesEnabled, setSubtitlesEnabled] = useState<boolean>(true);
  const [useRealPlayer, setUseRealPlayer] = useState<boolean>(false);

  // Bunny Stream Multi-Audio Configurations
  const [audioTracks, setAudioTracks] = useState<{ code: string; name: string; isDefault: boolean }[]>([]);
  const [selectedAudioCode, setSelectedAudioCode] = useState<string | null>(null);
  const [isAudioLoading, setIsAudioLoading] = useState<boolean>(false);
  const [isAudioDropdownOpen, setIsAudioDropdownOpen] = useState<boolean>(false);
  const [isDescExpanded, setIsDescExpanded] = useState<boolean>(false);
  const [isRatingOpen, setIsRatingOpen] = useState<boolean>(false);

  // New review state
  const [newReviewText, setNewReviewText] = useState<string>('');
  const [newReviewRating, setNewReviewRating] = useState<number>(10);

  // Admin suite addition form states
  const [adminUsernameInput, setAdminUsernameInput] = useState<string>('');
  const [adminPasswordInput, setAdminPasswordInput] = useState<string>('');
  const [adminDramaTitle, setAdminDramaTitle] = useState<string>('');
  const [adminDramaDesc, setAdminDramaDesc] = useState<string>('');
  const [adminDramaPoster, setAdminDramaPoster] = useState<string>('');
  const [adminDramaBanner, setAdminDramaBanner] = useState<string>('');
  const [posterUploading, setPosterUploading] = useState<boolean>(false);
  const [posterProgress, setPosterProgress] = useState<number>(0);
  const [bannerUploading, setBannerUploading] = useState<boolean>(false);
  const [bannerProgress, setBannerProgress] = useState<number>(0);
  const [adminDramaTrailer, setAdminDramaTrailer] = useState<string>('');
  const [adminDramaGenre, setAdminDramaGenre] = useState<string>('');
  const [adminDramaCountry, setAdminDramaCountry] = useState<string>('');
  const [adminDramaYear, setAdminDramaYear] = useState<number>(2026);
  const [adminDramaStatus, setAdminDramaStatus] = useState<string>('Ongoing');
  const [adminDramaCast, setAdminDramaCast] = useState<string>('');
  const [adminDramaDownloadUrl, setAdminDramaDownloadUrl] = useState<string>('');
  const [selectedDramaToEdit, setSelectedDramaToEdit] = useState<number | null>(null);

  // Admin episode state
  const [adminEpDramaId, setAdminEpDramaId] = useState<number>(1);
  const [adminEpSeason, setAdminEpSeason] = useState<number>(1);
  const [adminEpNumber, setAdminEpNumber] = useState<number>(1);
  const [adminEpTitle, setAdminEpTitle] = useState<string>('');
  const [adminEpUrl, setAdminEpUrl] = useState<string>('');
  const [adminEpDownloadUrl, setAdminEpDownloadUrl] = useState<string>('');
  const [adminEpEditId, setAdminEpEditId] = useState<number | null>(null);
  const [pastedStreamtapeUrl, setPastedStreamtapeUrl] = useState<string>('');

  // Playlist additions modal/helper
  const [activePlaylistInput, setActivePlaylistInput] = useState<string>('');
  const [activePlaylistPrivate, setActivePlaylistPrivate] = useState<boolean>(true);

  // Streamtape Remote Upload Manager States
  const [adminSubTab, setAdminSubTab] = useState<'catalog' | 'streamtape' | 'storage'>('catalog');
  const [streamtapeLogin, setStreamtapeLogin] = useState<string>(() => safeLocalStorage.getItem('vibe_streamtape_login') || '');
  const [streamtapeKey, setStreamtapeKey] = useState<string>(() => safeLocalStorage.getItem('vibe_streamtape_key') || '');
  const [uploadUrl, setUploadUrl] = useState<string>('');
  const [uploadDramaId, setUploadDramaId] = useState<number>(1);
  const [uploadSeason, setUploadSeason] = useState<number>(1);
  const [uploadEpisode, setUploadEpisode] = useState<number>(1);
  const [uploadCustomName, setUploadCustomName] = useState<string>('');
  const [uploadFolderId, setUploadFolderId] = useState<string>('');
  const [uploadQueue, setUploadQueue] = useState<any[]>(() => {
    try {
      const saved = localStorage.getItem('vibe_upload_queue');
      return saved ? JSON.parse(saved) : [];
    } catch (e) {
      console.error("Failed to parse vibe_upload_queue from localStorage", e);
      return [];
    }
  });

  const [isPurgingRatings, setIsPurgingRatings] = useState<boolean>(false);

  // Custom Glassmorphic Toast Notification State
  const [toast, setToast] = useState<{ message: string; type: 'success' | 'error' | 'info' } | null>(null);
  const showToast = (message: string, type: 'success' | 'error' | 'info' = 'success') => {
    setToast({ message, type });
  };

  // Lockout clock countdown simulator
  const [lockoutRemaining, setLockoutRemaining] = useState<string>('');

  // --------------------------------------------------------
  // Firebase Live Sync & Authentication
  // --------------------------------------------------------
  // Real-time status, presence, loading, and notifications states
  const [isOnline, setIsOnline] = useState<boolean>(navigator.onLine);
  // Track online/offline status
  useEffect(() => {
    const handleOnline = () => {
      setIsOnline(true);
      showToast('✨ Reconnected to VibeDramaHub! Sync restored.', 'success');
    };
    const handleOffline = () => {
      setIsOnline(false);
      showToast('⚠️ Connection lost. Running in offline mode.', 'error');
    };
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  // Live presence system using Firestore
  useEffect(() => {
    let sessId = safeSessionStorage.getItem('vibe_session_id');
    if (!sessId) {
      sessId = 'session_' + Math.random().toString(36).substring(2, 11);
      safeSessionStorage.setItem('vibe_session_id', sessId);
    }
    
    const activeId = currentUser ? String(currentUser.id) : sessId;
    const presenceRef = doc(db, 'presence', activeId);

    const updatePresence = async () => {
      if (!navigator.onLine) return;
      try {
        await setDoc(presenceRef, {
          lastActive: new Date().toISOString(),
          username: currentUser?.username || 'Guest',
          isGuest: !currentUser
        }, { merge: true });
      } catch (err) {
        console.error("Presence update error:", err);
      }
    };

    updatePresence();
    const interval = setInterval(updatePresence, 20000);

    // Subscribe to presence
    const unsubPresence = onSnapshot(collection(db, 'presence'), (snapshot) => {
      const now = Date.now();
      let count = 0;
      snapshot.forEach((doc) => {
        const data = doc.data();
        if (data.lastActive) {
          const lastActiveTime = new Date(data.lastActive).getTime();
          if (now - lastActiveTime < 45000) {
            count++;
          }
        }
      });
      setOnlineCount(count > 0 ? count : 1);
    }, (err) => {
      console.warn("Presence subscription warning (offline or unauthorized):", err);
    });

    const handleUnload = () => {
      deleteDoc(presenceRef).catch(() => {});
    };
    window.addEventListener('beforeunload', handleUnload);

    return () => {
      clearInterval(interval);
      unsubPresence();
      window.removeEventListener('beforeunload', handleUnload);
      deleteDoc(presenceRef).catch(() => {});
    };
  }, [currentUser, isOnline]);

  // --------------------------------------------------------
  // Firebase Live Sync & Authentication
  // --------------------------------------------------------
  // On Mount: Seed and set up real-time onSnapshot subscriptions
  useEffect(() => {
    const initFirebase = async () => {
      try {
        await seedDatabaseIfEmpty();
      } catch (err) {
        console.warn("Seeding failed (probably offline):", err);
      }
    };
    initFirebase();

    // Fallback timeout to ensure the application loads and unlocks even if the Firebase Firestore connection is offline/unavailable.
    const loadingTimeout = setTimeout(() => {
      setInitialDataLoaded((loaded) => {
        if (!loaded) {
          console.warn("Firestore data load timed out. Proceeding in offline mode.");
          return true;
        }
        return loaded;
      });
    }, 2000);

    // Subscribe to dramas
    const unsubDramas = onSnapshot(collection(db, 'dramas'), (snapshot) => {
      const list: Drama[] = [];
      snapshot.forEach((doc) => {
        list.push(doc.data() as Drama);
      });
      // Order dramas by createdAt in descending order so the newest drama is featured automatically.
      list.sort((a, b) => {
        const timeA = a.createdAt ? new Date(a.createdAt).getTime() : a.id;
        const timeB = b.createdAt ? new Date(b.createdAt).getTime() : b.id;
        return timeB - timeA;
      });
      setDramas(list);
      setInitialDataLoaded(true);
    }, (err) => {
      console.error("Dramas subscription error:", err);
      setInitialDataLoaded(true); // Ensure app unlocks even if dramas subscription fails
    });

    // Subscribe to episodes
    const unsubEpisodes = onSnapshot(collection(db, 'episodes'), (snapshot) => {
      const list: Episode[] = [];
      snapshot.forEach((doc) => {
        list.push(doc.data() as Episode);
      });
      list.sort((a, b) => a.episode_number - b.episode_number);
      setEpisodes(list);
    }, (err) => console.error("Episodes subscription error:", err));

    // Subscribe to reviews
    const unsubReviews = onSnapshot(collection(db, 'reviews'), (snapshot) => {
      const list: Review[] = [];
      snapshot.forEach((doc) => {
        list.push(doc.data() as Review);
      });
      setReviews(list);
    }, (err) => console.error("Reviews subscription error:", err));

    // Subscribe to registered users
    const unsubUsers = onSnapshot(collection(db, 'users'), (snapshot) => {
      const list: PlatformUser[] = [];
      snapshot.forEach((doc) => {
        list.push(doc.data() as PlatformUser);
      });
      setRegisteredUsers(list);
    }, (err) => console.error("Users subscription error:", err));

    // Subscribe to notifications
    const unsubNotifications = onSnapshot(collection(db, 'notifications'), (snapshot) => {
      const list: PlatformNotification[] = [];
      snapshot.forEach((doc) => {
        list.push({ id: doc.id, ...doc.data() } as PlatformNotification);
      });
      list.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
      
      setNotifications(prev => {
        // Only trigger toast if we already had notifications loaded previously
        if (prev.length > 0 && list.length > prev.length) {
          const newest = list[0];
          showToast(`🔔 New Release: ${newest.title} - ${newest.description}`, 'success');
        }
        return list;
      });
    }, (err) => console.error("Notifications subscription error:", err));

    // Subscribe to views
    const unsubViews = onSnapshot(collection(db, 'views'), (snapshot) => {
      const list: any[] = [];
      snapshot.forEach((doc) => {
        list.push(doc.data());
      });
      setAllViews(list);
    }, (err) => console.error("Views subscription error:", err));

    // Subscribe to likes
    const unsubLikes = onSnapshot(collection(db, 'likes'), (snapshot) => {
      const list: any[] = [];
      snapshot.forEach((doc) => {
        list.push(doc.data());
      });
      setAllLikes(list);
    }, (err) => console.error("Likes subscription error:", err));

    // Subscribe to favorites
    const unsubFavorites = onSnapshot(collection(db, 'favorites'), (snapshot) => {
      const list: any[] = [];
      snapshot.forEach((doc) => {
        list.push(doc.data());
      });
      setAllFavorites(list);
    }, (err) => console.error("Favorites subscription error:", err));

    // Subscribe to ratings
    const unsubRatings = onSnapshot(collection(db, 'ratings'), (snapshot) => {
      const list: Rating[] = [];
      snapshot.forEach((doc) => {
        list.push({ id: doc.id, ...doc.data() } as Rating);
      });
      setRatings(list);
    }, (err) => console.error("Ratings subscription error:", err));

    // Subscribe to presence
    const unsubPresence = onSnapshot(collection(db, 'presence'), (snapshot) => {
      let activeCount = 0;
      const cutoff = Date.now() - 25000; // 25 seconds of inactivity is considered offline
      snapshot.forEach((doc) => {
        const data = doc.data();
        if (data.last_active) {
          const activeTime = new Date(data.last_active).getTime();
          if (activeTime >= cutoff) {
            activeCount++;
          }
        }
      });
      setOnlineCount(Math.max(1, activeCount));
    }, (err) => console.error("Presence subscription error:", err));

    return () => {
      clearTimeout(loadingTimeout);
      unsubDramas();
      unsubEpisodes();
      unsubReviews();
      unsubUsers();
      unsubNotifications();
      unsubViews();
      unsubLikes();
      unsubFavorites();
      unsubRatings();
      unsubPresence();
    };
  }, []);

  // Sync auth state changes & real-time user document profile
  useEffect(() => {
    let unsubUserDoc: (() => void) | null = null;

    // Enforce Local Persistence
    setPersistence(auth, browserLocalPersistence).catch((err) => {
      console.error("Firebase auth local persistence configuration failure:", err);
    });

    const unsubAuth = onAuthStateChanged(auth, async (firebaseUser) => {
      if (unsubUserDoc) {
        unsubUserDoc();
        unsubUserDoc = null;
      }

      if (firebaseUser) {
        const isAuthorizedAdmin = firebaseUser.email === 'rahulgahatraj2007@gmail.com';
        if (isAuthorizedAdmin) {
          setIsAdminLogged(true);
          setAuthLoading(false);
        }

        // Set up real-time subscription for the active user's document
        unsubUserDoc = onSnapshot(doc(db, 'users', firebaseUser.uid), async (userDoc) => {
          if (userDoc.exists()) {
            const profile = userDoc.data() as PlatformUser;
            const isAuthorizedAdminConfirm = firebaseUser.email === 'rahulgahatraj2007@gmail.com' && profile.role === 'admin';
            
            if (firebaseUser.email === 'rahulgahatraj2007@gmail.com' && profile.role !== 'admin') {
              const updatedProfile = { ...profile, role: 'admin' };
              await setDoc(doc(db, 'users', firebaseUser.uid), updatedProfile);
            } else {
              if (firebaseUser.email !== 'rahulgahatraj2007@gmail.com' && profile.role === 'admin') {
                const downgradedProfile = { ...profile, role: 'user' };
                await setDoc(doc(db, 'users', firebaseUser.uid), downgradedProfile);
              } else {
                setCurrentUser(profile);
                setIsAdminLogged(isAuthorizedAdminConfirm);
                safeLocalStorage.setItem('vibe_user', JSON.stringify(profile));
                setAuthLoading(false);
              }
            }
          } else {
            // Document doesn't exist yet, seed it
            const isAuthorizedAdminConfirm = firebaseUser.email === 'rahulgahatraj2007@gmail.com';
            const fallbackProfile: PlatformUser = {
              id: firebaseUser.uid,
              fullname: firebaseUser.displayName || (isAuthorizedAdminConfirm ? 'Rahul (Admin)' : 'Vibe Member'),
              username: firebaseUser.displayName?.split(' ')[0] || (isAuthorizedAdminConfirm ? 'Rahul' : 'Member'),
              email: firebaseUser.email || '',
              status: 'active',
              createdAt: new Date().toISOString().split('T')[0],
              role: isAuthorizedAdminConfirm ? 'admin' : 'user'
            };
            await setDoc(doc(db, 'users', firebaseUser.uid), fallbackProfile);
          }
        }, (err) => {
          console.error("User doc real-time subscription error:", err);
          setAuthLoading(false);
        });
      } else {
        setCurrentUser(null);
        setIsAdminLogged(false);
        safeLocalStorage.removeItem('vibe_user');

        const savedTab = safeLocalStorage.getItem('vibe_active_tab');
        if (savedTab === 'admin_dash' || savedTab === 'admin_login') {
          setActiveTab('admin_login');
        }
        setAuthLoading(false);
      }
    });

    return () => {
      unsubAuth();
      if (unsubUserDoc) unsubUserDoc();
    };
  }, []);

  const isPopStateRef = useRef<boolean>(false);
  const selectedDramaRef = useRef<Drama | null>(null);
  const selectedEpisodeRef = useRef<Episode | null>(null);
  const isHydratingRef = useRef<boolean>(false);

  useEffect(() => {
    selectedDramaRef.current = selectedDrama;
  }, [selectedDrama]);

  useEffect(() => {
    selectedEpisodeRef.current = selectedEpisode;
  }, [selectedEpisode]);

  const [pendingNavDramaId, setPendingNavDramaId] = useState<number | null>(null);
  const [pendingNavEpisodeId, setPendingNavEpisodeId] = useState<number | null>(null);

  // Scroll Positions Ref - loads from and persists to sessionStorage
  const scrollPositionsRef = useRef<Record<string, number>>((() => {
    try {
      const saved = sessionStorage.getItem('vibe_scroll_positions');
      return saved ? JSON.parse(saved) : {};
    } catch (e) {
      return {};
    }
  })());

  const getCurrentScrollKey = () => {
    if (selectedEpisode) {
      return `player-${selectedEpisode.id}`;
    }
    if (selectedDrama) {
      return `drama-${selectedDrama.id}`;
    }
    if (activeTab === 'home') {
      if (searchQuery) {
        return `home-search-${searchQuery}`;
      }
      if (selectedGenre) {
        return `home-genre-${selectedGenre}`;
      }
      return 'home-main';
    }
    return activeTab;
  };

  const lastViewKeyRef = useRef<string>('');

  // Sync selectedDrama and selectedEpisode to localStorage to preserve state on refresh
  useEffect(() => {
    if (selectedDrama) {
      safeLocalStorage.setItem('vibe_selected_drama_id', String(selectedDrama.id));
    } else {
      safeLocalStorage.removeItem('vibe_selected_drama_id');
    }
  }, [selectedDrama]);

  useEffect(() => {
    if (selectedEpisode) {
      safeLocalStorage.setItem('vibe_selected_episode_id', String(selectedEpisode.id));
    } else {
      safeLocalStorage.removeItem('vibe_selected_episode_id');
    }
  }, [selectedEpisode]);

  // Listen to window scroll events and persist them in sessionStorage/ref
  useEffect(() => {
    const handleScroll = () => {
      const key = getCurrentScrollKey();
      if (key) {
        scrollPositionsRef.current[key] = window.scrollY;
        try {
          sessionStorage.setItem('vibe_scroll_positions', JSON.stringify(scrollPositionsRef.current));
        } catch (e) {
          // Ignore
        }
      }
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => {
      window.removeEventListener('scroll', handleScroll);
    };
  }, [activeTab, selectedDrama?.id, selectedEpisode?.id, searchQuery, selectedGenre]);

  // Restore scroll positions when view/tab changes
  useEffect(() => {
    const currentKey = getCurrentScrollKey();
    if (currentKey !== lastViewKeyRef.current) {
      const savedScroll = scrollPositionsRef.current[currentKey];
      
      if (savedScroll !== undefined && savedScroll > 0) {
        let attempts = 0;
        const restore = () => {
          window.scrollTo(0, savedScroll);
          if (Math.abs(window.scrollY - savedScroll) > 10 && attempts < 10) {
            attempts++;
            requestAnimationFrame(restore);
          }
        };
        setTimeout(restore, 50);
      } else {
        // Only scroll to top on non-player tab/drama views to avoid breaking scroll-to-player
        if (!selectedEpisode) {
          window.scrollTo(0, 0);
        }
      }
      lastViewKeyRef.current = currentKey;
    }
  }, [activeTab, selectedDrama?.id, selectedEpisode?.id, searchQuery, selectedGenre]);

  // 1. Initial Routing & Popstate Handling (Browser-initiated navigation)
  useEffect(() => {
    const handleNavigation = (e?: PopStateEvent) => {
      if (e) {
        isPopStateRef.current = true;
      }
      let state = e?.state || window.history.state;
      const path = window.location.pathname;
      const searchParams = new URLSearchParams(window.location.search);

      if (!state) {
        let parsedDramaId: number | null = null;
        let parsedEpisodeId: number | null = null;

        if (path.startsWith('/drama/')) {
          const idStr = path.substring(7).split('/')[0];
          const num = Number(idStr);
          if (!isNaN(num)) parsedDramaId = num;
        } else if (searchParams.has('id') && path.startsWith('/drama')) {
          const num = Number(searchParams.get('id'));
          if (!isNaN(num)) parsedDramaId = num;
        }

        if (path.startsWith('/episode/')) {
          const idStr = path.substring(9).split('/')[0];
          const num = Number(idStr);
          if (!isNaN(num)) parsedEpisodeId = num;
        } else if (searchParams.has('id') && path.startsWith('/episode')) {
          const num = Number(searchParams.get('id'));
          if (!isNaN(num)) parsedEpisodeId = num;
        }

        if (parsedEpisodeId && searchParams.has('dramaId')) {
          const num = Number(searchParams.get('dramaId'));
          if (!isNaN(num)) parsedDramaId = num;
        }

        let tab = 'home';
        if (path.startsWith('/admin')) {
          if (authLoading) return;
          tab = auth.currentUser && isAdminLogged ? 'admin_dash' : 'admin_login';
        } else if (path.startsWith('/profile')) {
          tab = 'profile';
        } else if (path.startsWith('/playlists')) {
          tab = 'playlists';
        } else if (path.startsWith('/mylist')) {
          tab = 'mylist';
        } else if (path.startsWith('/history')) {
          tab = 'history';
        } else if (path.startsWith('/copyright')) {
          tab = 'copyright';
        } else if (path.startsWith('/legal')) {
          tab = 'legal';
        } else if (path.startsWith('/brand')) {
          tab = 'brand';
        } else if (path.startsWith('/support')) {
          tab = 'support';
        } else if (path.startsWith('/contact')) {
          tab = 'contact';
        } else if (parsedEpisodeId) {
          tab = 'player';
        } else if (parsedDramaId) {
          tab = 'home';
        } else if (path === '/' || path === '') {
          const savedTab = safeLocalStorage.getItem('vibe_active_tab') || 'home';
          const savedDramaId = safeLocalStorage.getItem('vibe_selected_drama_id');
          const savedEpisodeId = safeLocalStorage.getItem('vibe_selected_episode_id');
          tab = savedTab;
          if (!parsedDramaId && savedDramaId) parsedDramaId = Number(savedDramaId);
          if (!parsedEpisodeId && savedEpisodeId) parsedEpisodeId = Number(savedEpisodeId);
        }

        state = {
          tab: tab,
          dramaId: parsedDramaId,
          episodeId: parsedEpisodeId
        };
        window.history.replaceState(state, '', getPathForState(tab, parsedDramaId, parsedEpisodeId));
      }

      if (state) {
        setActiveTab(state.tab || 'home');
        if (state.dramaId) {
          const foundDrama = dramas.find(d => d.id === state.dramaId);
          if (foundDrama) {
            if (!selectedDramaRef.current || selectedDramaRef.current.id !== foundDrama.id) {
              setSelectedDrama(foundDrama);
            }
          } else {
            setPendingNavDramaId(state.dramaId);
          }
        } else {
          if (selectedDramaRef.current !== null) {
            setSelectedDrama(null);
          }
          setPendingNavDramaId(null);
        }

        if (state.episodeId) {
          const foundEp = episodes.find(ep => ep.id === state.episodeId);
          if (foundEp) {
            if (!selectedEpisodeRef.current || selectedEpisodeRef.current.id !== foundEp.id) {
              setSelectedEpisode(foundEp);
            }
          } else {
            setPendingNavEpisodeId(state.episodeId);
          }
        } else {
          if (selectedEpisodeRef.current !== null) {
            setSelectedEpisode(null);
          }
          setPendingNavEpisodeId(null);
        }
      }
    };

    if (!authLoading) {
      handleNavigation();
    }

    window.addEventListener('popstate', handleNavigation);
    return () => window.removeEventListener('popstate', handleNavigation);
  }, [authLoading, dramas, episodes, isAdminLogged]);

  // 2. Hydrate pending navigation states once Async Firebase data loads
  useEffect(() => {
    if (pendingNavDramaId && dramas.length > 0) {
      const found = dramas.find(d => d.id === pendingNavDramaId);
      if (found) {
        setSelectedDrama(found);
        setPendingNavDramaId(null);
      }
    }
  }, [pendingNavDramaId, dramas]);

  useEffect(() => {
    if (pendingNavEpisodeId && episodes.length > 0) {
      const found = episodes.find(e => e.id === pendingNavEpisodeId);
      if (found) {
        setSelectedEpisode(found);
        setPendingNavEpisodeId(null);
      }
    }
  }, [pendingNavEpisodeId, episodes]);

  // 3. Sync Active Tab state back to the URL (User-initiated in-app navigation)
  useEffect(() => {
    // If the data is still loading or hydrating, do NOT sync/push state to the browser history
    if (!initialDataLoaded || pendingNavDramaId !== null || pendingNavEpisodeId !== null) {
      return;
    }

    if (isPopStateRef.current) {
      isPopStateRef.current = false;
      return;
    }

    const currentState = window.history.state;
    const newDramaId = selectedDrama ? selectedDrama.id : null;
    const newEpisodeId = selectedEpisode ? selectedEpisode.id : null;

    if (
      currentState &&
      currentState.tab === activeTab &&
      currentState.dramaId === newDramaId &&
      currentState.episodeId === newEpisodeId
    ) {
      return;
    }

    const path = (activeTab === 'admin_dash' || activeTab === 'admin_login') ? '/admin' : '/';
    
    window.history.pushState({
      tab: activeTab,
      dramaId: newDramaId,
      episodeId: newEpisodeId
    }, '', path);
  }, [activeTab, selectedDrama, selectedEpisode, initialDataLoaded, pendingNavDramaId, pendingNavEpisodeId]);

  // Track navigation history stack (breadcrumbs) reactively to prevent "blank home" issue
  useEffect(() => {
    if (!initialDataLoaded) return;

    const currentTab = activeTab;
    const currentDramaId = selectedDrama ? selectedDrama.id : null;
    const currentEpisodeId = selectedEpisode ? selectedEpisode.id : null;

    setNavStack(prev => {
      // 1. If stack is empty, initialize it with the current state
      if (prev.length === 0) {
        return [{ tab: currentTab, dramaId: currentDramaId, episodeId: currentEpisodeId }];
      }

      const last = prev[prev.length - 1];
      // 2. If current state matches the last state in the stack, do nothing
      if (last.tab === currentTab && last.dramaId === currentDramaId && last.episodeId === currentEpisodeId) {
        return prev;
      }

      // 3. If we are navigating "back" (i.e. current state matches a state previously in the stack),
      // we can roll back (slice) the stack to that matching state to preserve the clean stack trace.
      const existingIndex = prev.findIndex(
        item => item.tab === currentTab && item.dramaId === currentDramaId && item.episodeId === currentEpisodeId
      );
      if (existingIndex !== -1) {
        return prev.slice(0, existingIndex + 1);
      }

      // 4. If we are replacing an episode with another episode of the same drama (e.g. play next episode),
      // replace the last stack item instead of adding a new one, keeping navigation direct.
      if (last.dramaId === currentDramaId && last.episodeId !== null && currentEpisodeId !== null) {
        const nextStack = [...prev];
        nextStack[nextStack.length - 1] = { tab: currentTab, dramaId: currentDramaId, episodeId: currentEpisodeId };
        return nextStack;
      }

      // 5. Otherwise, push the new navigation state onto the stack
      return [...prev, { tab: currentTab, dramaId: currentDramaId, episodeId: currentEpisodeId }];
    });
  }, [activeTab, selectedDrama?.id, selectedEpisode?.id, initialDataLoaded]);

  // History-aware back button action
  const handleBack = () => {
    if (navStack.length > 1) {
      // We have a history stack! Pop the current state and restore the previous one
      const updatedStack = [...navStack];
      updatedStack.pop(); // Remove current state
      const prevState = updatedStack[updatedStack.length - 1];

      // Update our stack state (the reactive hook will see the state changes below and automatically slice the stack)
      setNavStack(updatedStack);

      // Restore states
      const foundDrama = prevState.dramaId ? dramas.find(d => d.id === prevState.dramaId) || null : null;
      const foundEpisode = prevState.episodeId ? episodes.find(e => e.id === prevState.episodeId) || null : null;

      // Update states
      setActiveTab(prevState.tab);
      setSelectedDrama(foundDrama);
      setSelectedEpisode(foundEpisode);

      // Save to localStorage for safety
      safeLocalStorage.setItem('vibe_active_tab', prevState.tab);
      if (prevState.dramaId) {
        safeLocalStorage.setItem('vibe_selected_drama_id', String(prevState.dramaId));
      } else {
        safeLocalStorage.removeItem('vibe_selected_drama_id');
      }
      if (prevState.episodeId) {
        safeLocalStorage.setItem('vibe_selected_episode_id', String(prevState.episodeId));
      } else {
        safeLocalStorage.removeItem('vibe_selected_episode_id');
      }

      // Sync browser history so progressive back buttons also align
      const path = (prevState.tab === 'admin_dash' || prevState.tab === 'admin_login') ? '/admin' : '/';
      window.history.pushState({ 
        tab: prevState.tab, 
        dramaId: prevState.dramaId, 
        episodeId: prevState.episodeId 
      }, '', path);
    } else {
      // Fallback if stack is somehow empty or has 1 item
      if (selectedEpisode) {
        setSelectedEpisode(null);
      } else if (selectedDrama) {
        setSelectedDrama(null);
      } else {
        setActiveTab('home');
      }
    }
  };

  // Top-level playNextEpisode for auto-play and message event handlers
  const playNextEpisode = () => {
    if (!selectedEpisode) return;
    const dramaEpisodes = episodes
      .filter(e => e.drama_id === selectedEpisode.drama_id)
      .sort((a, b) => a.episode_number - b.episode_number);
      
    const currentIndex = dramaEpisodes.findIndex(e => e.id === selectedEpisode.id);
    if (currentIndex !== -1 && currentIndex < dramaEpisodes.length - 1) {
      const nextEp = dramaEpisodes[currentIndex + 1];
      setSelectedEpisode(nextEp);
      setCurrentTime(0);
      setIsPlaying(true);
      showToast(`Playing Episode ${nextEp.episode_number}: ${nextEp.title}...`, 'info');
      
      setTimeout(() => {
        document.getElementById('video-player-container')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }, 150);
    } else {
      showToast('You have watched the last episode of this series!', 'success');
    }
  };

  // Register postMessage message event handler for Bunny Stream auto-play next
  useEffect(() => {
    const handleBunnyMessage = (event: MessageEvent) => {
      let data;
      try {
        data = typeof event.data === 'string' ? JSON.parse(event.data) : event.data;
      } catch (e) {
        return;
      }
      
      if (!data) return;
      
      const isEnded = 
        data.event === 'ended' || 
        data.event === 'player:ended' || 
        data.event === 'video:ended' || 
        data.type === 'ended';
        
      if (isEnded) {
        if (autoNext) {
          playNextEpisode();
        }
      }
    };
    
    window.addEventListener('message', handleBunnyMessage);
    return () => {
      window.removeEventListener('message', handleBunnyMessage);
    };
  }, [selectedEpisode, episodes, autoNext]);

  // Auto scroll to Video Player when activeEpisode changes
  useEffect(() => {
    if (activeTab === 'player' && selectedEpisode) {
      const handleScrollToPlayer = () => {
        const container = document.getElementById('video-player-container');
        if (container) {
          container.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
      };

      // Set a small timeout as a fallback to ensure we scroll even if onLoad doesn't fire
      const timer = setTimeout(handleScrollToPlayer, 400);

      return () => clearTimeout(timer);
    }
  }, [selectedEpisode?.id, activeTab]);

  // Online Presence heartbeat logic
  useEffect(() => {
    let visitorId = safeLocalStorage.getItem('vibe_visitor_id');
    if (!visitorId) {
      visitorId = 'visitor_' + Math.random().toString(36).substring(2, 11);
      safeLocalStorage.setItem('vibe_visitor_id', visitorId);
    }

    const updatePresence = async () => {
      const activeId = auth.currentUser ? auth.currentUser.uid : visitorId;
      if (!activeId) return;

      const presenceRef = doc(db, 'presence', activeId);
      try {
        await setDoc(presenceRef, {
          last_active: new Date().toISOString(),
          userId: auth.currentUser ? auth.currentUser.uid : null,
          isOnline: true
        }, { merge: true });
      } catch (err) {
        console.error("Failed to update presence:", err);
      }
    };

    updatePresence();
    const interval = setInterval(updatePresence, 10000);

    const handleUnload = () => {
      const activeId = auth.currentUser ? auth.currentUser.uid : visitorId;
      if (activeId) {
        const presenceRef = doc(db, 'presence', activeId);
        deleteDoc(presenceRef).catch(() => {});
      }
    };

    window.addEventListener('beforeunload', handleUnload);

    return () => {
      clearInterval(interval);
      window.removeEventListener('beforeunload', handleUnload);
    };
  }, [currentUser]);

  // Load favorites, playlists, and history from profile when logged in, or local storage when logged out
  useEffect(() => {
    isHydratingRef.current = true;
    if (currentUser) {
      if (currentUser.favorites) {
        setFavorites(currentUser.favorites);
      }
      if (currentUser.playlists) {
        setPlaylists(currentUser.playlists);
      }
      if (currentUser.watchHistory) {
        setWatchHistory(currentUser.watchHistory);
      }
    } else {
      const savedFavs = safeLocalStorage.getItem('vibe_favorites');
      try {
        setFavorites(savedFavs ? JSON.parse(savedFavs) : [1]);
      } catch (e) {
        setFavorites([1]);
      }
      
      const savedPlaylists = safeLocalStorage.getItem('vibe_playlists');
      try {
        setPlaylists(savedPlaylists ? JSON.parse(savedPlaylists) : [
          { id: 1, name: 'Rom-Com Binge', isPrivate: true, dramaIds: [1] }
        ]);
      } catch (e) {
        setPlaylists([
          { id: 1, name: 'Rom-Com Binge', isPrivate: true, dramaIds: [1] }
        ]);
      }
      
      const savedHistory = safeLocalStorage.getItem('vibe_history');
      try {
        setWatchHistory(savedHistory ? JSON.parse(savedHistory) : [
          { dramaId: 1, episodeId: 101, progressSeconds: 420, completed: false, updatedAt: '2026-07-09T12:00:00' }
        ]);
      } catch (e) {
        setWatchHistory([
          { dramaId: 1, episodeId: 101, progressSeconds: 420, completed: false, updatedAt: '2026-07-09T12:00:00' }
        ]);
      }
    }
    // Allow React state updates to resolve before releasing hydration lock
    const timer = setTimeout(() => {
      isHydratingRef.current = false;
    }, 50);
    return () => clearTimeout(timer);
  }, [currentUser]);

  // Synchronize local updates back to Firestore profile when logged in, or local storage when logged out
  useEffect(() => {
    if (isHydratingRef.current) return;

    if (currentUser && auth.currentUser) {
      const userRef = doc(db, 'users', auth.currentUser.uid);
      const needsUpdate = 
        JSON.stringify(currentUser.favorites || []) !== JSON.stringify(favorites);
      
      if (needsUpdate) {
        setDoc(userRef, {
          favorites
        }, { merge: true }).catch(err => console.error("Error syncing favorites to Firestore profile:", err));
      }
    } else {
      safeLocalStorage.setItem('vibe_favorites', JSON.stringify(favorites));
    }
  }, [favorites, currentUser]);

  useEffect(() => {
    if (isHydratingRef.current) return;

    if (currentUser && auth.currentUser) {
      const userRef = doc(db, 'users', auth.currentUser.uid);
      const needsUpdate = 
        JSON.stringify(currentUser.playlists || []) !== JSON.stringify(playlists);
      if (needsUpdate) {
        setDoc(userRef, { playlists }, { merge: true }).catch(err => console.error("Error syncing playlists to Firestore profile:", err));
      }
    } else {
      safeLocalStorage.setItem('vibe_playlists', JSON.stringify(playlists));
    }
  }, [playlists, currentUser]);

  useEffect(() => {
    if (isHydratingRef.current) return;

    if (currentUser && auth.currentUser) {
      const userRef = doc(db, 'users', auth.currentUser.uid);
      const needsUpdate = 
        JSON.stringify(currentUser.watchHistory || []) !== JSON.stringify(watchHistory);
      if (needsUpdate) {
        setDoc(userRef, { watchHistory }, { merge: true }).catch(err => console.error("Error syncing history to Firestore profile:", err));
      }
    } else {
      safeLocalStorage.setItem('vibe_history', JSON.stringify(watchHistory));
    }
  }, [watchHistory, currentUser]);

  // Auto-clear toast notification after 4 seconds
  useEffect(() => {
    if (toast) {
      const timer = setTimeout(() => {
        setToast(null);
      }, 4000);
      return () => clearTimeout(timer);
    }
  }, [toast]);

  // Streamtape states persistence
  useEffect(() => {
    safeLocalStorage.setItem('vibe_streamtape_login', streamtapeLogin);
  }, [streamtapeLogin]);

  useEffect(() => {
    safeLocalStorage.setItem('vibe_streamtape_key', streamtapeKey);
  }, [streamtapeKey]);

  useEffect(() => {
    safeLocalStorage.setItem('vibe_upload_queue', JSON.stringify(uploadQueue));
  }, [uploadQueue]);

  // Streamtape Queue Simulator Auto-refresh (Every 5 seconds)
  useEffect(() => {
    let interval: any;
    const hasActiveJob = uploadQueue.some(j => j.status === 'pending' || j.status === 'processing');
    
    if (hasActiveJob) {
      interval = setInterval(() => {
        setUploadQueue(prevQueue => {
          const nextQueue = prevQueue.map(job => {
            if (job.status === 'pending') {
              return { ...job, status: 'processing', progress: 10 };
            }
            if (job.status === 'processing') {
              const nextProgress = job.progress + Math.floor(Math.random() * 20) + 12;
              if (nextProgress >= 100) {
                // Upload Completed! Save to local states immediately
                const fileId = 'tape_' + Math.random().toString(36).substring(2, 11);
                const embedUrl = `https://streamtape.com/e/${fileId}`;
                
                // Attach the uploaded video to the selected episode and display immediately
                setEpisodes(prevEps => {
                  const existingIndex = prevEps.findIndex(e => e.drama_id === job.drama_id && e.episode_number === job.episode_number);
                  const epTitle = `Episode ${job.episode_number}: ${job.custom_name.replace('.mp4', '').replace('.mkv', '').replace(/[-_]/g, ' ')}`;
                  
                  if (existingIndex !== -1) {
                    const updated = [...prevEps];
                    updated[existingIndex] = {
                      ...updated[existingIndex],
                      streamtape_url: embedUrl
                    };
                    return updated;
                  } else {
                    return [
                      ...prevEps,
                      {
                        id: Date.now() + Math.floor(Math.random() * 1000),
                        drama_id: job.drama_id,
                        episode_number: job.episode_number,
                        title: epTitle,
                        streamtape_url: embedUrl
                      }
                    ];
                  }
                });

                return {
                  ...job,
                  status: 'completed',
                  progress: 100,
                  file_id: fileId,
                  embed_url: embedUrl
                };
              }
              return { ...job, progress: nextProgress };
            }
            return job;
          });
          
          return nextQueue;
        });
      }, 5000);
    }
    
    return () => clearInterval(interval);
  }, [uploadQueue]);

  // Lockout tick simulator
  useEffect(() => {
    if (lockoutTime) {
      const interval = setInterval(() => {
        const diff = lockoutTime - Date.now();
        if (diff <= 0) {
          setLockoutTime(null);
          setFailedAttempts(0);
          setAuthError('');
        } else {
          const minutes = Math.floor(diff / 60000);
          const seconds = Math.floor((diff % 60000) / 1000);
          setLockoutRemaining(`${minutes}m ${seconds}s`);
        }
      }, 1000);
      return () => clearInterval(interval);
    }
  }, [lockoutTime]);

  // Track watch history when selectedEpisode changes
  useEffect(() => {
    if (selectedEpisode) {
      updateWatchProgressLocal(selectedEpisode.drama_id, selectedEpisode.id, 0, false);
      setVideoUnavailable(false);

      // Record a real-time view log in Firestore
      const userId = auth.currentUser ? auth.currentUser.uid : (safeLocalStorage.getItem('vibe_visitor_id') || 'guest');
      const viewDocId = `${selectedEpisode.id}_${userId}`;
      setDoc(doc(db, 'views', viewDocId), {
        dramaId: selectedEpisode.drama_id,
        episodeId: selectedEpisode.id,
        userId: userId,
        watchedAt: new Date().toISOString()
      }, { merge: true }).catch(err => console.error("Error logging real-time view to Firestore:", err));
    }
  }, [selectedEpisode]);

  // Dynamic audio language detection from Bunny Stream HLS Playlist
  useEffect(() => {
    if (!selectedEpisode || !selectedEpisode.streamtape_url) {
      setAudioTracks([]);
      setSelectedAudioCode(null);
      return;
    }

    const url = selectedEpisode.streamtape_url.trim();
    let playlistUrl = '';

    // 1. iframe.mediadelivery.net (embed or play)
    const mediaDeliveryRegex = /iframe\.mediadelivery\.net\/(embed|play)\/([a-zA-Z0-9\-]+)\/([a-zA-Z0-9\-]+)/i;
    const match = url.match(mediaDeliveryRegex);
    if (match) {
      const libraryId = match[2];
      const videoId = match[3];
      playlistUrl = `https://iframe.mediadelivery.net/play/${libraryId}/${videoId}/playlist.m3u8`;
    } else {
      // 2. Direct Bunny CDN hostnames
      const bCdnRegex = /(vz-[a-zA-Z0-9\-]+\.b-cdn\.net)\/([a-zA-Z0-9\-]+)/i;
      const bCdnMatch = url.match(bCdnRegex);
      if (bCdnMatch) {
        const host = bCdnMatch[1];
        const videoId = bCdnMatch[2];
        playlistUrl = `https://${host}/${videoId}/playlist.m3u8`;
      }
    }

    if (!playlistUrl) {
      // Not a Bunny Stream URL or couldn't parse it. Set to empty.
      setAudioTracks([]);
      setSelectedAudioCode(null);
      return;
    }

    setIsAudioLoading(true);
    let isMounted = true;

    fetch(playlistUrl)
      .then(res => {
        if (!res.ok) throw new Error('Playlist fetch failed');
        return res.text();
      })
      .then(text => {
        if (!isMounted) return;
        
        const lines = text.split('\n');
        const parsedTracks: { code: string; name: string; isDefault: boolean }[] = [];
        const seenLanguages = new Set<string>();

        for (const line of lines) {
          if (line.startsWith('#EXT-X-MEDIA:') && line.includes('TYPE=AUDIO')) {
            const nameMatch = line.match(/NAME="([^"]+)"/i);
            const langMatch = line.match(/LANGUAGE="([^"]+)"/i);
            const defaultMatch = line.match(/DEFAULT=(YES|NO)/i);

            const name = nameMatch ? nameMatch[1] : '';
            const code = langMatch ? langMatch[1] : '';
            const isDefault = defaultMatch ? defaultMatch[1].toUpperCase() === 'YES' : false;

            const finalCode = code || name.toLowerCase().slice(0, 2);
            const finalName = getFriendlyLanguageName(finalCode, name);

            if (finalCode && !seenLanguages.has(finalCode)) {
              seenLanguages.add(finalCode);
              parsedTracks.push({
                code: finalCode,
                name: finalName,
                isDefault
              });
            }
          }
        }

        // If no alternative audio tracks are found in the m3u8, but it's a valid playlist,
        // it means there's just one audio track (original language).
        if (parsedTracks.length === 0) {
          parsedTracks.push({
            code: 'original',
            name: 'Original Audio',
            isDefault: true
          });
        }

        setAudioTracks(parsedTracks);

        // Find the default track
        const defaultTrack = parsedTracks.find(t => t.isDefault) || parsedTracks[0];
        if (defaultTrack) {
          setSelectedAudioCode(defaultTrack.code);
        }
        setIsAudioLoading(false);
      })
      .catch(err => {
        console.error("Error loading Bunny Stream audio tracks:", err);
        if (isMounted) {
          // Fall back to a single original track
          setAudioTracks([{
            code: 'original',
            name: 'Original Audio',
            isDefault: true
          }]);
          setSelectedAudioCode('original');
          setIsAudioLoading(false);
        }
      });

    return () => {
      isMounted = false;
    };
  }, [selectedEpisode]);

  const handleLanguageChange = (code: string, name: string) => {
    setSelectedAudioCode(code);
    showToast(`Switching audio stream to ${name}...`, 'info');

    // Attempt to send postMessage to the player for seamless dynamic switching
    const iframe = document.getElementById('bunny-player-iframe') as HTMLIFrameElement;
    if (iframe && iframe.contentWindow) {
      const messages = [
        { event: 'setLanguage', value: code },
        { method: 'setLanguage', value: code },
        { event: 'setAudioTrack', value: code },
        { method: 'setAudioTrack', value: code },
        { event: 'setAudioTrack', value: name },
        { method: 'setAudioTrack', value: name },
        { event: 'setAudio', value: code },
        { method: 'setAudio', value: code }
      ];
      messages.forEach(msg => {
        try {
          iframe.contentWindow?.postMessage(JSON.stringify(msg), '*');
        } catch (e) {
          console.error("postMessage error:", e);
        }
      });
    }
  };

  // --------------------------------------------------------
  // Handlers & Business Logic
  // --------------------------------------------------------
  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError('');
    setAuthSuccess('');

    // Check rate limit lockout first
    if (lockoutTime && lockoutTime > Date.now()) {
      setAuthError('Too many failed login attempts. Please try again after 2 hours.');
      return;
    }

    try {
      // Determine email if username is entered
      let email = usernameInput;
      if (!usernameInput.includes('@')) {
        const matched = registeredUsers.find(
          u => u.username.toLowerCase() === usernameInput.toLowerCase()
        );
        if (matched) {
          email = matched.email;
        } else {
          // Fallback if not found locally, try standard username email structure or let firebase check
          email = `${usernameInput.toLowerCase()}@vibedramahub.com`;
        }
      }

      const userCred = await signInWithEmailAndPassword(auth, email, passwordInput);
      
      // Fetch user profile to verify status
      const userDoc = await getDoc(doc(db, 'users', userCred.user.uid));
      if (userDoc.exists()) {
        const profile = userDoc.data() as PlatformUser;
        if (profile.status !== 'active') {
          setAuthError(`Your account has been ${profile.status}. Please contact the administrator.`);
          await signOut(auth);
          return;
        }
      }

      setFailedAttempts(0);
      setAuthSuccess('Welcome back!');
      setUsernameInput('');
      setPasswordInput('');
    } catch (err: any) {
      console.error(err);
      triggerFailedAttempt();
    }
  };

  const triggerFailedAttempt = () => {
    const nextAttempts = failedAttempts + 1;
    setFailedAttempts(nextAttempts);
    if (nextAttempts >= 5) {
      const lockUntil = Date.now() + 2 * 60 * 60 * 1000; // 2 hours
      setLockoutTime(lockUntil);
      setAuthError('Too many failed login attempts. Please try again after 2 hours.');
    } else {
      setAuthError(`Incorrect credentials. You have ${5 - nextAttempts} attempts remaining before a 2-hour lockout.`);
    }
  };

  const handleSignup = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError('');
    setAuthSuccess('');

    if (!fullnameInput || !usernameInput || !emailInput || !passwordInput || !confirmPasswordInput) {
      setAuthError('All fields are required.');
      return;
    }

    if (passwordInput !== confirmPasswordInput) {
      setAuthError('Passwords do not match.');
      return;
    }

    if (registeredUsers.some(u => u.username.toLowerCase() === usernameInput.toLowerCase() || u.email.toLowerCase() === emailInput.toLowerCase())) {
      setAuthError('Username or email is already registered.');
      return;
    }

    try {
      const userCred = await createUserWithEmailAndPassword(auth, emailInput, passwordInput);
      
      // Store user profile in users collection
      const userProfile = {
        id: userCred.user.uid,
        fullname: fullnameInput,
        username: usernameInput,
        email: emailInput,
        status: 'active',
        createdAt: new Date().toISOString().split('T')[0],
        role: 'user'
      };
      
      await setDoc(doc(db, 'users', userCred.user.uid), userProfile);
      setAuthSuccess('Account created! Welcome to VIBEDRAMAHUB.');
      
      // Clear inputs
      setFullnameInput('');
      setConfirmPasswordInput('');
      setUsernameInput('');
      setEmailInput('');
      setPasswordInput('');
    } catch (err: any) {
      console.error(err);
      setAuthError(err.message || 'Signup failed.');
    }
  };

  const handleForgotPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError('');
    setAuthSuccess('');

    if (!emailInput) {
      setAuthError('Please enter your email address.');
      return;
    }

    try {
      await sendPasswordResetEmail(auth, emailInput);
      setAuthSuccess(`A secure reset link has been dispatched to ${emailInput}`);
    } catch (err: any) {
      console.error(err);
      setAuthError(err.message || 'Forgot password failed.');
    }
  };

  const handleLogout = async () => {
    try {
      await signOut(auth);
      setCurrentUser(null);
      safeLocalStorage.removeItem('vibe_user');
      setActiveTab('home');
      showToast('Successfully signed out.', 'info');
    } catch (err: any) {
      console.error(err);
    }
  };

  const handleSaveProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editFullName.trim() || !editUsername.trim() || !currentUser) return;

    const updatedUser = {
      ...currentUser,
      fullname: editFullName.trim(),
      username: editUsername.trim(),
      bio: editBio.trim(),
      photoURL: editPhotoURL.trim(),
    };

    try {
      if (auth.currentUser) {
        const userRef = doc(db, 'users', auth.currentUser.uid);
        await setDoc(userRef, {
          fullname: editFullName.trim(),
          username: editUsername.trim(),
          bio: editBio.trim(),
          photoURL: editPhotoURL.trim(),
        }, { merge: true });
        showToast('Profile saved in Cloud Firestore!', 'success');
      } else {
        safeLocalStorage.setItem('vibe_user', JSON.stringify(updatedUser));
        showToast('Guest profile updated locally!', 'success');
      }
      setCurrentUser(updatedUser);
      setIsEditingProfile(false);
    } catch (err: any) {
      console.error(err);
      showToast('Failed to save profile changes.', 'error');
    }
  };

  const handleAdminLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError('');

    const email = adminUsernameInput.trim();
    if (email.toLowerCase() !== 'rahulgahatraj2007@gmail.com') {
      setAuthError('Unauthorized administrative credentials.');
      showToast('Access denied: Unauthorized admin email.', 'error');
      return;
    }

    try {
      // Try signing in
      const userCred = await signInWithEmailAndPassword(auth, email, adminPasswordInput);
      
      if (userCred.user.email === 'rahulgahatraj2007@gmail.com') {
        const userDoc = await getDoc(doc(db, 'users', userCred.user.uid));
        if (userDoc.exists() && userDoc.data().role === 'admin') {
          setIsAdminLogged(true);
          setActiveTab('admin_dash');
          setAdminUsernameInput('');
          setAdminPasswordInput('');
          showToast('Successfully logged in as Administrator!', 'success');
          return;
        }
      }
      
      // If we authenticated but they don't have the role yet, or not authorized, sign out
      await signOut(auth);
      setAuthError('Invalid administrative credentials or unauthorized account.');
      showToast('Access denied: Not an authorized admin.', 'error');
    } catch (err: any) {
      console.error(err);
      setAuthError('Invalid administrative credentials.');
    }
  };

  const handleGoogleLogin = async () => {
    setAuthError('');
    setAuthSuccess('');

    const provider = new GoogleAuthProvider();
    try {
      const userCred = await signInWithPopup(auth, provider);
      const isUserAdmin = userCred.user.email === 'rahulgahatraj2007@gmail.com';
      
      if (isUserAdmin) {
        setIsAdminLogged(true);
        setActiveTab('admin_dash');
        showToast('Successfully logged in as Administrator via Google!', 'success');
      } else {
        if (activeTab === 'admin_login') {
          setAuthError('This Google account is not registered as an administrator.');
          showToast('Not an Administrator. Access denied to Control Console.', 'error');
          setActiveTab('home');
        } else {
          showToast('Welcome to VIBEDRAMAHUB!', 'success');
        }
      }
      setShowLoginPopup(false);
      if (pendingAction) {
        pendingAction();
        setPendingAction(null);
      }
    } catch (err: any) {
      console.error(err);
      setAuthError(err.message || 'Error logging in with Google');
    }
  };

  const ensureAuthenticated = (action: () => void) => {
    if (auth.currentUser) {
      action();
    } else {
      setPendingAction(() => action);
      setShowLoginPopup(true);
    }
  };

  const formatCount = (num: number): string => {
    if (num >= 1000000) {
      return (num / 1000000).toFixed(1).replace(/\.0$/, '') + 'M';
    }
    if (num >= 1000) {
      return (num / 1000).toFixed(1).replace(/\.0$/, '') + 'K';
    }
    return num.toString();
  };

  const toggleFavorite = async (dramaId: number) => {
    if (!auth.currentUser) {
      ensureAuthenticated(() => toggleFavorite(dramaId));
      return;
    }
    const userId = auth.currentUser.uid;
    const docId = `${dramaId}_${userId}`;
    const docRef = doc(db, 'favorites', docId);
    
    const isFav = allFavorites.some(f => f.dramaId === dramaId && f.userId === userId);
    
    try {
      if (isFav) {
        await deleteDoc(docRef);
        showToast('Removed from Favorites watchlist.', 'info');
      } else {
        await setDoc(docRef, { dramaId, userId });
        showToast('Added to Favorites watchlist!', 'success');
      }
    } catch (err) {
      console.error(err);
      showToast('Failed to update favorites in database.', 'error');
    }
  };

  const toggleLike = async (dramaId: number) => {
    if (!auth.currentUser) {
      ensureAuthenticated(() => toggleLike(dramaId));
      return;
    }
    const userId = auth.currentUser.uid;
    const docId = `${dramaId}_${userId}`;
    const docRef = doc(db, 'likes', docId);
    
    const hasLiked = allLikes.some(l => l.dramaId === dramaId && l.userId === userId);
    
    try {
      if (hasLiked) {
        await deleteDoc(docRef);
        showToast('Removed like from drama.', 'info');
      } else {
        await setDoc(docRef, { dramaId, userId });
        showToast('Drama liked!', 'success');
      }
    } catch (err) {
      console.error(err);
      showToast('Failed to update likes in database.', 'error');
    }
  };

  const submitRating = async (dramaId: number, ratingVal: number) => {
    if (!auth.currentUser) {
      ensureAuthenticated(() => submitRating(dramaId, ratingVal));
      return;
    }
    
    // Validate range and precision
    const roundedRating = Math.round(ratingVal * 10) / 10;
    if (roundedRating < 1.0 || roundedRating > 10.0) {
      showToast('Ratings must be between 1.0 and 10.0 only.', 'error');
      return;
    }

    const userId = auth.currentUser.uid;
    const docId = `${dramaId}_${userId}`;
    const docRef = doc(db, 'ratings', docId);
    
    setIsSavingRating(true);
    setRatingSaveSuccess(false);

    try {
      await setDoc(docRef, {
        dramaId: Number(dramaId),
        userId,
        rating: roundedRating,
        createdAt: new Date().toISOString()
      });
      setIsSavingRating(false);
      setRatingSaveSuccess(true);
      showToast(`Your rating of ${roundedRating.toFixed(1)}/10.0 has been saved!`, 'success');
      setTimeout(() => setRatingSaveSuccess(false), 4000);
    } catch (err) {
      console.error(err);
      setIsSavingRating(false);
      showToast('Failed to save your rating.', 'error');
    }
  };

  const submitProfileRating = async (dramaId: number, ratingVal: number) => {
    if (!auth.currentUser) return;
    
    // Validate range and precision
    const roundedRating = Math.round(ratingVal * 10) / 10;
    if (roundedRating < 1.0 || roundedRating > 10.0) {
      showToast('Ratings must be between 1.0 and 10.0 only.', 'error');
      return;
    }

    const userId = auth.currentUser.uid;
    const docId = `${dramaId}_${userId}`;
    const docRef = doc(db, 'ratings', docId);
    
    setIsSavingProfileRating(true);

    try {
      await setDoc(docRef, {
        dramaId: Number(dramaId),
        userId,
        rating: roundedRating,
        createdAt: new Date().toISOString()
      });
      setIsSavingProfileRating(false);
      setEditingProfileRatingId(null);
      showToast(`Rating updated to ${roundedRating.toFixed(1)}/10.0 successfully!`, 'success');
    } catch (err) {
      console.error(err);
      setIsSavingProfileRating(false);
      showToast('Failed to update rating.', 'error');
    }
  };

  const purgeLegacyRatings = async () => {
    if (!auth.currentUser || auth.currentUser.email !== 'rahulgahatraj2007@gmail.com') {
      showToast('Unauthorized: Only the system Administrator can initiate a database maintenance purge.', 'error');
      return;
    }

    if (!window.confirm('Are you sure you want to perform database maintenance? This will permanently delete all legacy, invalid, out-of-range (not 1.0 - 10.0), or duplicate ratings from Cloud Firestore.')) {
      return;
    }

    setIsPurgingRatings(true);
    showToast('Scanning Cloud Firestore ratings collection...', 'info');

    try {
      let deletedCount = 0;
      // Get all invalid ratings
      // Since ratings is kept updated in state by our real-time listener, we can find the invalid ones directly:
      const invalidRatings = ratings.filter(r => {
        const isOutOfRange = r.rating < 1.0 || r.rating > 10.0;
        const isOrphaned = !dramas.some(d => d.id === r.dramaId);
        const isMalformed = r.rating === undefined || r.rating === null || isNaN(r.rating);
        return isOutOfRange || isOrphaned || isMalformed;
      });

      if (invalidRatings.length === 0) {
        showToast('Database is already clean! No invalid, legacy, or fake rating records were detected.', 'success');
        setIsPurgingRatings(false);
        return;
      }

      // Loop and delete each from Firestore
      for (const rating of invalidRatings) {
        const docId = `${rating.dramaId}_${rating.userId}`;
        const docRef = doc(db, 'ratings', docId);
        await deleteDoc(docRef);
        deletedCount++;
      }

      showToast(`Database maintenance completed successfully! Deleted ${deletedCount} legacy rating documents.`, 'success');
    } catch (err) {
      console.error(err);
      showToast('Database maintenance failed. Check console for permission logs.', 'error');
    } finally {
      setIsPurgingRatings(false);
    }
  };

  const handleAdminLogout = async () => {
    try {
      await signOut(auth);
      setIsAdminLogged(false);
      setActiveTab('home');
      showToast('Admin session terminated successfully.', 'info');
    } catch (err: any) {
      console.error(err);
    }
  };

  const toggleFavoriteLocal = async (dramaId: number) => {
    if (auth.currentUser) {
      await toggleFavorite(dramaId);
    } else {
      setFavorites(prev => {
        if (prev.includes(dramaId)) {
          const updated = prev.filter(id => id !== dramaId);
          safeLocalStorage.setItem('vibe_favorites', JSON.stringify(updated));
          return updated;
        } else {
          const updated = [...prev, dramaId];
          safeLocalStorage.setItem('vibe_favorites', JSON.stringify(updated));
          return updated;
        }
      });
      showToast('Updated local favorites list!', 'success');
    }
  };

  const createPlaylistLocal = (e: React.FormEvent) => {
    e.preventDefault();
    if (!activePlaylistInput.trim()) return;

    const newPlaylist: Playlist = {
      id: playlists.length + 1,
      name: activePlaylistInput,
      isPrivate: activePlaylistPrivate,
      dramaIds: []
    };

    setPlaylists(prev => [...prev, newPlaylist]);
    setActivePlaylistInput('');
  };

  const deletePlaylistLocal = (id: number) => {
    if (confirm('Delete this playlist permanently?')) {
      setPlaylists(prev => prev.filter(p => p.id !== id));
    }
  };

  const toggleDramaInPlaylist = (playlistId: number, dramaId: number) => {
    setPlaylists(prev => prev.map(p => {
      if (p.id === playlistId) {
        const alreadyIn = p.dramaIds.includes(dramaId);
        return {
          ...p,
          dramaIds: alreadyIn ? p.dramaIds.filter(id => id !== dramaId) : [...p.dramaIds, dramaId]
        };
      }
      return p;
    }));
  };

  const updateWatchProgressLocal = (dramaId: number, episodeId: number, progress: number, completed: boolean) => {
    setWatchHistory(prev => {
      const existingIndex = prev.findIndex(item => item.dramaId === dramaId && item.episodeId === episodeId);
      const updated = [...prev];
      const newItem: WatchHistoryItem = {
        dramaId,
        episodeId,
        progressSeconds: progress,
        completed,
        updatedAt: new Date().toISOString()
      };

      if (existingIndex !== -1) {
        updated[existingIndex] = newItem;
      } else {
        updated.unshift(newItem);
      }
      return updated;
    });
  };

  const handleAddReview = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newReviewText.trim() || !selectedDrama || !currentUser) return;

    const newReview: Review = {
      dramaId: selectedDrama.id,
      username: currentUser.username,
      fullname: currentUser.fullname,
      text: newReviewText,
      rating: newReviewRating,
      createdAt: new Date().toISOString().split('T')[0]
    };

    try {
      await addDoc(collection(db, 'reviews'), newReview);
      setNewReviewText('');
      showToast('Your review has been published!', 'success');
    } catch (err: any) {
      console.error(err);
      showToast('Failed to post review: ' + err.message, 'error');
    }
  };

  // Admin Edit and Create Dramas
  const handleSaveDramaAdmin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!adminDramaTitle || !adminDramaDesc || !adminDramaPoster || !adminDramaBanner || !adminDramaGenre || !adminDramaCountry || !adminDramaCast) {
      showToast('All primary metadata fields are required.', 'error');
      return;
    }

    const targetId = selectedDramaToEdit !== null 
      ? selectedDramaToEdit 
      : (dramas.length > 0 ? Math.max(...dramas.map(d => d.id)) + 1 : 1);

    const existingDrama = dramas.find(d => d.id === targetId);
    const dramaData: Drama = {
      id: targetId,
      title: adminDramaTitle,
      description: adminDramaDesc,
      poster_url: adminDramaPoster,
      banner_url: adminDramaBanner,
      trailer_url: adminDramaTrailer,
      genre: adminDramaGenre,
      country: adminDramaCountry,
      release_year: Number(adminDramaYear),
      status: adminDramaStatus,
      cast: adminDramaCast,
      download_url: adminDramaDownloadUrl || '',
      createdAt: existingDrama?.createdAt || new Date().toISOString()
    };

    try {
      await setDoc(doc(db, 'dramas', String(targetId)), dramaData);
      if (selectedDramaToEdit !== null) {
        showToast('Drama record updated successfully!', 'success');
        setSelectedDramaToEdit(null);
      } else {
        // Publish real-time notification
        await addDoc(collection(db, 'notifications'), {
          title: adminDramaTitle,
          description: `New ${adminDramaGenre} drama added to catalog!`,
          createdAt: new Date().toISOString()
        });
        showToast('New drama successfully cataloged into the database!', 'success');
      }

      // Reset Form
      setAdminDramaTitle('');
      setAdminDramaDesc('');
      setAdminDramaPoster('');
      setAdminDramaBanner('');
      setAdminDramaTrailer('');
      setAdminDramaGenre('');
      setAdminDramaCountry('');
      setAdminDramaYear(2026);
      setAdminDramaStatus('Ongoing');
      setAdminDramaCast('');
      setAdminDramaDownloadUrl('');
    } catch (err: any) {
      console.error(err);
      showToast('Error saving drama: ' + err.message, 'error');
    }
  };

  const handleEditDramaAdminClick = (drama: Drama) => {
    setSelectedDramaToEdit(drama.id);
    setAdminDramaTitle(drama.title);
    setAdminDramaDesc(drama.description);
    setAdminDramaPoster(drama.poster_url);
    setAdminDramaBanner(drama.banner_url);
    setAdminDramaTrailer(drama.trailer_url);
    setAdminDramaGenre(drama.genre);
    setAdminDramaCountry(drama.country);
    setAdminDramaYear(drama.release_year);
    setAdminDramaStatus(drama.status);
    setAdminDramaCast(drama.cast);
    setAdminDramaDownloadUrl(drama.download_url || '');
  };

  const handleDeleteDramaAdmin = async (id: number) => {
    if (confirm('Are you sure you want to delete this drama and all associated episodes?')) {
      try {
        await deleteDoc(doc(db, 'dramas', String(id)));
        
        // Delete associated episodes
        const q = query(collection(db, 'episodes'), where('drama_id', '==', id));
        const snapshot = await getDocs(q);
        snapshot.forEach(async (document) => {
          await deleteDoc(doc(db, 'episodes', document.id));
        });

        showToast('Drama and its episodes deleted successfully!', 'success');
      } catch (err: any) {
        console.error(err);
        showToast('Failed to delete drama: ' + err.message, 'error');
      }
    }
  };

  const handleSaveEpisodeAdmin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!adminEpTitle || !adminEpUrl) {
      showToast('Title and Streamtape URL are required.', 'error');
      return;
    }

    let finalUrl = adminEpUrl;
    const match = adminEpUrl.match(/\/(v|e)\/([a-zA-Z0-9_-]+)/);
    if (match && match[2]) {
      finalUrl = 'https://streamtape.com/e/' + match[2];
    }

    const targetId = adminEpEditId !== null 
      ? adminEpEditId 
      : (episodes.length > 0 ? Math.max(...episodes.map(ep => ep.id)) + 1 : 1);

    const episodeData: Episode = {
      id: targetId,
      drama_id: Number(adminEpDramaId),
      episode_number: Number(adminEpNumber),
      title: adminEpTitle,
      streamtape_url: finalUrl,
      download_url: adminEpDownloadUrl || '',
      createdAt: new Date().toISOString()
    };

    try {
      await setDoc(doc(db, 'episodes', String(targetId)), episodeData);
      if (adminEpEditId !== null) {
        showToast('Episode successfully updated and replaced!', 'success');
        setAdminEpEditId(null);
      } else {
        const associatedDrama = dramas.find(d => d.id === Number(adminEpDramaId));
        const dramaTitle = associatedDrama ? associatedDrama.title : 'Catalog';
        // Publish real-time notification
        await addDoc(collection(db, 'notifications'), {
          title: `${dramaTitle} - Episode ${adminEpNumber}`,
          description: adminEpTitle ? `Now streaming: "${adminEpTitle}"` : `New episode added!`,
          createdAt: new Date().toISOString()
        });
        showToast('Episode successfully compiled into streaming slot!', 'success');
      }

      setAdminEpTitle('');
      setAdminEpUrl('');
      setAdminEpDownloadUrl('');
      setPastedStreamtapeUrl('');
      setAdminEpNumber(prev => prev + 1);
    } catch (err: any) {
      console.error(err);
      showToast('Failed to save episode: ' + err.message, 'error');
    }
  };

  const handleEditEpisodeClick = (ep: Episode) => {
    setAdminEpEditId(ep.id);
    setAdminEpDramaId(ep.drama_id);
    setAdminEpNumber(ep.episode_number);
    setAdminEpTitle(ep.title);
    setAdminEpUrl(ep.streamtape_url);
    setPastedStreamtapeUrl(ep.streamtape_url);
    setAdminEpDownloadUrl(ep.download_url || '');
  };

  const handleDeleteEpisodeClick = async (id: number) => {
    if (confirm('Delete this episode streamnode record?')) {
      try {
        await deleteDoc(doc(db, 'episodes', String(id)));
        showToast('Episode deleted successfully!', 'success');
        if (adminEpEditId === id) {
          setAdminEpEditId(null);
          setAdminEpTitle('');
          setAdminEpUrl('');
          setAdminEpDownloadUrl('');
          setPastedStreamtapeUrl('');
        }
      } catch (err: any) {
        console.error(err);
        showToast('Failed to delete episode: ' + err.message, 'error');
      }
    }
  };

  const handleAdminToggleUserStatus = async (userId: string | number, currentStatus: 'active' | 'suspended' | 'banned') => {
    let nextStatus: 'active' | 'suspended' | 'banned' = 'active';
    if (currentStatus === 'active') nextStatus = 'suspended';
    else if (currentStatus === 'suspended') nextStatus = 'banned';

    try {
      await setDoc(doc(db, 'users', String(userId)), { status: nextStatus }, { merge: true });
      showToast(`User status updated to ${nextStatus}!`, 'success');
    } catch (err: any) {
      console.error(err);
      showToast('Failed to update user status.', 'error');
    }
  };

  const handleAdminDeleteUser = async (userId: string | number) => {
    if (confirm('Delete this user account permanently?')) {
      try {
        await deleteDoc(doc(db, 'users', String(userId)));
        showToast('User deleted successfully!', 'success');
      } catch (err: any) {
        console.error(err);
        showToast('Failed to delete user.', 'error');
      }
    }
  };

  // Firebase Storage Upload Handlers
  const handlePosterUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    
    // Check if it's an image
    if (!file.type.startsWith('image/')) {
      showToast('Please select a valid image file.', 'error');
      return;
    }

    setPosterUploading(true);
    setPosterProgress(0);

    const storageRef = ref(storage, `posters/${Date.now()}_${file.name}`);
    const uploadTask = uploadBytesResumable(storageRef, file);

    uploadTask.on('state_changed', 
      (snapshot) => {
        const progress = Math.round((snapshot.bytesTransferred / snapshot.totalBytes) * 100);
        setPosterProgress(progress);
      }, 
      (error) => {
        console.error('Poster upload failed:', error);
        showToast(`Poster upload failed: ${error.message}`, 'error');
        setPosterUploading(false);
      }, 
      () => {
        getDownloadURL(uploadTask.snapshot.ref).then((downloadURL) => {
          // Document metadata in Firestore so it lists in our Media Library
          addDoc(collection(db, 'storage_files'), {
            name: file.name,
            url: downloadURL,
            size: `${(file.size / 1024).toFixed(1)} KB`,
            type: file.type,
            uploadedAt: new Date().toISOString()
          }).catch(err => console.error("Error logging poster metadata:", err));

          setAdminDramaPoster(downloadURL);
          setPosterUploading(false);
          showToast('Poster image successfully uploaded to Firebase Storage!', 'success');
        });
      }
    );
  };

  const handleBannerUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Check if it's an image
    if (!file.type.startsWith('image/')) {
      showToast('Please select a valid image file.', 'error');
      return;
    }

    setBannerUploading(true);
    setBannerProgress(0);

    const storageRef = ref(storage, `banners/${Date.now()}_${file.name}`);
    const uploadTask = uploadBytesResumable(storageRef, file);

    uploadTask.on('state_changed', 
      (snapshot) => {
        const progress = Math.round((snapshot.bytesTransferred / snapshot.totalBytes) * 100);
        setBannerProgress(progress);
      }, 
      (error) => {
        console.error('Banner upload failed:', error);
        showToast(`Banner upload failed: ${error.message}`, 'error');
        setBannerUploading(false);
      }, 
      () => {
        getDownloadURL(uploadTask.snapshot.ref).then((downloadURL) => {
          // Document metadata in Firestore so it lists in our Media Library
          addDoc(collection(db, 'storage_files'), {
            name: file.name,
            url: downloadURL,
            size: `${(file.size / 1024).toFixed(1)} KB`,
            type: file.type,
            uploadedAt: new Date().toISOString()
          }).catch(err => console.error("Error logging banner metadata:", err));

          setAdminDramaBanner(downloadURL);
          setBannerUploading(false);
          showToast('Banner image successfully uploaded to Firebase Storage!', 'success');
        });
      }
    );
  };

  // Streamtape Remote Upload Actions
  const handleStartRemoteUpload = (e: React.FormEvent) => {
    e.preventDefault();
    if (!uploadUrl || !uploadCustomName) {
      showToast('Video Source URL and Custom Filename are required.', 'error');
      return;
    }

    if (!streamtapeLogin || !streamtapeKey) {
      showToast('Please configure and save your Streamtape API credentials in the settings panel first.', 'error');
      return;
    }

    const selectedDramaObj = dramas.find(d => d.id === uploadDramaId);
    const dramaTitle = selectedDramaObj ? selectedDramaObj.title : 'Unknown Drama';

    const newJob = {
      id: 'job_' + Date.now(),
      drama_id: uploadDramaId,
      drama_title: dramaTitle,
      season_number: uploadSeason,
      episode_number: uploadEpisode,
      custom_name: uploadCustomName,
      source_url: uploadUrl,
      folder_id: uploadFolderId,
      status: 'pending',
      progress: 0,
      created_at: new Date().toISOString()
    };

    setUploadQueue(prev => [newJob, ...prev]);
    setUploadUrl('');
    setUploadCustomName('');
    showToast('Remote upload task successfully added to Streamtape pipeline (Simulated/Local Cache)!', 'success');
  };

  const handleRetryUpload = (jobId: string) => {
    setUploadQueue(prev => prev.map(job => {
      if (job.id === jobId) {
        return {
          ...job,
          status: 'pending',
          progress: 0,
          error_message: undefined,
          file_id: undefined,
          embed_url: undefined
        };
      }
      return job;
    }));
  };

  const handleCancelUpload = (jobId: string) => {
    setUploadQueue(prev => prev.map(job => {
      if (job.id === jobId) {
        return {
          ...job,
          status: 'failed',
          error_message: 'Upload canceled by administrator.'
        };
      }
      return job;
    }));
  };

  const handleDeleteUpload = (jobId: string) => {
    if (confirm('Are you sure you want to clear this upload record?')) {
      setUploadQueue(prev => prev.filter(job => job.id !== jobId));
    }
  };



  // Filter dramas based on query and selected genre
  const filteredDramas = useMemo(() => {
    let list = [...dramas];

    if (searchQuery) {
      list = list.filter(d => 
        d.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        d.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
        d.cast.toLowerCase().includes(searchQuery.toLowerCase()) ||
        d.country.toLowerCase().includes(searchQuery.toLowerCase())
      );
    }

    if (selectedGenre) {
      list = list.filter(d => d.genre.toLowerCase().includes(selectedGenre.toLowerCase()));
    }

    return list;
  }, [dramas, searchQuery, selectedGenre]);

  // Calculate average rating for selected drama
  const getAverageRating = (dramaId: number) => {
    const dramaRatings = ratings.filter(r => r.dramaId === dramaId);
    if (dramaRatings.length > 0) {
      const sum = dramaRatings.reduce((acc, r) => acc + r.rating, 0);
      return (sum / dramaRatings.length).toFixed(1);
    }
    return '0.0';
  };



  return (
    <div className="min-h-screen bg-[#05050a] text-white flex flex-col font-sans select-none overflow-x-hidden relative">
      
      {/* Cinematic Opening Animation Intro */}
      {showIntro && (
        <CinematicIntro onComplete={() => {
          setShowIntro(false);
          safeSessionStorage.setItem('vibe_intro_watched', 'true');
        }} />
      )}

      {/* --------------------------------------------------------
          SIGN UP / SIGN IN DIALOG (BLOCKED VISITOR SHIELD)
          -------------------------------------------------------- */}
      {authLoading ? (
        <div className="flex-1 flex flex-col items-center justify-center bg-[#05050a] relative z-50">
          <div className="text-center">
            <h1 className="text-4xl font-bold tracking-tighter bg-gradient-to-r from-purple-500 to-blue-500 bg-clip-text text-transparent uppercase mb-4 animate-pulse">VIBEDRAMAHUB</h1>
            <div className="flex items-center justify-center gap-3">
              <RotateCw className="w-5 h-5 text-purple-500 animate-spin" />
              <span className="text-gray-400 font-mono text-xs tracking-wider uppercase">Verifying Administrator Session...</span>
            </div>
          </div>
        </div>
      ) : (
        <>
          {!currentUser && (
        <div className="flex-1 flex items-center justify-center py-12 px-4 relative z-40 bg-[#05050a]">
          <div className="absolute inset-0 opacity-10 pointer-events-none" style={{ backgroundImage: "url('https://images.unsplash.com/photo-1517604931442-7e0c8ed2963c?q=80&w=1200')", backgroundSize: 'cover', backgroundPosition: 'center' }}></div>
          
          <div className="w-full max-w-md relative">
            <div className="text-center mb-6">
              <h1 className="text-4xl font-bold tracking-tighter bg-gradient-to-r from-purple-500 to-blue-500 bg-clip-text text-transparent uppercase">VIBEDRAMAHUB</h1>
              <p className="text-[#9ea2c0] text-xs font-mono tracking-widest mt-1">STREAMING REDEFINED • MEMORY EXCLUSIVE</p>
            </div>

            <div className="bg-[#0a0a14]/65 border border-white/8 backdrop-blur-2xl rounded-2xl p-8 shadow-2xl relative">
              
              {/* Failed attempts Warning */}
              {lockoutTime && lockoutTime > Date.now() ? (
                <div className="text-center py-6">
                  <ShieldAlert className="w-12 h-12 text-red-500 mx-auto mb-4 animate-bounce" />
                  <h3 className="text-lg font-bold text-red-500 mb-2">Login Locked Out</h3>
                  <p className="text-sm text-gray-400 mb-4">Too many failed login attempts. Please try again after 2 hours.</p>
                  <div className="font-mono text-xs text-blue-400 bg-blue-500/10 py-1.5 px-3 rounded-full inline-block">
                    Unlocks in: {lockoutRemaining}
                  </div>
                </div>
              ) : (
                <>
                  <h2 className="text-xl font-bold text-white mb-6 text-center">
                    {authMode === 'login' ? 'Sign In to Stream' : authMode === 'signup' ? 'Create Your Account' : 'Recover Account'}
                  </h2>

                  {authError && (
                    <div className="bg-red-500/10 border border-red-500/25 text-red-400 p-3 rounded-lg text-xs text-center mb-4 flex items-center justify-center gap-1.5">
                      <ShieldAlert className="w-4 h-4 shrink-0" />
                      <span>{authError}</span>
                    </div>
                  )}

                  {authSuccess && (
                    <div className="bg-green-500/10 border border-green-500/25 text-green-400 p-3 rounded-lg text-xs text-center mb-4 flex items-center justify-center gap-1.5">
                      <CheckCircle2 className="w-4 h-4 shrink-0" />
                      <span>{authSuccess}</span>
                    </div>
                  )}

                  <form onSubmit={authMode === 'login' ? handleLogin : authMode === 'signup' ? handleSignup : handleForgotPassword} className="space-y-4">
                    {authMode === 'signup' && (
                      <div>
                        <label className="block text-xs text-gray-400 mb-1.5 font-medium">Full Name</label>
                        <input 
                          type="text" 
                          required 
                          value={fullnameInput}
                          onChange={e => setFullnameInput(e.target.value)}
                          className="w-full bg-white/4 border border-white/8 rounded-xl px-4 py-3 text-sm text-white focus:outline-none focus:border-purple-600 transition" 
                          placeholder="Jane Doe"
                        />
                      </div>
                    )}

                    <div>
                      <label className="block text-xs text-gray-400 mb-1.5 font-medium">
                        {authMode === 'signup' ? 'Username' : 'Username or Email'}
                      </label>
                      <input 
                        type="text" 
                        required 
                        value={usernameInput}
                        onChange={e => setUsernameInput(e.target.value)}
                        className="w-full bg-white/4 border border-white/8 rounded-xl px-4 py-3 text-sm text-white focus:outline-none focus:border-purple-600 transition" 
                        placeholder={authMode === 'signup' ? 'janedoe99' : ''}
                      />
                    </div>

                    {authMode === 'signup' && (
                      <div>
                        <label className="block text-xs text-gray-400 mb-1.5 font-medium">Email Address</label>
                        <input 
                          type="email" 
                          required 
                          value={emailInput}
                          onChange={e => setEmailInput(e.target.value)}
                          className="w-full bg-white/4 border border-white/8 rounded-xl px-4 py-3 text-sm text-white focus:outline-none focus:border-purple-600 transition" 
                          placeholder="jane@example.com"
                        />
                      </div>
                    )}

                    {authMode !== 'forgot' && (
                      <div className="grid grid-cols-1 gap-4">
                        <div>
                          <label className="block text-xs text-gray-400 mb-1.5 font-medium">Password</label>
                          <input 
                            type="password" 
                            required 
                            value={passwordInput}
                            onChange={e => setPasswordInput(e.target.value)}
                            className="w-full bg-white/4 border border-white/8 rounded-xl px-4 py-3 text-sm text-white focus:outline-none focus:border-purple-600 transition" 
                            placeholder="••••••"
                          />
                        </div>
                        {authMode === 'signup' && (
                          <div>
                            <label className="block text-xs text-gray-400 mb-1.5 font-medium">Confirm Password</label>
                            <input 
                              type="password" 
                              required 
                              value={confirmPasswordInput}
                              onChange={e => setConfirmPasswordInput(e.target.value)}
                              className="w-full bg-white/4 border border-white/8 rounded-xl px-4 py-3 text-sm text-white focus:outline-none focus:border-purple-600 transition" 
                              placeholder="••••••"
                            />
                          </div>
                        )}
                      </div>
                    )}

                    {authMode === 'login' && (
                      <div className="flex items-center justify-between text-xs">
                        <label className="flex items-center gap-1.5 text-gray-400 cursor-pointer">
                          <input 
                            type="checkbox" 
                            checked={rememberMe}
                            onChange={e => setRememberMe(e.target.checked)}
                            className="accent-purple-600 rounded" 
                          />
                          <span>Remember Me</span>
                        </label>
                        <button 
                          type="button"
                          onClick={() => setAuthMode('forgot')}
                          className="text-blue-400 hover:underline"
                        >
                          Forgot Password?
                        </button>
                      </div>
                    )}

                    <button 
                      type="submit"
                      className="w-full bg-gradient-to-r from-purple-600 to-blue-600 text-white py-3 rounded-xl font-semibold text-sm hover:opacity-90 transition shadow-lg shadow-purple-600/20 cursor-pointer"
                    >
                      {authMode === 'login' ? 'Sign In' : authMode === 'signup' ? 'Create Account' : 'Send Instructions'}
                    </button>

                    {authMode === 'login' && (
                      <div className="flex items-center my-3 text-xs text-gray-500">
                        <div className="flex-1 border-t border-white/5"></div>
                        <span className="px-3 uppercase tracking-wider text-[10px]">Or</span>
                        <div className="flex-1 border-t border-white/5"></div>
                      </div>
                    )}

                    {authMode === 'login' && (
                      <button 
                        type="button"
                        onClick={handleGoogleLogin}
                        className="w-full bg-white text-black hover:bg-gray-100 py-3 rounded-xl font-semibold text-sm transition cursor-pointer flex items-center justify-center gap-2 shadow-lg"
                      >
                        <svg className="w-4 h-4" viewBox="0 0 24 24">
                          <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4"/>
                          <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/>
                          <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z" fill="#FBBC05"/>
                          <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z" fill="#EA4335"/>
                        </svg>
                        <span>Sign In with Google</span>
                      </button>
                    )}

                    {authMode === 'login' && (
                      <button 
                        type="button"
                        onClick={() => {
                          const demoUser = registeredUsers[1] || { id: 2, fullname: 'John Doe', username: 'johndoe', email: 'john@example.com', status: 'active', createdAt: '2026-06-15' };
                          setCurrentUser(demoUser);
                          setAuthSuccess('Successfully entered as guest!');
                        }}
                        className="w-full bg-white/5 border border-white/10 text-white py-2.5 rounded-xl font-semibold text-xs mt-2 hover:bg-white/10 transition cursor-pointer flex items-center justify-center gap-1.5"
                      >
                        ⚡ Bypass Sign In / Enter as Guest
                      </button>
                    )}
                  </form>

                  <div className="mt-6 pt-6 border-t border-white/5 text-center text-xs text-gray-400">
                    {authMode === 'login' ? (
                      <span>New to VIBEDRAMAHUB? <button type="button" onClick={() => setAuthMode('signup')} className="text-blue-400 font-semibold hover:underline">Register Now</button></span>
                    ) : (
                      <span>Back to <button type="button" onClick={() => setAuthMode('login')} className="text-blue-400 font-semibold hover:underline">Sign In</button></span>
                    )}
                  </div>
                </>
              )}
            </div>
            
            {/* Quick Helper Banner */}
            <div className="mt-4 p-3 bg-white/4 border border-white/5 rounded-xl text-[11px] text-gray-400 text-center">
              💡 <strong>Developer Hint:</strong> Register with any details to create a virtual profile. Password is <code>123456</code>.
            </div>
          </div>
        </div>
      )}

      {/* --------------------------------------------------------
          MAIN STREAM PORTAL (IF LOGGED IN)
          -------------------------------------------------------- */}
      {currentUser && (
        <div className="flex-1 flex flex-col">
          
          {/* NAVIGATION BAR */}
          <nav className="bg-[#05050a]/80 sticky top-0 backdrop-blur-md border-b border-white/5 px-6 py-4 flex items-center justify-between z-30">
            <div className="flex items-center gap-8">
              <button 
                onClick={() => { setActiveTab('home'); setSelectedDrama(null); }}
                className="text-2xl font-bold tracking-tighter bg-gradient-to-r from-purple-500 to-blue-500 bg-clip-text text-transparent uppercase cursor-pointer"
              >
                VIBEDRAMAHUB
              </button>
              
              <div className="hidden lg:flex items-center gap-6 text-sm text-[#9ea2c0]">
                <button 
                  onClick={() => { setActiveTab('home'); setSelectedGenre(''); setSelectedDrama(null); setSelectedEpisode(null); }}
                  className={`hover:text-white transition cursor-pointer ${activeTab === 'home' && !selectedGenre ? 'text-white font-medium' : ''}`}
                >
                  Home
                </button>
                <button 
                  onClick={() => { setActiveTab('home'); setSelectedGenre('Romance'); setSelectedDrama(null); setSelectedEpisode(null); }}
                  className={`hover:text-white transition cursor-pointer ${selectedGenre === 'Romance' ? 'text-white font-medium' : ''}`}
                >
                  Romance
                </button>
                <button 
                  onClick={() => { setActiveTab('home'); setSelectedGenre('Comedy'); setSelectedDrama(null); setSelectedEpisode(null); }}
                  className={`hover:text-white transition cursor-pointer ${selectedGenre === 'Comedy' ? 'text-white font-medium' : ''}`}
                >
                  Comedy
                </button>
                <button 
                  onClick={() => { setActiveTab('home'); setSelectedGenre('Action'); setSelectedDrama(null); setSelectedEpisode(null); }}
                  className={`hover:text-white transition cursor-pointer ${selectedGenre === 'Action' ? 'text-white font-medium' : ''}`}
                >
                  Action
                </button>
                <button 
                  onClick={() => { setActiveTab('home'); setSelectedGenre('Mystery'); setSelectedDrama(null); setSelectedEpisode(null); }}
                  className={`hover:text-white transition cursor-pointer ${selectedGenre === 'Mystery' ? 'text-white font-medium' : ''}`}
                >
                  Mystery
                </button>
                <button 
                  onClick={() => { setActiveTab('playlists'); setSelectedDrama(null); setSelectedEpisode(null); }}
                  className={`hover:text-white transition cursor-pointer ${activeTab === 'playlists' ? 'text-white font-medium' : ''}`}
                >
                  My Playlists
                </button>
                <button 
                  onClick={() => { setActiveTab('mylist'); setSelectedDrama(null); setSelectedEpisode(null); }}
                  className={`hover:text-white transition cursor-pointer ${activeTab === 'mylist' ? 'text-white font-medium' : ''}`}
                >
                  My List
                </button>

                {auth.currentUser ? (
                  <button 
                    onClick={() => {
                      setEditFullName(currentUser.fullname || '');
                      setEditUsername(currentUser.username || '');
                      setEditBio(currentUser.bio || '');
                      setEditPhotoURL(currentUser.photoURL || '');
                      setSelectedDrama(null);
                      setSelectedEpisode(null);
                      setActiveTab('profile');
                    }}
                    className={`hover:text-white transition cursor-pointer ${activeTab === 'profile' ? 'text-white font-medium' : ''}`}
                  >
                    Profile
                  </button>
                ) : (
                  <button 
                    onClick={handleGoogleLogin}
                    className="flex items-center gap-1.5 bg-gradient-to-r from-red-600 to-amber-600 hover:opacity-95 text-white font-bold px-3 py-1.5 rounded-full text-xs transition active:scale-95 cursor-pointer shadow-md shadow-red-900/10"
                  >
                    <svg className="w-3 h-3" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                      <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#FFFFFF"/>
                      <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#FFFFFF"/>
                      <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z" fill="#FFFFFF"/>
                      <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z" fill="#FFFFFF"/>
                    </svg>
                    <span>Sign In with Google</span>
                  </button>
                )}
              </div>
            </div>

            <div className="flex items-center gap-4">
              {/* Mobile Menu Hamburger Button */}
              <button 
                onClick={() => {
                  setShowMobileMenu(!showMobileMenu);
                  setShowMobileSearch(false);
                }}
                className="lg:hidden p-2 rounded-full text-gray-300 hover:text-white hover:bg-white/5 transition-all cursor-pointer"
                title="Toggle Menu"
                aria-label="Toggle Menu"
              >
                {showMobileMenu ? <X className="w-5 h-5 text-purple-400" /> : <Menu className="w-5 h-5" />}
              </button>

              {/* Mobile Search Toggle Button */}
              <button 
                onClick={() => {
                  setShowMobileSearch(!showMobileSearch);
                  setShowMobileMenu(false);
                }}
                className={`md:hidden p-2 rounded-full text-gray-300 hover:text-white hover:bg-white/5 transition-all cursor-pointer ${showMobileSearch ? 'bg-white/8 text-purple-400' : ''}`}
                title="Search Dramas"
                aria-label="Search Dramas"
              >
                <Search className="w-5 h-5" />
              </button>

              {/* Dynamic search input with AI smart search toggle */}
              <div className="items-center gap-2 hidden md:flex">
                <div className="relative">
                  <input 
                    type="text"
                    placeholder="Search dramas..."
                    value={searchQuery}
                    onChange={e => setSearchQuery(e.target.value)}
                    className="bg-white/4 border border-white/8 rounded-full py-1.5 pl-9 pr-10 text-xs text-white focus:outline-none transition-all duration-300 w-44 focus:w-64 focus:border-purple-500"
                    aria-label="Search Dramas Input"
                  />
                  <Search className="w-3.5 h-3.5 absolute left-3 top-2.5 text-[#9ea2c0]" />
                  {searchQuery && (
                    <button onClick={clearSearch} aria-label="Clear Search" className="absolute right-3 top-2.5 text-gray-400 hover:text-white">
                      <X className="w-3 h-3" />
                    </button>
                  )}
                </div>
              </div>

              {/* Online Users Count */}
              <div className="flex items-center gap-1.5 bg-[#05050a]/60 border border-white/8 px-3 py-1.5 rounded-full text-[11px] text-green-400 font-semibold shadow-inner">
                <span className="relative flex h-2 w-2">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-2 w-2 bg-green-500"></span>
                </span>
                <span className="font-mono">{onlineCount} Online</span>
              </div>

              {/* Notifications bell */}
              <div className="relative group cursor-pointer p-1">
                <Bell className="w-5 h-5 text-gray-300" />
                {notifications.length > 0 && (
                  <span className="absolute -top-1 -right-1 w-4 h-4 bg-red-500 rounded-full text-[9px] font-bold text-white flex items-center justify-center shadow-lg border border-[#05050a]">
                    {notifications.length > 9 ? '9+' : notifications.length}
                  </span>
                )}
                <div className="absolute right-0 top-full mt-2 w-72 bg-[#0a0a14] border border-white/8 rounded-xl p-3 shadow-xl hidden group-hover:block text-xs space-y-2 z-50">
                  <div className="font-bold border-b border-white/5 pb-1.5 flex items-center justify-between">
                    <span>New Stream Notifications</span>
                    <span className="text-[10px] text-gray-500 font-normal">{notifications.length} total</span>
                  </div>
                  {notifications.length === 0 ? (
                    <div className="text-center text-gray-500 py-3 text-[11px]">No notifications yet.</div>
                  ) : (
                    <div className="space-y-2 max-h-60 overflow-y-auto">
                      {notifications.slice(0, 5).map((notif) => (
                        <div key={notif.id} className="py-1 border-b border-white/5 last:border-0">
                          <div className="font-semibold text-white flex items-center justify-between gap-1">
                            <span className="truncate">{notif.title}</span>
                            <span className="text-[9px] text-gray-500 font-mono shrink-0">
                              {new Date(notif.createdAt).toLocaleDateString([], { month: 'short', day: 'numeric' })}
                            </span>
                          </div>
                          <div className="text-gray-400 text-[10px] truncate">{notif.description}</div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>

              {/* User Dropdown Profile Menu / Google Sign In */}
              {!auth.currentUser ? (
                <button 
                  onClick={handleGoogleLogin}
                  className="flex items-center gap-1.5 bg-gradient-to-r from-purple-600 to-blue-600 hover:opacity-90 transition text-white text-xs font-bold px-4 py-2 rounded-full shadow-lg active:scale-95 cursor-pointer"
                >
                  <svg className="w-3.5 h-3.5" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#FFFFFF"/>
                    <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#FFFFFF"/>
                    <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z" fill="#FFFFFF"/>
                    <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z" fill="#FFFFFF"/>
                  </svg>
                  <span>Sign In with Google</span>
                </button>
              ) : (
                <div className="relative group cursor-pointer">
                  <button 
                    onClick={() => {
                      setEditFullName(currentUser.fullname || '');
                      setEditUsername(currentUser.username || '');
                      setEditBio(currentUser.bio || '');
                      setEditPhotoURL(currentUser.photoURL || '');
                      setSelectedDrama(null);
                      setSelectedEpisode(null);
                      setActiveTab('profile');
                    }}
                    className="flex items-center gap-2 bg-white/4 border border-white/8 hover:bg-white/8 hover:border-purple-500/50 transition rounded-full px-3 py-1.5 text-xs text-white font-medium"
                  >
                    {currentUser.photoURL ? (
                      <img 
                        src={currentUser.photoURL} 
                        alt="" 
                        className="w-4.5 h-4.5 rounded-full object-cover border border-purple-500" 
                        onError={(e) => {
                          e.currentTarget.style.display = 'none';
                        }}
                      />
                    ) : (
                      <div className="w-4.5 h-4.5 rounded-full bg-purple-600/30 flex items-center justify-center text-[10px] font-bold text-purple-300 border border-purple-500/50">
                        {currentUser.fullname ? currentUser.fullname[0].toUpperCase() : 'U'}
                      </div>
                    )}
                    <span>{currentUser.fullname}</span>
                  </button>
                  <div className="absolute right-0 top-full mt-2 w-48 bg-[#0a0a14] border border-white/8 rounded-xl py-2 shadow-xl hidden group-hover:block text-xs z-50">
                    <div className="px-3 py-1.5 border-b border-white/5 mb-1.5">
                      <div className="font-bold text-white text-truncate">@{currentUser.username}</div>
                      <div className="text-gray-400 text-[10px] text-truncate">{currentUser.email}</div>
                    </div>
                    {isAdminLogged && (
                      <button 
                        onClick={() => {
                          setSelectedDrama(null);
                          setSelectedEpisode(null);
                          setActiveTab('admin_dash');
                        }} 
                        className="w-full text-left px-3 py-1.5 hover:bg-purple-600/10 text-red-400 flex items-center gap-1.5"
                      >
                        <ShieldAlert className="w-3.5 h-3.5" />
                        <span>Admin Suite</span>
                      </button>
                    )}
                    <button 
                      onClick={() => {
                        setEditFullName(currentUser.fullname || '');
                        setEditUsername(currentUser.username || '');
                        setEditBio(currentUser.bio || '');
                        setEditPhotoURL(currentUser.photoURL || '');
                        setSelectedDrama(null);
                        setSelectedEpisode(null);
                        setActiveTab('profile');
                      }} 
                      className="w-full text-left px-3 py-1.5 hover:bg-white/4 flex items-center gap-1.5"
                    >
                      <User className="w-3.5 h-3.5 text-blue-400" />
                      <span>My Profile</span>
                    </button>
                    <button 
                      onClick={() => {
                        setSelectedDrama(null);
                        setSelectedEpisode(null);
                        setActiveTab('history');
                      }} 
                      className="w-full text-left px-3 py-1.5 hover:bg-white/4 flex items-center gap-1.5"
                    >
                      <History className="w-3.5 h-3.5 text-yellow-500" />
                      <span>Watch History</span>
                    </button>
                    <button onClick={handleLogout} className="w-full text-left px-3 py-1.5 hover:bg-white/4 text-red-400 flex items-center gap-1.5 border-t border-white/5 mt-1.5">
                      <LogOut className="w-3.5 h-3.5" />
                      <span>Sign Out</span>
                    </button>
                  </div>
                </div>
              )}
            </div>
          </nav>

          {/* Mobile Navigation Drawer/Menu */}
          {showMobileMenu && (
            <div className="lg:hidden bg-[#0a0a14]/95 border-b border-white/5 p-5 backdrop-blur-lg animate-fade-in relative z-20 space-y-4">
              <div className="flex flex-col gap-3 text-sm text-[#9ea2c0]">
                <button 
                  onClick={() => {
                    setActiveTab('home');
                    setSelectedGenre('');
                    setSelectedDrama(null);
                    setSelectedEpisode(null);
                    setShowMobileMenu(false);
                  }}
                  className={`w-full text-left py-2 px-3 rounded-lg hover:bg-white/5 transition hover:text-white cursor-pointer ${activeTab === 'home' && !selectedGenre ? 'bg-purple-600/15 text-white font-semibold border-l-2 border-purple-500' : ''}`}
                >
                  Home
                </button>
                <div className="grid grid-cols-2 gap-2 pl-3">
                  <button 
                    onClick={() => {
                      setActiveTab('home');
                      setSelectedGenre('Romance');
                      setSelectedDrama(null);
                      setSelectedEpisode(null);
                      setShowMobileMenu(false);
                    }}
                    className={`text-left py-1.5 px-2.5 rounded-md text-xs hover:bg-white/5 transition hover:text-white cursor-pointer ${selectedGenre === 'Romance' ? 'bg-white/5 text-white font-semibold' : ''}`}
                  >
                    Romance
                  </button>
                  <button 
                    onClick={() => {
                      setActiveTab('home');
                      setSelectedGenre('Comedy');
                      setSelectedDrama(null);
                      setSelectedEpisode(null);
                      setShowMobileMenu(false);
                    }}
                    className={`text-left py-1.5 px-2.5 rounded-md text-xs hover:bg-white/5 transition hover:text-white cursor-pointer ${selectedGenre === 'Comedy' ? 'bg-white/5 text-white font-semibold' : ''}`}
                  >
                    Comedy
                  </button>
                  <button 
                    onClick={() => {
                      setActiveTab('home');
                      setSelectedGenre('Action');
                      setSelectedDrama(null);
                      setSelectedEpisode(null);
                      setShowMobileMenu(false);
                    }}
                    className={`text-left py-1.5 px-2.5 rounded-md text-xs hover:bg-white/5 transition hover:text-white cursor-pointer ${selectedGenre === 'Action' ? 'bg-white/5 text-white font-semibold' : ''}`}
                  >
                    Action
                  </button>
                  <button 
                    onClick={() => {
                      setActiveTab('home');
                      setSelectedGenre('Mystery');
                      setSelectedDrama(null);
                      setSelectedEpisode(null);
                      setShowMobileMenu(false);
                    }}
                    className={`text-left py-1.5 px-2.5 rounded-md text-xs hover:bg-white/5 transition hover:text-white cursor-pointer ${selectedGenre === 'Mystery' ? 'bg-white/5 text-white font-semibold' : ''}`}
                  >
                    Mystery
                  </button>
                </div>

                <button 
                  onClick={() => {
                    setActiveTab('playlists');
                    setSelectedDrama(null);
                    setSelectedEpisode(null);
                    setShowMobileMenu(false);
                  }}
                  className={`w-full text-left py-2 px-3 rounded-lg hover:bg-white/5 transition hover:text-white cursor-pointer ${activeTab === 'playlists' ? 'bg-purple-600/15 text-white font-semibold border-l-2 border-purple-500' : ''}`}
                >
                  My Playlists
                </button>

                <button 
                  onClick={() => {
                    setActiveTab('mylist');
                    setSelectedDrama(null);
                    setSelectedEpisode(null);
                    setShowMobileMenu(false);
                  }}
                  className={`w-full text-left py-2 px-3 rounded-lg hover:bg-white/5 transition hover:text-white cursor-pointer ${activeTab === 'mylist' ? 'bg-purple-600/15 text-white font-semibold border-l-2 border-purple-500' : ''}`}
                >
                  My List
                </button>

                <hr className="border-white/5 my-1" />

                {auth.currentUser ? (
                  <>
                    <button 
                      onClick={() => {
                        setEditFullName(currentUser.fullname || '');
                        setEditUsername(currentUser.username || '');
                        setEditBio(currentUser.bio || '');
                        setEditPhotoURL(currentUser.photoURL || '');
                        setSelectedDrama(null);
                        setSelectedEpisode(null);
                        setActiveTab('profile');
                        setShowMobileMenu(false);
                      }}
                      className={`w-full text-left py-2.5 px-3 rounded-lg hover:bg-white/5 transition hover:text-white cursor-pointer flex items-center gap-2.5 ${activeTab === 'profile' ? 'bg-purple-600/15 text-white font-semibold border-l-2 border-purple-500' : ''}`}
                    >
                      {currentUser.photoURL ? (
                        <img src={currentUser.photoURL} alt="" className="w-5 h-5 rounded-full object-cover border border-purple-500" />
                      ) : (
                        <div className="w-5 h-5 rounded-full bg-purple-600/30 flex items-center justify-center text-[10px] font-bold text-purple-300">
                          {currentUser.fullname ? currentUser.fullname[0].toUpperCase() : 'U'}
                        </div>
                      )}
                      <div className="flex flex-col truncate">
                        <span className="text-white font-bold leading-none">{currentUser.fullname}</span>
                        <span className="text-[10px] text-gray-400 font-mono">@{currentUser.username}</span>
                      </div>
                    </button>

                    <button 
                      onClick={() => {
                        setActiveTab('history');
                        setSelectedDrama(null);
                        setSelectedEpisode(null);
                        setShowMobileMenu(false);
                      }}
                      className={`w-full text-left py-2 px-3 rounded-lg hover:bg-white/5 transition hover:text-white cursor-pointer flex items-center gap-2 ${activeTab === 'history' ? 'bg-purple-600/15 text-white font-semibold border-l-2 border-purple-500' : ''}`}
                    >
                      <History className="w-4 h-4 text-yellow-500" />
                      <span>Watch History</span>
                    </button>
                  </>
                ) : (
                  <button 
                    onClick={() => {
                      handleGoogleLogin();
                      setShowMobileMenu(false);
                    }}
                    className="w-full bg-gradient-to-r from-purple-600 to-blue-600 hover:opacity-90 text-white font-bold py-2.5 px-4 rounded-xl text-xs transition flex items-center justify-center gap-2 cursor-pointer shadow-lg animate-pulse"
                  >
                    <svg className="w-4 h-4" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                      <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#FFFFFF"/>
                      <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#FFFFFF"/>
                      <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z" fill="#FFFFFF"/>
                      <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z" fill="#FFFFFF"/>
                    </svg>
                    <span>Sign In with Google</span>
                  </button>
                )}

                {isAdminLogged && (
                  <button 
                    onClick={() => {
                      setActiveTab('admin_dash');
                      setSelectedDrama(null);
                      setSelectedEpisode(null);
                      setShowMobileMenu(false);
                    }}
                    className={`w-full text-left py-2 px-3 rounded-lg hover:bg-white/5 transition hover:text-white cursor-pointer flex items-center gap-2 ${activeTab === 'admin_dash' ? 'bg-purple-600/15 text-white font-semibold border-l-2 border-purple-500' : ''}`}
                  >
                    <ShieldAlert className="w-4 h-4 text-red-500" />
                    <span>Admin Suite</span>
                  </button>
                )}

                <button 
                  onClick={() => {
                    handleLogout();
                    setShowMobileMenu(false);
                  }}
                  className="w-full text-left py-2 px-3 rounded-lg hover:bg-white/5 transition text-red-400 hover:text-red-300 cursor-pointer flex items-center gap-2 border-t border-white/5 pt-3"
                >
                  <LogOut className="w-4 h-4" />
                  <span>Sign Out</span>
                </button>
              </div>
            </div>
          )}

          {/* Mobile Expandable Search Bar */}
          {showMobileSearch && (
            <div className="bg-[#0a0a14] border-b border-white/5 p-4 md:hidden animate-fade-in relative z-20">
              <div className="relative">
                <input 
                  type="text"
                  placeholder="Search dramas, genre, cast..."
                  value={searchQuery}
                  onChange={e => setSearchQuery(e.target.value)}
                  className="w-full bg-white/5 border border-white/10 rounded-xl py-2.5 pl-10 pr-10 text-xs text-white placeholder-gray-500 focus:outline-none focus:border-purple-500 transition-all"
                  aria-label="Search Dramas Mobile Input"
                  autoFocus
                />
                <Search className="w-4 h-4 absolute left-3.5 top-3 text-gray-400" />
                {searchQuery && (
                  <button 
                    onClick={() => {
                      clearSearch();
                    }}
                    aria-label="Clear Search"
                    className="absolute right-3.5 top-3 text-gray-400 hover:text-white"
                  >
                    <X className="w-4 h-4" />
                  </button>
                )}
              </div>
            </div>
          )}

          {/* --------------------------------------------------------
              ROUTED VIEWS DISPATCHER
              -------------------------------------------------------- */}
          <div className="flex-1">

            {/* TAB: HOME VIEW */}
            {activeTab === 'home' && !selectedDrama && (
              <div className="space-y-8 animate-fade-in">
                {/* Hero Feature Banner Slider */}
                {!searchQuery && !selectedGenre && dramas.length > 0 && (() => {
                  const currentDrama = dramas[currentBannerIndex];
                  if (!currentDrama) return null;

                  return (
                    <div 
                      className="relative h-[65vh] min-h-[420px] overflow-hidden rounded-2xl"
                      onMouseEnter={() => setIsHovering(true)}
                      onMouseLeave={() => setIsHovering(false)}
                      onTouchStart={onTouchStart}
                      onTouchMove={onTouchMove}
                      onTouchEnd={onTouchEnd}
                    >
                      <AnimatePresence initial={false} custom={direction} mode="wait">
                        <motion.div
                          key={currentDrama.id}
                          custom={direction}
                          variants={bannerVariants}
                          initial="enter"
                          animate="center"
                          exit="exit"
                          className="absolute inset-0 flex items-center cursor-pointer"
                          onClick={(e) => {
                            // Clicking anywhere on the banner should open the drama details page.
                            // Ensure clicks on buttons/indicators are ignored to prevent nested state changes.
                            const target = e.target as HTMLElement;
                            if (
                              target.closest('button') || 
                              target.closest('.carousel-indicators') || 
                              target.closest('.carousel-nav-btn')
                            ) {
                              return;
                            }
                            setSelectedDrama(currentDrama);
                          }}
                        >
                          {/* Lazy-loaded background banner image */}
                          <img
                            src={currentDrama.banner_url}
                            alt={currentDrama.title}
                            className="absolute inset-0 w-full h-full object-cover pointer-events-none"
                            loading="lazy"
                            referrerPolicy="no-referrer"
                          />
                          {/* Gradient overlays */}
                          <div className="absolute inset-0 bg-gradient-to-t from-[#05050a] via-[#05050a]/40 to-[#05050a]/90 pointer-events-none"></div>
                          <div className="absolute inset-0 bg-gradient-to-r from-[#05050a] via-[#05050a]/20 to-transparent pointer-events-none"></div>
                          
                          <div className="container mx-auto px-6 md:px-12 relative z-10 max-w-3xl">
                            <div className="flex flex-wrap gap-2 mb-3 items-center">
                              <span className="bg-purple-600/25 border border-purple-500 text-white text-[11px] font-bold px-3 py-1 rounded-full uppercase tracking-wider inline-block">
                                {currentDrama.country || 'POPULAR'}
                              </span>
                              {currentDrama.genre && (
                                <span className="bg-white/5 border border-white/10 text-gray-300 text-[11px] font-medium px-3 py-1 rounded-full uppercase tracking-wider inline-block">
                                  {currentDrama.genre}
                                </span>
                              )}
                              {getAverageRating(currentDrama.id) && (
                                <span className="bg-yellow-500/10 border border-yellow-500/20 text-yellow-400 text-[11px] font-bold px-3 py-1 rounded-full flex items-center gap-1">
                                  <Star className="w-3 h-3 fill-yellow-400" />
                                  <span>{getAverageRating(currentDrama.id)}</span>
                                </span>
                              )}
                              {currentDrama.release_year && (
                                <span className="text-gray-400 text-xs font-mono ml-1">{currentDrama.release_year}</span>
                              )}
                            </div>
                            <h1 className="text-4xl md:text-6xl font-bold tracking-tight mb-3 text-white">
                              {currentDrama.title}
                            </h1>
                            <p className="text-[#9ea2c0] text-sm md:text-base mb-6 leading-relaxed line-clamp-3">
                              {currentDrama.description}
                            </p>
                            <div className="flex flex-wrap gap-3">
                              <button 
                                onClick={(e) => {
                                  e.stopPropagation();
                                  setSelectedDrama(currentDrama);
                                  const eps = episodes.filter(e => e.drama_id === currentDrama.id).sort((a,b)=>a.episode_number-b.episode_number);
                                  if (eps.length > 0) {
                                    setSelectedEpisode(eps[0]);
                                    setActiveTab('player');
                                    setCurrentTime(0);
                                    setIsPlaying(true);
                                  }
                                }}
                                className="bg-gradient-to-r from-purple-600 to-blue-600 hover:opacity-95 text-white font-semibold rounded-full px-6 py-2.5 flex items-center gap-2 text-sm cursor-pointer shadow-lg shadow-purple-600/20 animate-fade-in"
                              >
                                <Play className="w-4 h-4 fill-white" />
                                <span>
                                  {episodes.some(e => e.drama_id === currentDrama.id) ? 'Watch Ep 1 Now' : 'Watch Trailer'}
                                </span>
                              </button>
                              <button 
                                onClick={(e) => {
                                  e.stopPropagation();
                                  setSelectedDrama(currentDrama);
                                }}
                                className="bg-white/8 hover:bg-white/12 border border-white/10 text-white font-semibold rounded-full px-6 py-2.5 flex items-center gap-2 text-sm cursor-pointer"
                              >
                                <Info className="w-4 h-4" />
                                <span>More Information</span>
                              </button>
                            </div>
                          </div>
                        </motion.div>
                      </AnimatePresence>

                      {/* Navigation Arrow buttons (desktop only) */}
                      {dramas.length > 1 && (
                        <>
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              prevBanner();
                            }}
                            className="carousel-nav-btn absolute left-4 top-1/2 -translate-y-1/2 bg-[#05050a]/55 hover:bg-purple-600/75 border border-white/10 text-white p-2 rounded-full backdrop-blur-md transition-all active:scale-90 z-20 cursor-pointer hidden md:flex items-center justify-center group"
                            aria-label="Previous Slide"
                          >
                            <ChevronLeft className="w-5 h-5 group-hover:-translate-x-0.5 transition-transform" />
                          </button>
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              nextBanner();
                            }}
                            className="carousel-nav-btn absolute right-4 top-1/2 -translate-y-1/2 bg-[#05050a]/55 hover:bg-purple-600/75 border border-white/10 text-white p-2 rounded-full backdrop-blur-md transition-all active:scale-90 z-20 cursor-pointer hidden md:flex items-center justify-center group"
                            aria-label="Next Slide"
                          >
                            <ChevronRight className="w-5 h-5 group-hover:translate-x-0.5 transition-transform" />
                          </button>
                        </>
                      )}

                      {/* Clickable indicator dots */}
                      {dramas.length > 1 && (
                        <div className="carousel-indicators absolute bottom-6 left-1/2 -translate-x-1/2 flex gap-2 z-20">
                          {dramas.map((_, idx) => (
                            <button
                              key={idx}
                              onClick={(e) => {
                                e.stopPropagation();
                                setDirection(idx > currentBannerIndex ? 1 : -1);
                                setCurrentBannerIndex(idx);
                              }}
                              className={`h-1.5 rounded-full transition-all duration-300 cursor-pointer ${
                                idx === currentBannerIndex 
                                  ? 'w-6 bg-purple-500' 
                                  : 'w-1.5 bg-white/45 hover:bg-white/70'
                              }`}
                              aria-label={`Go to slide ${idx + 1}`}
                            />
                          ))}
                        </div>
                      )}
                    </div>
                  );
                })()}

                <div className="container mx-auto px-6 md:px-12 space-y-10 pb-16">
                  
                  {/* Category Filter Chips for all devices (especially helpful on mobile) */}
                  <div className="border-b border-white/5 pb-4">
                    <p className="text-[10px] text-gray-500 font-bold uppercase tracking-widest mb-2.5">Browse Genres</p>
                    <div className="flex gap-2 overflow-x-auto pb-1 scrollbar-none scroll-smooth">
                      {[
                        { label: '🔥 All Shows', value: '' },
                        { label: '💖 Romance', value: 'Romance' },
                        { label: '😂 Comedy', value: 'Comedy' },
                        { label: '⚔️ Action', value: 'Action' },
                        { label: '🔍 Mystery', value: 'Mystery' }
                      ].map((chip) => (
                        <button
                          key={chip.value}
                          onClick={() => {
                            setActiveTab('home');
                            setSelectedGenre(chip.value);
                            setSelectedDrama(null);
                          }}
                          className={`px-4 py-2 rounded-full text-xs font-semibold whitespace-nowrap transition-all duration-300 border cursor-pointer ${
                            selectedGenre === chip.value
                              ? 'bg-gradient-to-r from-purple-600 to-blue-600 text-white border-transparent shadow-[0_0_12px_rgba(168,85,247,0.35)]'
                              : 'bg-white/5 border-white/8 text-gray-300 hover:bg-white/10 hover:text-white'
                          }`}
                        >
                          {chip.label}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Dynamic Query feedback */}
                  {(searchQuery || selectedGenre) && (
                    <div className="flex justify-between items-center border-b border-white/5 pb-4 mb-4">
                      <div>
                        <h2 className="text-2xl font-bold">
                          {searchQuery ? `Search Results for: "${searchQuery}"` : `Category: ${selectedGenre}`}
                        </h2>
                        <p className="text-gray-400 text-xs mt-1">Found {filteredDramas.length} drama matching filters.</p>
                      </div>
                      <button 
                        onClick={() => { setSearchQuery(''); setSelectedGenre(''); }}
                        className="text-xs text-blue-400 hover:underline"
                      >
                        Reset All Filters
                      </button>
                    </div>
                  )}

                  {/* Offline Warning Banner */}
                  {!isOnline && (
                    <div className="bg-red-500/10 border border-red-500/20 rounded-xl p-3 mb-6 flex items-center justify-between text-xs text-red-400 animate-pulse">
                      <div className="flex items-center gap-2">
                        <WifiOff className="w-4 h-4 shrink-0 text-red-500" />
                        <span>Offline mode active. You are viewing cached data. Real-time sync will resume when connection is restored.</span>
                      </div>
                      <span className="text-[10px] uppercase font-bold tracking-wider opacity-60">Disconnected</span>
                    </div>
                  )}

                  {!initialDataLoaded ? (
                    <div className="space-y-10 animate-pulse">
                      {/* Skeletons for Continue Watching / Recently Added */}
                      <div>
                        <div className="h-6 w-48 bg-white/10 rounded mb-4"></div>
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
                          {[1, 2, 3, 4].map(n => (
                            <div key={n} className="rounded-xl overflow-hidden aspect-[2/3] bg-white/5 p-4 flex flex-col justify-between">
                              <div className="w-12 h-4 bg-white/10 rounded"></div>
                              <div className="space-y-2">
                                <div className="w-full h-4 bg-white/10 rounded"></div>
                                <div className="w-2/3 h-3 bg-white/10 rounded font-mono"></div>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>

                      {/* Skeletons for Trending */}
                      <div>
                        <div className="h-6 w-32 bg-white/10 rounded mb-4"></div>
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
                          {[1, 2, 3, 4].map(n => (
                            <div key={n} className="rounded-xl overflow-hidden aspect-[2/3] bg-white/5 p-4 flex flex-col justify-between">
                              <div className="w-12 h-4 bg-white/10 rounded"></div>
                              <div className="space-y-2">
                                <div className="w-full h-4 bg-white/10 rounded"></div>
                                <div className="w-2/3 h-3 bg-white/10 rounded"></div>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  ) : (
                    <div className="space-y-10">
                      {/* CONTINUE WATCHING TRACKS */}
                      {!searchQuery && !selectedGenre && watchHistory.length > 0 && (
                        <div>
                          <h3 className="text-xl font-bold mb-4 flex items-center gap-2">
                            <Clock className="w-5 h-5 text-blue-400" />
                            <span>Continue Watching</span>
                          </h3>
                          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
                            {watchHistory.slice(0, 4).map(item => {
                              const d = dramas.find(x => x.id === item.dramaId);
                              const ep = episodes.find(x => x.id === item.episodeId);
                              if (!d || !ep) return null;
                              return (
                                <div key={item.episodeId} className="bg-[#0a0a14]/65 border border-white/8 rounded-xl p-3 flex flex-col justify-between">
                                  <div className="relative overflow-hidden rounded-lg mb-2">
                                    <img src={d.poster_url} alt={`${d.title} Poster`} loading="lazy" className="w-full h-32 object-cover" />
                                    <span className="absolute bottom-2 left-2 bg-black/80 px-2 py-0.5 rounded text-[10px] font-mono">
                                      Ep {ep.episode_number}
                                    </span>
                                  </div>
                                  <h5 className="font-bold text-white text-truncate mb-0.5">{d.title}</h5>
                                  <p className="text-gray-400 text-[11px] text-truncate mb-3">{ep.title}</p>
                                  
                                  <button 
                                    onClick={() => {
                                      setSelectedDrama(d);
                                      setSelectedEpisode(ep);
                                      setCurrentTime(item.progressSeconds);
                                      setActiveTab('player');
                                      setIsPlaying(true);
                                    }}
                                    className="w-full bg-blue-500/10 hover:bg-blue-500/20 text-blue-400 rounded-full py-1.5 text-xs font-semibold"
                                  >
                                    Resume Streaming
                                  </button>
                                </div>
                              );
                            })}
                          </div>
                        </div>
                      )}

                      {/* RECENTLY ADDED DRAMAS SECTION */}
                      {!searchQuery && !selectedGenre && recentlyAddedDramas.length > 0 && (
                        <div>
                          <h3 className="text-xl font-bold mb-5 flex items-center gap-2">
                            <Sparkles className="w-5 h-5 text-emerald-400 animate-pulse" />
                            <span>Recently Added Releases</span>
                          </h3>
                          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-6">
                            {recentlyAddedDramas.map(drama => (
                              <div 
                                key={`recent-${drama.id}`} 
                                onClick={() => setSelectedDrama(drama)}
                                className="group relative rounded-xl overflow-hidden cursor-pointer shadow-lg border border-[#ffffff]/5 aspect-[2/3] hover:-translate-y-2 transition duration-300 select-none bg-[#0a0a14]"
                              >
                                <img src={drama.poster_url} alt={`${drama.title} Poster`} loading="lazy" className="w-full h-full object-cover group-hover:scale-105 transition duration-500" />
                                <span className="absolute top-3 left-3 bg-emerald-500 text-black text-[9px] font-bold px-2 py-0.5 rounded uppercase font-mono shadow-md tracking-wider">
                                  New
                                </span>
                                <div className="absolute inset-0 bg-gradient-to-t from-[#05050a] via-[#05050a]/30 to-transparent opacity-0 group-hover:opacity-100 transition duration-300 flex flex-col justify-end p-3">
                                  <h4 className="font-bold text-white text-xs leading-tight mb-1">{drama.title}</h4>
                                  <p className="text-gray-400 text-[9px] line-clamp-2 leading-relaxed mb-2">{drama.description}</p>
                                  <div className="flex items-center justify-between text-[10px] text-gray-300 border-t border-white/10 pt-1.5">
                                    <span className="font-semibold text-yellow-400 flex items-center gap-0.5">
                                      <Star className="w-2.5 h-2.5 fill-yellow-400" />
                                      <span>{getAverageRating(drama.id)}</span>
                                    </span>
                                    <span>{drama.release_year}</span>
                                  </div>
                                </div>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}

                      {/* LIVE TRENDING SECTION */}
                      {!searchQuery && !selectedGenre && trendingDramas.length > 0 && (
                        <div>
                          <h3 className="text-xl font-bold mb-5 flex items-center gap-2">
                            <Star className="w-5 h-5 text-yellow-400 animate-bounce" />
                            <span>Live Trending Hits</span>
                          </h3>
                          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-6">
                            {trendingDramas.map((drama, idx) => (
                              <div 
                                key={`trending-${drama.id}`} 
                                onClick={() => setSelectedDrama(drama)}
                                className="group relative rounded-xl overflow-hidden cursor-pointer shadow-lg border border-[#ffffff]/5 aspect-[2/3] hover:-translate-y-2 transition duration-300 select-none bg-[#0a0a14]"
                              >
                                <img src={drama.poster_url} alt={`${drama.title} Trending Poster`} loading="lazy" className="w-full h-full object-cover group-hover:scale-105 transition duration-500" />
                                <span className="absolute top-3 left-3 bg-yellow-400 text-black text-[11px] font-black px-2.5 py-0.5 rounded shadow-md font-mono">
                                  #{idx + 1}
                                </span>
                                <div className="absolute inset-0 bg-gradient-to-t from-[#05050a] via-[#05050a]/30 to-transparent opacity-0 group-hover:opacity-100 transition duration-300 flex flex-col justify-end p-3">
                                  <h4 className="font-bold text-white text-xs leading-tight mb-1">{drama.title}</h4>
                                  <div className="flex items-center justify-between text-[10px] text-gray-300 mt-2">
                                    <span className="font-semibold text-yellow-400 flex items-center gap-0.5 bg-yellow-500/10 px-1.5 py-0.5 rounded border border-yellow-500/20">
                                      <Star className="w-2.5 h-2.5 fill-yellow-400" />
                                      <span>{getAverageRating(drama.id)}</span>
                                    </span>
                                    <span>{drama.release_year}</span>
                                  </div>
                                </div>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}

                      {/* DRAMA GRID CARDS (GRID LIST) */}
                      <div>
                        <h3 className="text-xl font-bold mb-5 flex items-center gap-2">
                          <Film className="w-5 h-5 text-purple-400" />
                          <span>{selectedGenre ? `${selectedGenre} Drama Catalog` : 'Explore Streaming Catalog'}</span>
                        </h3>
                        
                        {filteredDramas.length === 0 ? (
                          <div className="bg-[#0a0a14]/45 border border-white/5 rounded-2xl p-12 text-center text-gray-400">
                            <Film className="w-12 h-12 text-gray-600 mx-auto mb-4" />
                            <h4 className="font-bold text-white mb-1">No Dramas Match Filters</h4>
                            <p className="text-xs">Adjust your search keyword or selection tags to discover amazing releases.</p>
                          </div>
                        ) : (
                          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-6">
                            {filteredDramas.map(drama => {
                              const likesCount = allLikes.filter(l => l.dramaId === drama.id).length;
                              const viewsCount = allViews.filter(v => v.dramaId === drama.id).length;
                              return (
                                <div 
                                  key={drama.id} 
                                  onClick={() => setSelectedDrama(drama)}
                                  className="group relative rounded-xl overflow-hidden cursor-pointer shadow-lg border border-[#ffffff]/5 aspect-[2/3] hover:-translate-y-2 transition duration-300 select-none bg-[#0a0a14]"
                                >
                                  <img src={drama.poster_url} alt={`${drama.title} Poster`} loading="lazy" className="w-full h-full object-cover group-hover:scale-105 transition duration-500" />
                                  <div className="absolute inset-0 bg-gradient-to-t from-[#05050a] via-[#05050a]/30 to-transparent opacity-0 group-hover:opacity-100 transition duration-300 flex flex-col justify-end p-3">
                                    <h4 className="font-bold text-white text-xs leading-tight mb-1">{drama.title}</h4>
                                    <div className="flex items-center justify-between text-[10px] text-gray-300 mb-1.5">
                                      <span className="font-semibold text-yellow-400 flex items-center gap-0.5">
                                        <Star className="w-2.5 h-2.5 fill-yellow-400" />
                                        <span>{getAverageRating(drama.id)}</span>
                                      </span>
                                      <span>{drama.release_year}</span>
                                    </div>
                                    <div className="flex items-center gap-2.5 text-[9px] text-gray-400 font-mono">
                                      <span className="flex items-center gap-0.5">
                                        <Eye className="w-3 h-3 text-gray-500" />
                                        <span>{formatCount(viewsCount)}</span>
                                      </span>
                                      <span className="flex items-center gap-0.5">
                                        <ThumbsUp className="w-2.5 h-2.5 text-gray-500" />
                                        <span>{formatCount(likesCount)}</span>
                                      </span>
                                    </div>
                                  </div>
                                </div>
                              );
                            })}
                          </div>
                        )}
                      </div>
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* TAB: DRAMA DETAILS VIEW */}
            {selectedDrama && activeTab !== 'player' && activeTab !== 'profile' && activeTab !== 'playlists' && activeTab !== 'mylist' && activeTab !== 'history' && activeTab !== 'admin_dash' && activeTab !== 'admin_login' && activeTab !== 'legal' && activeTab !== 'copyright' && activeTab !== 'brand' && activeTab !== 'contact' && activeTab !== 'support' && (() => {
              const lastWatchedItem = watchHistory
                .filter(item => item.dramaId === selectedDrama.id)
                .sort((a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime())[0];

              const dramaEpisodes = episodes
                .filter(e => e.drama_id === selectedDrama.id)
                .sort((a, b) => a.episode_number - b.episode_number);

              const epToPlay = lastWatchedItem
                ? (episodes.find(x => x.id === lastWatchedItem.episodeId) || dramaEpisodes[0])
                : dramaEpisodes[0];

              const watchNowLabel = epToPlay
                ? (lastWatchedItem ? `Resume Episode ${epToPlay.episode_number}` : `Watch Episode ${epToPlay.episode_number || 1}`)
                : "Watch Now";

              const handleWatchNowClick = () => {
                if (!epToPlay) {
                  showToast("No episodes available to watch yet.", "info");
                  return;
                }
                setSelectedEpisode(epToPlay);
                setActiveTab('player');
                setCurrentTime(lastWatchedItem ? lastWatchedItem.progressSeconds : 0);
                setIsPlaying(true);
              };

              return (
                <div className="animate-fade-in">
                  {/* Hero banner section */}
                  <div className="relative h-[45vh] bg-cover bg-center flex items-end" style={{ backgroundImage: `url('${selectedDrama.banner_url}')` }}>
                    <div className="absolute inset-0 bg-gradient-to-t from-[#05050a] via-[#05050a]/30 to-[#05050a]/90"></div>
                    <div className="container mx-auto px-6 md:px-12 relative z-10 pb-6">
                      <button 
                        onClick={() => setSelectedDrama(null)}
                        className="bg-white/8 hover:bg-white/12 px-3 py-1.5 rounded-full text-xs text-white flex items-center gap-1 mb-4 cursor-pointer"
                      >
                        <ChevronLeft className="w-3.5 h-3.5" />
                        <span>Back to Catalog</span>
                      </button>

                      <div className="flex flex-wrap gap-2 mb-2">
                        {selectedDrama.genre.split(',').map((g, i) => (
                          <span key={i} className="bg-purple-600/20 border border-purple-600/40 text-blue-400 text-[10px] font-bold px-2.5 py-1 rounded-full uppercase">
                            {g.trim()}
                          </span>
                        ))}
                        <span className="bg-black/40 text-gray-300 text-[10px] border border-white/10 px-2.5 py-1 rounded-full">
                          {selectedDrama.country}
                        </span>
                      </div>

                      <h1 className="text-3xl md:text-5xl font-bold tracking-tight mb-2">{selectedDrama.title}</h1>
                      <div className="text-xs text-gray-300 flex gap-4">
                        <span><strong>Year:</strong> {selectedDrama.release_year}</span>
                        <span><strong>Status:</strong> {selectedDrama.status}</span>
                      </div>
                    </div>
                  </div>

                  <div className="container mx-auto px-6 md:px-12 py-10">
                    <div className="space-y-8">
                      
                      {/* SECTION 1: Streaming Episode Slot (Directly below hero section) */}
                      <div className="bg-[#0a0a14]/65 border border-white/8 rounded-2xl p-6 md:p-8 shadow-2xl backdrop-blur-md">
                        
                        {/* CTA / Action Bar */}
                        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-8 border-b border-white/5 pb-6">
                          <div className="space-y-2">
                            <h3 className="text-xl md:text-2xl font-bold text-white flex items-center gap-2">
                              <Play className="w-5 h-5 text-purple-400 fill-purple-400" />
                              <span>Now Streaming</span>
                            </h3>
                            <p className="text-xs text-gray-400 font-mono">
                              Select an episode or resume playing your last saved progress below.
                            </p>
                          </div>

                          {/* Button Row */}
                          <div className="flex flex-wrap items-center gap-3">
                            {/* Watch Now Button */}
                            <button 
                              onClick={handleWatchNowClick}
                              className="flex-1 md:flex-initial bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-500 hover:to-blue-500 text-white font-bold text-sm px-6 py-3.5 rounded-xl transition duration-300 shadow-lg shadow-purple-600/20 active:scale-95 flex items-center justify-center gap-2 cursor-pointer"
                            >
                              <Play className="w-4 h-4 fill-white" />
                              <span>{watchNowLabel}</span>
                            </button>

                            {/* Favorite Button */}
                            <button 
                              onClick={() => toggleFavoriteLocal(selectedDrama.id)}
                              className={`p-3.5 rounded-xl border transition duration-300 flex items-center justify-center gap-2 cursor-pointer ${
                                favorites.includes(selectedDrama.id) 
                                  ? 'bg-red-500/15 border-red-500/30 text-red-500 hover:bg-red-500/25' 
                                  : 'bg-white/4 border-white/8 text-gray-300 hover:bg-white/8 hover:text-white'
                              }`}
                              title="Toggle Favorite"
                            >
                              <Heart className={`w-5 h-5 ${favorites.includes(selectedDrama.id) ? 'fill-red-500' : ''}`} />
                              <span className="text-xs font-semibold hidden md:inline">
                                {favorites.includes(selectedDrama.id) ? 'Favorited' : 'Favorite'}
                              </span>
                            </button>

                            {/* Like Button */}
                            <button 
                              onClick={() => toggleLike(selectedDrama.id)}
                              className={`p-3.5 rounded-xl border transition duration-300 flex items-center justify-center gap-2 cursor-pointer ${
                                auth.currentUser && allLikes.some(l => l.dramaId === selectedDrama.id && l.userId === auth.currentUser.uid)
                                  ? 'bg-blue-500/15 border-blue-500/30 text-blue-400 hover:bg-blue-500/25' 
                                  : 'bg-white/4 border-white/8 text-gray-300 hover:bg-white/8 hover:text-white'
                              }`}
                              title="Like Drama"
                            >
                              <ThumbsUp className={`w-5 h-5 ${auth.currentUser && allLikes.some(l => l.dramaId === selectedDrama.id && l.userId === auth.currentUser.uid) ? 'fill-blue-500' : ''}`} />
                              <span className="text-xs font-semibold">
                                {formatCount(allLikes.filter(l => l.dramaId === selectedDrama.id).length)}
                              </span>
                            </button>

                            {/* Views Count */}
                            <div className="p-3.5 rounded-xl border border-white/5 bg-[#05050a]/40 text-gray-400 flex items-center justify-center gap-2">
                              <Eye className="w-5 h-5" />
                              <span className="text-xs font-mono font-semibold">
                                {formatCount(allViews.filter(v => v.dramaId === selectedDrama.id).length)} Views
                              </span>
                            </div>

                             {/* Rating Button */}
                             <button 
                               onClick={() => {
                                 const targetSection = document.getElementById('drama-details-rating-system') || document.getElementById('reviews-section');
                                 if (targetSection) targetSection.scrollIntoView({ behavior: 'smooth', block: 'center' });
                               }}
                               className="p-3.5 rounded-xl border border-white/8 bg-white/4 text-gray-300 hover:bg-white/8 hover:text-white transition duration-300 flex items-center justify-center gap-2 cursor-pointer"
                               title="Scroll to interactive rating system"
                             >
                              <Star className="w-5 h-5 text-yellow-400 fill-yellow-400" />
                              <span className="text-xs font-semibold">
                                {getAverageRating(selectedDrama.id)} / 10
                              </span>
                            </button>

                            {/* Download Button */}
                            {selectedDrama.download_url && selectedDrama.download_url.trim() !== '' && (
                              <a 
                                href={selectedDrama.download_url}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="p-3.5 rounded-xl border border-emerald-500/20 bg-emerald-500/10 text-emerald-300 hover:bg-emerald-500/20 hover:text-emerald-200 transition duration-300 flex items-center justify-center gap-2 cursor-pointer shadow-[0_0_15px_rgba(16,185,129,0.1)]"
                                title="Download full drama series"
                              >
                                <Download className="w-5 h-5 text-emerald-400" />
                                <span className="text-xs font-semibold hidden md:inline">Download Drama</span>
                              </a>
                            )}
                          </div>
                        </div>

                        {/* Quick playlist addition picker */}
                        <div className="mb-6 bg-[#05050a]/40 border border-white/5 rounded-xl p-4">
                          <label className="block text-xs text-gray-400 mb-2 font-medium font-mono">Add To Playlists Folder</label>
                          <div className="flex flex-wrap gap-1.5">
                            {playlists.map(pl => {
                              const included = pl.dramaIds.includes(selectedDrama.id);
                              return (
                                <button 
                                  key={pl.id}
                                  onClick={() => toggleDramaInPlaylist(pl.id, selectedDrama.id)}
                                  className={`text-[11px] px-3.5 py-1.5 rounded-lg border font-semibold transition duration-300 cursor-pointer ${
                                    included 
                                      ? 'bg-purple-600/20 border-purple-600 text-white shadow-inner shadow-purple-600/10' 
                                      : 'bg-white/4 border-white/10 text-gray-400 hover:bg-white/8 hover:text-white'
                                  }`}
                                >
                                  {included ? '✓ ' : '+ '} {pl.name}
                                </button>
                              );
                            })}
                          </div>
                        </div>

                        {/* Interactive Premium Rating Component */}
                        <div id="drama-details-rating-system" className="mb-6 bg-gradient-to-br from-[#0e0e20]/90 to-[#070714]/90 border border-white/8 rounded-2xl p-5 md:p-6 shadow-2xl relative overflow-hidden backdrop-blur-md space-y-5">
                          <div className="absolute top-0 left-0 w-1 h-full bg-purple-500"></div>
                          
                          <div className="flex items-center justify-between">
                            <div>
                              <h4 className="text-sm font-bold text-white flex items-center gap-1.5">
                                <Sparkles className="w-4 h-4 text-purple-400" />
                                <span>Viewer Rating System</span>
                              </h4>
                              <p className="text-[10px] text-gray-400 mt-0.5">Scale: 1.0 to 10.0 (0.1 precision)</p>
                            </div>
                            
                            {auth.currentUser ? (
                              <span className="text-[10px] text-emerald-400 bg-emerald-500/10 border border-emerald-500/20 px-2.5 py-1 rounded-full font-medium font-mono flex items-center gap-1">
                                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
                                Cloud Synced
                              </span>
                            ) : (
                              <span className="text-[10px] text-yellow-400 bg-yellow-500/10 border border-yellow-500/20 px-2.5 py-1 rounded-full font-medium font-mono flex items-center gap-1">
                                <span className="w-1.5 h-1.5 rounded-full bg-yellow-400"></span>
                                Login Required
                              </span>
                            )}
                          </div>

                          {/* Quick Stats Grid */}
                          <div className="grid grid-cols-3 gap-3 bg-[#05050a]/40 border border-white/5 p-3 rounded-xl">
                            <div className="text-center border-r border-white/5">
                              <span className="block text-[9px] text-gray-500 font-mono uppercase tracking-wider">Average Score</span>
                              <span className="text-base font-bold text-yellow-400 flex items-center justify-center gap-0.5 mt-0.5 font-mono">
                                <Star className="w-3.5 h-3.5 fill-yellow-400 text-yellow-400 shrink-0" />
                                {getAverageRating(selectedDrama.id)}
                              </span>
                            </div>
                            <div className="text-center border-r border-white/5">
                              <span className="block text-[9px] text-gray-500 font-mono uppercase tracking-wider">Total Votes</span>
                              <span className="text-base font-bold text-gray-200 block mt-0.5 font-mono">
                                {ratings.filter(r => r.dramaId === selectedDrama.id).length}
                              </span>
                            </div>
                            <div className="text-center">
                              <span className="block text-[9px] text-gray-500 font-mono uppercase tracking-wider">Your Rating</span>
                              <span className="text-base font-bold text-purple-400 block mt-0.5 font-mono">
                                {ratings.find(r => r.dramaId === selectedDrama.id && r.userId === auth.currentUser?.uid)
                                  ? `${ratings.find(r => r.dramaId === selectedDrama.id && r.userId === auth.currentUser?.uid)?.rating}`
                                  : '—'}
                              </span>
                            </div>
                          </div>

                          {/* Interactive Section */}
                          <div className="space-y-4">
                            {/* Star Visualizer Row */}
                            <div className="flex flex-col items-center justify-center py-2 bg-[#05050a]/20 border border-white/5 rounded-xl space-y-1">
                              <div className="flex items-center gap-1">
                                {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map((starVal) => {
                                  // Highlight stars based on active selection (slider value)
                                  const isFull = starVal <= Math.floor(ratingSliderVal);
                                  const isPartial = !isFull && (starVal === Math.ceil(ratingSliderVal)) && (ratingSliderVal % 1 !== 0);
                                  return (
                                    <button
                                      key={starVal}
                                      type="button"
                                      onClick={() => {
                                        setRatingSliderVal(starVal);
                                        setRatingSaveSuccess(false);
                                      }}
                                      className="p-1 hover:scale-125 transition active:scale-95 cursor-pointer group"
                                      title={`Quick Select ${starVal}.0 Stars`}
                                    >
                                      <Star 
                                        className={`w-6 h-6 transition-all duration-200 ${
                                          isFull 
                                            ? 'text-yellow-400 fill-yellow-400 filter drop-shadow-[0_0_4px_rgba(250,204,21,0.5)]' 
                                            : isPartial 
                                              ? 'text-yellow-400/80 fill-yellow-400/40' 
                                              : 'text-gray-600 hover:text-yellow-400/50'
                                        }`} 
                                      />
                                    </button>
                                  );
                                })}
                              </div>
                              
                              {/* Live Score Descriptor Tag */}
                              <div className="flex items-center gap-1.5 mt-1">
                                <span className="text-xl font-black text-gray-200 font-mono">{ratingSliderVal.toFixed(1)}</span>
                                <span className="text-xs text-gray-500">/ 10.0</span>
                                <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full uppercase ml-1.5 ${
                                  ratingSliderVal >= 9.0 ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20' :
                                  ratingSliderVal >= 7.5 ? 'bg-purple-500/10 text-purple-400 border border-purple-500/20' :
                                  ratingSliderVal >= 5.0 ? 'bg-blue-500/10 text-blue-400 border border-blue-500/20' :
                                  'bg-red-500/10 text-red-400 border border-red-500/20'
                                }`}>
                                  {ratingSliderVal >= 9.0 ? 'Masterpiece' :
                                   ratingSliderVal >= 7.5 ? 'Excellent' :
                                   ratingSliderVal >= 5.0 ? 'Good' : 'Fair'}
                                </span>
                              </div>
                            </div>

                            {/* Fine Tune Slider Control */}
                            <div className="space-y-2">
                              <div className="flex items-center justify-between text-xs text-gray-400 font-mono">
                                <span>Fine-tune Score</span>
                                <div className="flex items-center gap-1 bg-[#05050a]/60 px-2 py-0.5 rounded border border-white/5">
                                  <button 
                                    type="button"
                                    onClick={() => {
                                      setRatingSliderVal(prev => Math.max(1.0, Math.round((prev - 0.1) * 10) / 10));
                                      setRatingSaveSuccess(false);
                                    }}
                                    className="p-1 text-gray-400 hover:text-white hover:bg-white/5 rounded transition shrink-0"
                                    title="Decrease 0.1"
                                  >
                                    <Minus className="w-3 h-3" />
                                  </button>
                                  <span className="px-1 text-gray-200 font-bold shrink-0">{ratingSliderVal.toFixed(1)}</span>
                                  <button 
                                    type="button"
                                    onClick={() => {
                                      setRatingSliderVal(prev => Math.min(10.0, Math.round((prev + 0.1) * 10) / 10));
                                      setRatingSaveSuccess(false);
                                    }}
                                    className="p-1 text-gray-400 hover:text-white hover:bg-white/5 rounded transition shrink-0"
                                    title="Increase 0.1"
                                  >
                                    <Plus className="w-3 h-3" />
                                  </button>
                                </div>
                              </div>
                              
                              <input 
                                type="range" 
                                min="1.0" 
                                max="10.0" 
                                step="0.1" 
                                value={ratingSliderVal} 
                                onChange={(e) => {
                                  setRatingSliderVal(Number(e.target.value));
                                  setRatingSaveSuccess(false);
                                }}
                                className="w-full accent-purple-500 bg-white/10 h-1.5 rounded-lg cursor-pointer transition-all duration-300"
                              />
                              <div className="flex justify-between text-[9px] text-gray-600 font-mono">
                                <span>1.0</span>
                                <span>5.0</span>
                                <span>10.0</span>
                              </div>
                            </div>

                            {/* Action Submission Buttons */}
                            {auth.currentUser ? (
                              <div className="pt-2">
                                <button
                                  type="button"
                                  disabled={isSavingRating}
                                  onClick={() => submitRating(selectedDrama.id, ratingSliderVal)}
                                  className={`w-full py-2.5 rounded-xl font-bold text-xs flex items-center justify-center gap-2 cursor-pointer transition-all duration-300 ${
                                    ratingSaveSuccess 
                                      ? 'bg-emerald-500 text-black hover:bg-emerald-400 shadow-[0_0_15px_rgba(16,185,129,0.3)]' 
                                      : 'bg-purple-600 text-white hover:bg-purple-500 shadow-[0_0_15px_rgba(147,51,234,0.2)]'
                                  }`}
                                >
                                  {isSavingRating ? (
                                    <>
                                      <Loader2 className="w-4 h-4 animate-spin" />
                                      <span>Uploading Rating to Cloud...</span>
                                    </>
                                  ) : ratingSaveSuccess ? (
                                    <>
                                      <Check className="w-4 h-4 stroke-[3px]" />
                                      <span>Rating Saved Successfully!</span>
                                    </>
                                  ) : (
                                    <>
                                      <Star className="w-4 h-4 fill-current" />
                                      <span>
                                        {ratings.some(r => r.dramaId === selectedDrama.id && r.userId === auth.currentUser?.uid)
                                          ? 'Update My Existing Rating'
                                          : 'Save Rating on VIBEDRAMAHUB'}
                                      </span>
                                    </>
                                  )}
                                </button>
                                
                                <AnimatePresence>
                                  {ratingSaveSuccess && (
                                    <motion.p 
                                      initial={{ opacity: 0, y: -5 }}
                                      animate={{ opacity: 1, y: 0 }}
                                      exit={{ opacity: 0 }}
                                      className="text-center text-[10px] text-emerald-400 mt-2 font-mono"
                                    >
                                      ✓ Your rating is synced & secure in Firestore!
                                    </motion.p>
                                  )}
                                </AnimatePresence>
                              </div>
                            ) : (
                              <div className="pt-2 bg-[#05050a]/50 p-4 rounded-xl border border-dashed border-white/10 text-center space-y-3">
                                <p className="text-[11px] text-yellow-400/80 leading-relaxed">
                                  ⚠️ Guests cannot rate dramas. Authenticate your account via secure Google Login to unlock personal rating cloud sync.
                                </p>
                                <button
                                  type="button"
                                  onClick={handleGoogleLogin}
                                  className="mx-auto px-4 py-2 bg-white text-black hover:bg-gray-100 rounded-lg text-xs font-bold flex items-center gap-1.5 transition duration-300 shadow-md cursor-pointer active:scale-95"
                                >
                                  <svg className="w-3.5 h-3.5" viewBox="0 0 24 24">
                                    <path fill="#EA4335" d="M12 5.04c1.66 0 3.2.57 4.38 1.69l3.27-3.27C17.68 1.54 14.98 1 12 1 7.35 1 3.37 3.67 1.39 7.56l3.87 3a6.99 6.99 0 0 1 6.74-5.52z"/>
                                    <path fill="#4285F4" d="M23.49 12.27c0-.81-.07-1.59-.2-2.36H12v4.51h6.44a5.5 5.5 0 0 1-2.39 3.61l3.71 2.87c2.17-2 3.73-4.94 3.73-8.63z"/>
                                    <path fill="#FBBC05" d="M5.26 14.75a7.01 7.01 0 0 1 0-4.14L1.39 7.61a11.96 11.96 0 0 0 0 10.53l3.87-3.39z"/>
                                    <path fill="#34A853" d="M12 23c3.24 0 5.97-1.07 7.96-2.91l-3.71-2.87c-1.03.69-2.35 1.11-4.25 1.11-3.21 0-5.93-2.17-6.9-5.11L1.23 16.5A11.97 11.97 0 0 0 12 23z"/>
                                  </svg>
                                  <span>Sign in with Google</span>
                                </button>
                              </div>
                            )}
                          </div>
                        </div>

                        {/* Episodes List array */}
                        <div className="space-y-3">
                          <div className="flex items-center justify-between mb-3">
                            <h4 className="text-sm font-bold text-gray-300">
                              Episode Sequence ({episodes.filter(e => e.drama_id === selectedDrama.id).length} Releases)
                            </h4>
                            <span className="text-[10px] bg-white/5 border border-white/10 text-gray-400 px-2 py-0.5 rounded font-mono">
                              1080p Streamtape Nodes
                            </span>
                          </div>
                          
                          {episodes.filter(e => e.drama_id === selectedDrama.id).length === 0 ? (
                            <div className="text-center text-gray-500 text-xs py-10 bg-[#05050a]/20 border border-white/5 rounded-xl">
                              <Film className="w-8 h-8 text-gray-700 mx-auto mb-2" />
                              <span>No episodes uploaded yet. Check back soon for fast streaming.</span>
                            </div>
                          ) : (
                            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                              {episodes.filter(e => e.drama_id === selectedDrama.id).sort((a,b)=>a.episode_number-b.episode_number).map(ep => {
                                const historyItem = watchHistory.find(item => item.episodeId === ep.id);
                                const isCompleted = historyItem?.completed;
                                const progressPercent = historyItem ? Math.min(100, Math.floor((historyItem.progressSeconds / 1800) * 100)) : 0; // estimate ep duration to 30 mins (1800s)

                                return (
                                  <div 
                                    key={ep.id}
                                    className="group relative bg-white/4 border border-white/8 hover:bg-purple-600/5 hover:border-purple-600/50 transition duration-300 rounded-xl overflow-hidden text-left shadow-md flex flex-col h-full"
                                  >
                                    {/* Clickable Card Body to play */}
                                    <div 
                                      onClick={() => {
                                        setSelectedEpisode(ep);
                                        setActiveTab('player');
                                        setCurrentTime(historyItem ? historyItem.progressSeconds : 0);
                                        setIsPlaying(true);
                                      }}
                                      className="cursor-pointer flex-1 flex flex-col w-full"
                                    >
                                      {/* Aspect-video 16:9 preview container */}
                                      <div className="relative aspect-video w-full bg-[#05050a] overflow-hidden border-b border-white/5">
                                        <img 
                                          src={getBunnyPreviewUrl(ep.streamtape_url, selectedDrama.poster_url)}
                                          onError={(e) => {
                                            e.currentTarget.src = selectedDrama.poster_url;
                                          }}
                                          alt={`Episode ${ep.episode_number} Preview`}
                                          className="w-full h-full object-cover group-hover:scale-105 transition duration-500"
                                          referrerPolicy="no-referrer"
                                        />
                                        
                                        {/* Play Hover Overlay */}
                                        <div className="absolute inset-0 bg-black/45 opacity-0 group-hover:opacity-100 transition duration-300 flex items-center justify-center">
                                          <div className="bg-purple-600/90 text-white p-2.5 rounded-full scale-90 group-hover:scale-100 transition duration-300 shadow-lg shadow-purple-600/30">
                                            <Play className="w-4 h-4 fill-white ml-0.5" />
                                          </div>
                                        </div>

                                        {/* Episode Number Badge on image */}
                                        <div className="absolute bottom-2 left-2 bg-black/75 backdrop-blur-md text-white text-[9px] font-bold px-2 py-0.5 rounded border border-white/10 font-mono font-bold">
                                          EP {ep.episode_number}
                                        </div>

                                        {/* mini progress bar */}
                                        {progressPercent > 0 && !isCompleted && (
                                          <div className="absolute bottom-0 left-0 right-0 h-1 bg-white/15">
                                            <div className="h-full bg-blue-500" style={{ width: `${progressPercent}%` }}></div>
                                          </div>
                                        )}
                                      </div>

                                      {/* Card body details */}
                                      <div className="p-3 flex flex-col justify-between flex-1 space-y-1.5 w-full bg-[#05050a]/20">
                                        <div className="space-y-0.5 w-full">
                                          <div className="flex items-center justify-between gap-2">
                                            <span className="text-xs font-bold text-white group-hover:text-blue-400 transition duration-200 truncate">
                                              Episode {ep.episode_number}
                                            </span>
                                            {isCompleted && (
                                              <span className="text-[9px] bg-green-500/20 text-green-400 font-semibold px-1.5 py-0.5 rounded font-mono shrink-0">
                                                Watched
                                              </span>
                                            )}
                                          </div>
                                          <div className="text-[11px] text-gray-400 line-clamp-1 group-hover:text-gray-300 transition duration-200">
                                            {ep.title || `Episode ${ep.episode_number}`}
                                          </div>
                                        </div>

                                        <div className="pt-1.5 border-t border-white/5 w-full flex items-center justify-between text-[10px]">
                                          <span className="text-blue-400 font-semibold font-mono flex items-center gap-1">
                                            Stream Now <span className="group-hover:translate-x-1 transition duration-200">→</span>
                                          </span>
                                          {progressPercent > 0 && !isCompleted && !ep.download_url && (
                                            <span className="text-gray-400 font-mono shrink-0">
                                              {progressPercent}% played
                                            </span>
                                          )}
                                        </div>
                                      </div>
                                    </div>

                                    {/* Separate Interactive Action for Download URL */}
                                    {ep.download_url && ep.download_url.trim() !== '' && (
                                      <div className="px-3 pb-3 pt-1 border-t border-white/5 bg-[#05050a]/40 flex items-center justify-between gap-2">
                                        <span className="text-[10px] text-gray-500 font-mono">Offline Link:</span>
                                        <a 
                                          href={ep.download_url}
                                          target="_blank"
                                          rel="noopener noreferrer"
                                          className="bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 hover:bg-emerald-500/20 hover:text-emerald-300 text-[10px] font-bold px-2.5 py-1 rounded-md flex items-center gap-1 transition duration-200"
                                          title="Download direct link"
                                        >
                                          <Download className="w-3 h-3" />
                                          <span>Download</span>
                                        </a>
                                      </div>
                                    )}
                                  </div>
                                );
                              })}
                            </div>
                          )}
                        </div>
                      </div>

                      {/* SECTION 2: Synopsis, Cast, and Trailers (Moved below Episode Section) */}
                      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                        <div className="lg:col-span-2 space-y-6">
                          <div className="bg-[#0a0a14]/65 border border-white/8 rounded-2xl p-6 md:p-8 shadow-xl backdrop-blur-md">
                            <h3 className="text-lg font-bold mb-4 border-b border-white/5 pb-2 text-white">
                              Storyline Synopsis
                            </h3>
                            <p className="text-gray-300 text-sm leading-relaxed mb-6 whitespace-pre-wrap">
                              {selectedDrama.description}
                            </p>
                            
                            <div className="border-t border-white/5 pt-4">
                              <h4 className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">
                                Cast Roster
                              </h4>
                              <p className="text-[#9ea2c0] font-mono text-xs leading-relaxed">
                                {selectedDrama.cast}
                              </p>
                            </div>
                          </div>

                          {/* Official Trailer Section */}
                          {selectedDrama.trailer_url && (
                            <div className="bg-[#0a0a14]/65 border border-white/8 rounded-2xl p-6 shadow-xl backdrop-blur-md">
                              <h3 className="text-base font-bold text-white mb-4 flex items-center gap-2">
                                <Play className="w-4 h-4 text-red-500 fill-red-500" />
                                <span>Official Trailer & Promotional Media</span>
                              </h3>
                              <div className="aspect-video w-full rounded-xl overflow-hidden border border-white/5">
                                <iframe 
                                  src={selectedDrama.trailer_url}
                                  title="Trailer" 
                                  className="w-full h-full"
                                  allowFullScreen
                                ></iframe>
                              </div>
                            </div>
                          )}
                        </div>

                        {/* SECTION 3: Reviews Panel (Moved below) */}
                        <div id="reviews-section" className="bg-[#0a0a14]/65 border border-white/8 rounded-2xl p-6 md:p-8 shadow-xl backdrop-blur-md h-fit">
                          <h3 className="text-lg font-bold mb-4 border-b border-white/5 pb-2 text-white">
                            Viewer Reviews ({reviews.filter(r => r.dramaId === selectedDrama.id).length})
                          </h3>

                          {/* Leave a review Form */}
                          <form onSubmit={handleAddReview} className="mb-6 space-y-4 pb-6 border-b border-white/5">
                            <div>
                              <label className="block text-xs text-gray-400 mb-1 font-medium font-mono">Your Score</label>
                              <select 
                                value={newReviewRating}
                                onChange={e => setNewReviewRating(Number(e.target.value))}
                                className="w-full bg-[#05050a] border border-white/8 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-purple-600 cursor-pointer"
                              >
                                <option value="10">10 (Masterpiece)</option>
                                <option value="9">9 (Great)</option>
                                <option value="8">8 (Very Good)</option>
                                <option value="7">7 (Good)</option>
                                <option value="6">6 (Fine)</option>
                                <option value="5">5 (Average)</option>
                              </select>
                            </div>
                            
                            <div>
                              <label className="block text-xs text-gray-400 mb-1 font-medium font-mono">Comments</label>
                              <textarea 
                                required
                                rows={3}
                                value={newReviewText}
                                onChange={e => setNewReviewText(e.target.value)}
                                placeholder="Write your review experience..."
                                className="w-full bg-[#05050a]/60 border border-white/8 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-purple-600 placeholder-gray-500"
                              ></textarea>
                            </div>
                            
                            <button 
                              type="submit" 
                              className="w-full bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-500 hover:to-blue-500 text-white text-xs py-2.5 rounded-xl font-bold transition duration-300 cursor-pointer shadow-md"
                            >
                              Submit Review
                            </button>
                          </form>

                          {/* Reviews list */}
                          <div className="space-y-4 max-h-[350px] overflow-y-auto pr-2">
                            {reviews.filter(r => r.dramaId === selectedDrama.id).length === 0 ? (
                              <div className="text-center text-gray-500 text-xs py-8">
                                No reviews submitted yet. Be the first to leave a review!
                              </div>
                            ) : (
                              reviews.filter(r => r.dramaId === selectedDrama.id).map((r, i) => (
                                <div key={i} className="bg-[#05050a]/40 border border-white/5 p-3 rounded-xl">
                                  <div className="flex justify-between items-center mb-1.5">
                                    <div className="text-xs font-bold text-white">
                                      {r.fullname} <span className="text-[#9ea2c0] font-mono text-[9px]">@{r.username}</span>
                                    </div>
                                    <div className="text-yellow-400 text-xs font-bold flex items-center gap-0.5">
                                      <Star className="w-3 h-3 fill-yellow-400" />
                                      <span>{r.rating}/10</span>
                                    </div>
                                  </div>
                                  <p className="text-gray-300 text-xs leading-relaxed">{r.text}</p>
                                  <span className="text-[9px] text-gray-500 mt-1.5 block font-mono">
                                    {r.createdAt}
                                  </span>
                                </div>
                              ))
                            )}
                          </div>
                        </div>
                      </div>

                    </div>
                  </div>
                </div>
              );
            })()}

            {/* TAB: PLAYLISTS VIEW */}
            {activeTab === 'playlists' && (
              <div className="container mx-auto px-6 md:px-12 py-10 animate-fade-in">
                <div className="mb-6 border-b border-white/5 pb-4">
                  <h1 className="text-3xl font-bold flex items-center gap-2">
                    <FolderPlus className="text-blue-400 w-8 h-8" />
                    <span>My Streaming Playlists</span>
                  </h1>
                  <p className="text-[#9ea2c0] text-sm mt-1">Organize and package your favorite drama series into custom folders.</p>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                  {/* Left Column: Create Playlist form */}
                  <div className="bg-[#0a0a14]/65 border border-white/8 rounded-2xl p-6 h-fit">
                    <h3 className="text-base font-bold text-white mb-4">Create New Playlist</h3>
                    <form onSubmit={createPlaylistLocal} className="space-y-4">
                      <div>
                        <label className="block text-xs text-gray-400 mb-1.5 font-medium">Playlist Name</label>
                        <input 
                          type="text"
                          required
                          value={activePlaylistInput}
                          onChange={e => setActivePlaylistInput(e.target.value)}
                          placeholder="e.g., K-Drama Romances"
                          className="w-full bg-white/4 border border-white/8 rounded-xl px-3 py-2 text-xs text-white focus:outline-none"
                        />
                      </div>
                      <div className="flex items-center gap-2">
                        <input 
                          type="checkbox"
                          checked={activePlaylistPrivate}
                          onChange={e => setActivePlaylistPrivate(e.target.checked)}
                          id="privateCheck"
                          className="accent-purple-600 rounded"
                        />
                        <label htmlFor="privateCheck" className="text-xs text-gray-400 cursor-pointer">Keep this playlist private</label>
                      </div>
                      <button type="submit" className="bg-gradient-to-r from-purple-600 to-blue-600 text-white text-xs font-semibold px-4 py-2 rounded-full cursor-pointer">
                        Create Folder Node
                      </button>
                    </form>
                  </div>

                  {/* Right Column: Playlists list folders */}
                  <div className="lg:col-span-2 space-y-6">
                    {playlists.length === 0 ? (
                      <div className="bg-[#0a0a14]/45 border border-white/5 p-12 rounded-2xl text-center text-gray-400">
                        <FolderPlus className="w-12 h-12 text-gray-600 mx-auto mb-3" />
                        <h4 className="font-bold text-white mb-1">No Custom Playlists</h4>
                        <p className="text-xs">Create your first folder using the control panel on the left.</p>
                      </div>
                    ) : (
                      playlists.map(pl => (
                        <div key={pl.id} className="bg-[#0a0a14]/65 border border-white/8 rounded-2xl p-6">
                          <div className="flex justify-between items-center mb-4 border-b border-white/5 pb-2">
                            <div>
                              <h4 className="text-base font-bold text-white">{pl.name}</h4>
                              <span className="text-[10px] text-gray-400 bg-white/4 border border-white/10 px-2 py-0.5 rounded-full uppercase">
                                {pl.isPrivate ? 'Private' : 'Public'} Folder ({pl.dramaIds.length} series)
                              </span>
                            </div>
                            <button 
                              onClick={() => deletePlaylistLocal(pl.id)}
                              className="text-red-400 hover:text-red-500 transition cursor-pointer"
                              title="Delete Playlist"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>

                          {/* Grid items inside playlist */}
                          {pl.dramaIds.length === 0 ? (
                            <div className="text-center py-4 text-xs text-gray-500">No dramas added into this playlist yet. Browse and add them from the catalog detail pages!</div>
                          ) : (
                            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                              {pl.dramaIds.map(id => {
                                const d = dramas.find(x => x.id === id);
                                if (!d) return null;
                                return (
                                  <div key={id} className="relative rounded-lg overflow-hidden border border-white/5 aspect-[2/3] group bg-black">
                                    <img src={d.poster_url} className="w-full h-full object-cover" />
                                    <div className="absolute inset-0 bg-black/60 flex flex-col justify-between p-2 opacity-0 group-hover:opacity-100 transition duration-200">
                                      <button 
                                        onClick={() => toggleDramaInPlaylist(pl.id, d.id)}
                                        className="bg-red-500 text-white rounded-full p-1 self-end text-[10px] hover:bg-red-600"
                                      >
                                        <X className="w-3 h-3" />
                                      </button>
                                      <span className="text-white text-[10px] font-bold text-truncate leading-tight block">{d.title}</span>
                                    </div>
                                  </div>
                                );
                              })}
                            </div>
                          )}
                        </div>
                      ))
                    )}
                  </div>
                </div>
              </div>
            )}

            {/* TAB: MY LIST VIEW (FAVORITES) */}
            {activeTab === 'mylist' && (
              <div className="container mx-auto px-6 md:px-12 py-10 animate-fade-in">
                <div className="mb-6 border-b border-white/5 pb-4">
                  <h1 className="text-3xl font-bold flex items-center gap-2">
                    <Heart className="text-red-500 w-8 h-8 fill-red-500 animate-pulse" />
                    <span>My List Favorites</span>
                  </h1>
                  <p className="text-[#9ea2c0] text-sm mt-1">Keep track of ongoing dramas or bookmark masterpiece episodes to watch again.</p>
                </div>

                {favorites.length === 0 ? (
                  <div className="bg-[#0a0a14]/45 border border-white/5 p-12 rounded-2xl text-center text-gray-400 max-w-2xl mx-auto">
                    <Heart className="w-12 h-12 text-gray-600 mx-auto mb-3" />
                    <h4 className="font-bold text-white mb-1">Your List is Currently Empty</h4>
                    <p className="text-xs mb-4">You haven't bookmarked any drama releases into your watchlist yet.</p>
                    <button onClick={() => setActiveTab('home')} className="bg-gradient-to-r from-purple-600 to-blue-600 text-white text-xs font-semibold px-4 py-2 rounded-full cursor-pointer">
                      Explore Releases
                    </button>
                  </div>
                ) : (
                  <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-6">
                    {favorites.map(id => {
                      const drama = dramas.find(x => x.id === id);
                      if (!drama) return null;
                      return (
                        <div key={id} className="group relative rounded-xl overflow-hidden cursor-pointer shadow-lg border border-white/5 aspect-[2/3] bg-[#0a0a14]">
                          <img src={drama.poster_url} className="w-full h-full object-cover" />
                          <div className="absolute inset-0 bg-gradient-to-t from-[#05050a] via-transparent opacity-0 group-hover:opacity-100 transition duration-300 flex flex-col justify-end p-3">
                            <h4 className="font-bold text-white text-xs leading-tight mb-1" onClick={() => setSelectedDrama(drama)}>{drama.title}</h4>
                            <div className="flex items-center justify-between">
                              <span className="text-[10px] text-gray-400">{drama.country}</span>
                              <button 
                                onClick={() => toggleFavoriteLocal(drama.id)}
                                className="text-red-500 hover:scale-110 transition"
                                title="Remove favorite"
                              >
                                <Heart className="w-4 h-4 fill-red-500" />
                              </button>
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            )}

            {/* TAB: WATCH HISTORY */}
            {activeTab === 'history' && (
              <div className="container mx-auto px-6 md:px-12 py-10 animate-fade-in">
                <div className="mb-6 border-b border-white/5 pb-4">
                  <h1 className="text-3xl font-bold flex items-center gap-2">
                    <History className="text-yellow-500 w-8 h-8" />
                    <span>Streaming Watch History</span>
                  </h1>
                  <p className="text-[#9ea2c0] text-sm mt-1">Review items you've watched or resume in-progress episodes.</p>
                </div>

                {watchHistory.length === 0 ? (
                  <div className="bg-[#0a0a14]/45 border border-white/5 p-12 rounded-2xl text-center text-gray-400 max-w-2xl mx-auto">
                    <History className="w-12 h-12 text-gray-600 mx-auto mb-3" />
                    <h4 className="font-bold text-white mb-1">No Watch History Found</h4>
                    <p className="text-xs mb-4">When you start streaming episodes on our platform, your timestamp logs will be recorded automatically!</p>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
                    {watchHistory.map((item, index) => {
                      const d = dramas.find(x => x.id === item.dramaId);
                      const ep = episodes.find(x => x.id === item.episodeId);
                      if (!d || !ep) return null;
                      return (
                        <div key={index} className="bg-[#0a0a14]/65 border border-white/8 rounded-xl p-3 flex flex-col justify-between">
                          <div className="relative overflow-hidden rounded-lg mb-2">
                            <img src={d.poster_url} className="w-full h-36 object-cover" />
                            <span className="absolute bottom-2 left-2 bg-black/80 px-2 py-0.5 rounded text-[10px] font-mono">
                              Episode {ep.episode_number}
                            </span>
                          </div>
                          <h5 className="font-bold text-white text-truncate mb-0.5">{d.title}</h5>
                          <p className="text-gray-400 text-[11px] text-truncate mb-3">{ep.title}</p>
                          
                          <div className="flex justify-between items-center text-xs mb-3 font-mono">
                            <span className="text-gray-500">Progress:</span>
                            <span className="text-blue-400">{Math.floor(item.progressSeconds / 60)}m {item.progressSeconds % 60}s</span>
                          </div>
                          
                          <button 
                            onClick={() => {
                              setSelectedDrama(d);
                              setSelectedEpisode(ep);
                              setCurrentTime(item.progressSeconds);
                              setActiveTab('player');
                              setIsPlaying(true);
                            }}
                            className="w-full bg-blue-500/10 hover:bg-blue-500/20 text-blue-400 rounded-full py-1.5 text-xs font-semibold"
                          >
                            Resume Stream
                          </button>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            )}

            {/* TAB: PROFILE VIEW */}
            {activeTab === 'profile' && currentUser && (
              <div className="container mx-auto px-6 md:px-12 py-10 animate-fade-in space-y-10">
                <div className="mb-6 border-b border-white/5 pb-4 flex flex-col md:flex-row md:items-center justify-between gap-4">
                  <div>
                    <h1 className="text-3xl font-bold flex items-center gap-2">
                      <User className="text-blue-400 w-8 h-8" />
                      <span>My Cloud Profile</span>
                    </h1>
                    <p className="text-[#9ea2c0] text-sm mt-1">Customize your streaming identity, view platform stats, and check real-time activity.</p>
                  </div>
                  {!auth.currentUser && (
                    <div className="bg-yellow-500/10 border border-yellow-500/25 rounded-xl p-3 max-w-sm text-xs text-yellow-400">
                      ⚠️ <strong>Guest Session:</strong> Profiles are transient in guest mode. Log in with Google to sync and lock in your custom credentials permanently.
                    </div>
                  )}
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                  {/* LEFT: User Info & Editor Card */}
                  <div className="bg-[#0a0a14]/65 border border-white/8 rounded-2xl p-6 h-fit space-y-6 backdrop-blur-md relative overflow-hidden">
                    <div className="absolute top-0 right-0 w-32 h-32 bg-purple-500/5 rounded-full blur-3xl pointer-events-none" />
                    
                    <div className="flex flex-col items-center text-center space-y-3 pb-4 border-b border-white/5">
                      <div className="relative">
                        <div className="w-24 h-24 rounded-full border-2 border-purple-500 overflow-hidden bg-purple-950 flex items-center justify-center">
                          {currentUser.photoURL || editPhotoURL ? (
                            <img 
                              src={editPhotoURL || currentUser.photoURL} 
                              alt="Avatar" 
                              className="w-full h-full object-cover" 
                              onError={(e) => {
                                e.currentTarget.src = '';
                                e.currentTarget.className = 'hidden';
                              }}
                              referrerPolicy="no-referrer"
                            />
                          ) : (
                            <span className="text-3xl font-bold text-white uppercase">{currentUser.fullname ? currentUser.fullname[0] : 'U'}</span>
                          )}
                        </div>
                        <div className="absolute bottom-0 right-0 bg-green-500 border border-[#0a0a14] w-4 h-4 rounded-full shadow-[0_0_8px_rgba(34,197,94,0.6)]" title="Online now"></div>
                      </div>

                      <div>
                        <h2 className="text-xl font-bold text-white">{currentUser.fullname}</h2>
                        <p className="text-xs text-gray-400 font-mono">@{currentUser.username}</p>
                        <p className="text-[10px] text-[#9ea2c0] mt-1">{currentUser.email}</p>
                      </div>

                      {/* Join Date rendering */}
                      <div className="flex items-center gap-1.5 justify-center text-[10px] text-gray-400 font-mono bg-white/5 py-1 px-3 rounded-full border border-white/5">
                        <Calendar className="w-3 h-3 text-purple-400" />
                        <span>Joined {currentUser.createdAt ? new Date(currentUser.createdAt).toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' }) : 'July 2026'}</span>
                      </div>

                      {currentUser.bio && (
                        <p className="text-xs text-gray-300 italic bg-[#05050a]/40 p-3 rounded-lg w-full leading-relaxed border border-white/5">
                          "{currentUser.bio}"
                        </p>
                      )}
                    </div>

                    {/* Edit Profile Form */}
                    {!isEditingProfile ? (
                      <button
                        onClick={() => {
                          setEditFullName(currentUser.fullname || '');
                          setEditUsername(currentUser.username || '');
                          setEditBio(currentUser.bio || '');
                          setEditPhotoURL(currentUser.photoURL || '');
                          setIsEditingProfile(true);
                        }}
                        className="w-full bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-600 hover:to-blue-600 text-white font-semibold py-2.5 rounded-xl text-xs transition active:scale-95 cursor-pointer flex items-center justify-center gap-1.5 shadow-lg shadow-purple-900/10"
                      >
                        <Edit className="w-3.5 h-3.5" />
                        <span>Edit Profile Identity</span>
                      </button>
                    ) : (
                      <form onSubmit={handleSaveProfile} className="space-y-4">
                        <div className="space-y-1">
                          <label className="block text-[10px] font-mono text-gray-400 uppercase tracking-wider">Full Name</label>
                          <input 
                            type="text"
                            required
                            value={editFullName}
                            onChange={e => setEditFullName(e.target.value)}
                            className="w-full bg-[#05050a] border border-white/8 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-purple-600"
                          />
                        </div>

                        <div className="space-y-1">
                          <label className="block text-[10px] font-mono text-gray-400 uppercase tracking-wider">Username</label>
                          <input 
                            type="text"
                            required
                            pattern="^[a-zA-Z0-9_]+$"
                            title="Only alphanumeric characters and underscores are allowed"
                            value={editUsername}
                            onChange={e => setEditUsername(e.target.value)}
                            className="w-full bg-[#05050a] border border-white/8 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-purple-600"
                          />
                        </div>

                        <div className="space-y-1">
                          <label className="block text-[10px] font-mono text-gray-400 uppercase tracking-wider">Bio Description</label>
                          <textarea 
                            rows={3}
                            value={editBio}
                            onChange={e => setEditBio(e.target.value)}
                            placeholder="Share your favorite genre or K-drama quote..."
                            className="w-full bg-[#05050a] border border-white/8 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-purple-600 placeholder-gray-600 resize-none"
                          />
                        </div>

                        <div className="space-y-1">
                          <label className="block text-[10px] font-mono text-gray-400 uppercase tracking-wider">Avatar Photo URL</label>
                          <input 
                            type="url"
                            value={editPhotoURL}
                            onChange={e => setEditPhotoURL(e.target.value)}
                            placeholder="https://images.unsplash.com/photo-..."
                            className="w-full bg-[#05050a] border border-white/8 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-purple-600 placeholder-gray-600"
                          />
                        </div>

                        <div className="flex gap-2 pt-2">
                          <button
                            type="submit"
                            className="flex-1 bg-emerald-600 hover:bg-emerald-500 text-white font-semibold py-2 rounded-lg text-xs transition cursor-pointer"
                          >
                            Save Updates
                          </button>
                          <button
                            type="button"
                            onClick={() => setIsEditingProfile(false)}
                            className="flex-1 bg-white/5 hover:bg-white/10 text-gray-300 py-2 rounded-lg text-xs transition cursor-pointer"
                          >
                            Cancel
                          </button>
                        </div>
                      </form>
                    )}
                  </div>

                  {/* CENTER & RIGHT: Stats, Real-Time Lists, & Live Feed */}
                  <div className="lg:col-span-2 space-y-8">
                    {/* Bento Stats Row */}
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                      <div className="bg-[#0a0a14]/45 border border-white/5 rounded-2xl p-4 text-center hover:border-purple-500/25 transition-all">
                        <Eye className="w-5 h-5 text-blue-400 mx-auto mb-1" />
                        <div className="text-xl font-mono font-bold text-white">
                          {allViews.filter(v => v.userId === (auth.currentUser ? auth.currentUser.uid : 'guest')).length}
                        </div>
                        <div className="text-[10px] text-gray-400">Total Views</div>
                      </div>
                      <div className="bg-[#0a0a14]/45 border border-white/5 rounded-2xl p-4 text-center hover:border-purple-500/25 transition-all">
                        <ThumbsUp className="w-5 h-5 text-cyan-400 mx-auto mb-1 fill-cyan-400/25" />
                        <div className="text-xl font-mono font-bold text-white">
                          {allLikes.filter(l => l.userId === (auth.currentUser ? auth.currentUser.uid : 'guest')).length}
                        </div>
                        <div className="text-[10px] text-gray-400">Total Likes</div>
                      </div>
                      <div className="bg-[#0a0a14]/45 border border-white/5 rounded-2xl p-4 text-center hover:border-purple-500/25 transition-all">
                        <Heart className="w-5 h-5 text-red-500 mx-auto mb-1 fill-red-500" />
                        <div className="text-xl font-mono font-bold text-white">
                          {allFavorites.filter(f => f.userId === (auth.currentUser ? auth.currentUser.uid : 'guest')).length}
                        </div>
                        <div className="text-[10px] text-gray-400">Total Favorites</div>
                      </div>
                      <div className="bg-[#0a0a14]/45 border border-white/5 rounded-2xl p-4 text-center hover:border-purple-500/25 transition-all">
                        <Star className="w-5 h-5 text-yellow-400 mx-auto mb-1 fill-yellow-400" />
                        <div className="text-xl font-mono font-bold text-white">
                          {ratings.filter(r => r.userId === (auth.currentUser ? auth.currentUser.uid : 'guest')).length}
                        </div>
                        <div className="text-[10px] text-gray-400">Total Ratings</div>
                      </div>
                    </div>

                    {/* SECTION: CONTINUE WATCHING */}
                    <div 
                      id="profile-continue-watching-section" 
                      className="bg-[#0a0a14]/65 border border-white/8 rounded-2xl p-6 backdrop-blur-md space-y-4"
                    >
                      <h3 className="text-base font-bold text-white flex items-center gap-2">
                        <Play className="w-4 h-4 text-green-400" />
                        <span>Continue Watching</span>
                      </h3>
                      
                      {watchHistory.filter(item => !item.completed).length === 0 ? (
                        <div className="text-center py-6 text-xs text-gray-500 bg-[#05050a]/20 border border-white/5 rounded-xl">
                          No active series in continue watching. Browse dramas to start streaming!
                        </div>
                      ) : (
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                          {watchHistory
                            .filter(item => !item.completed)
                            .map((item, index) => {
                              const d = dramas.find(x => x.id === item.dramaId);
                              const ep = episodes.find(x => x.id === item.episodeId);
                              if (!d || !ep) return null;
                              
                              const progressPct = Math.min(100, Math.max(10, Math.floor((item.progressSeconds / 1800) * 100)));

                              return (
                                <div key={`cw_${item.episodeId}_${index}`} className="flex flex-col p-3 bg-[#05050a]/40 border border-white/5 rounded-xl gap-3 hover:bg-white/4 transition duration-300">
                                  <div className="flex gap-3">
                                    <img src={d.poster_url} alt={d.title} className="w-12 h-16 rounded-lg object-cover border border-white/10" />
                                    <div className="flex flex-col justify-center text-left truncate">
                                      <h4 className="text-xs font-bold text-white truncate">{d.title}</h4>
                                      <span className="text-[10px] text-purple-300 font-mono mt-0.5">Ep {ep.episode_number}: {ep.title}</span>
                                      <span className="text-[9px] text-gray-500 mt-1">Paused at {Math.floor(item.progressSeconds / 60)}m</span>
                                    </div>
                                  </div>
                                  
                                  {/* Progress Bar */}
                                  <div className="space-y-1">
                                    <div className="h-1.5 w-full bg-white/5 rounded-full overflow-hidden">
                                      <div className="h-full bg-gradient-to-r from-purple-500 to-blue-500" style={{ width: `${progressPct}%` }} />
                                    </div>
                                    <div className="flex justify-between items-center text-[9px] text-gray-400">
                                      <span>Progress: {progressPct}%</span>
                                      <button 
                                        onClick={() => {
                                          setSelectedDrama(d);
                                          setSelectedEpisode(ep);
                                          setCurrentTime(item.progressSeconds);
                                          setActiveTab('player');
                                          setIsPlaying(true);
                                        }}
                                        className="text-purple-400 hover:text-purple-300 font-semibold uppercase tracking-wider cursor-pointer"
                                      >
                                        Resume Play
                                      </button>
                                    </div>
                                  </div>
                                </div>
                              );
                            })}
                        </div>
                      )}
                    </div>

                    {/* SECTION: FAVORITE DRAMAS */}
                    <div 
                      id="profile-favorites-section" 
                      className="bg-[#0a0a14]/65 border border-white/8 rounded-2xl p-6 backdrop-blur-md space-y-4"
                    >
                      <h3 className="text-base font-bold text-white flex items-center gap-2">
                        <Heart className="w-4 h-4 text-red-500 fill-red-500" />
                        <span>My Favorite Dramas</span>
                      </h3>
                      
                      {dramas.filter(d => allFavorites.some(f => f.dramaId === d.id && f.userId === (auth.currentUser ? auth.currentUser.uid : 'guest'))).length === 0 ? (
                        <div className="text-center py-6 text-xs text-gray-500 bg-[#05050a]/20 border border-white/5 rounded-xl">
                          You haven't favorited any dramas yet. Add them to your watchlist to see them here!
                        </div>
                      ) : (
                        <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
                          {dramas
                            .filter(d => allFavorites.some(f => f.dramaId === d.id && f.userId === (auth.currentUser ? auth.currentUser.uid : 'guest')))
                            .map((drama) => (
                              <div 
                                key={`fav_d_${drama.id}`} 
                                onClick={() => {
                                  setSelectedDrama(drama);
                                  setActiveTab('home');
                                }}
                                className="group cursor-pointer p-2.5 bg-[#05050a]/40 border border-white/5 rounded-xl hover:bg-white/4 transition duration-300 flex flex-col items-center text-center space-y-2"
                              >
                                <div className="w-full aspect-[3/4] rounded-lg overflow-hidden relative border border-white/5">
                                  <img src={drama.poster_url} alt={drama.title} className="w-full h-full object-cover group-hover:scale-105 transition duration-300" />
                                  <div className="absolute top-2 right-2 p-1.5 bg-red-600/95 rounded-full border border-red-500/20">
                                    <Heart className="w-3 h-3 text-white fill-white" />
                                  </div>
                                </div>
                                <div className="w-full truncate">
                                  <h4 className="text-xs font-bold text-white truncate group-hover:text-purple-400 transition">{drama.title}</h4>
                                  <span className="text-[9px] text-gray-400 block mt-0.5">{drama.genre}</span>
                                </div>
                              </div>
                            ))}
                        </div>
                      )}
                    </div>

                    {/* SECTION: RATED DRAMAS */}
                    <div 
                      id="profile-ratings-section" 
                      className="bg-[#0a0a14]/65 border border-white/8 rounded-2xl p-6 backdrop-blur-md space-y-6"
                    >
                      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 border-b border-white/5 pb-4">
                        <div className="flex items-center gap-2">
                          <Star className="w-5 h-5 text-yellow-400 fill-yellow-400" />
                          <h3 className="text-base font-bold text-white">My Ratings & Catalog History</h3>
                        </div>
                        
                        {/* Summary / Stats Badge */}
                        {auth.currentUser && ratings.filter(r => r.userId === auth.currentUser.uid).length > 0 && (
                          <div className="flex items-center gap-2 bg-purple-500/10 border border-purple-500/20 px-3 py-1 rounded-full text-xs text-purple-300 font-mono">
                            <span>Avg Given:</span>
                            <span className="font-bold text-yellow-400">
                              {(
                                ratings
                                  .filter(r => r.userId === auth.currentUser?.uid)
                                  .reduce((acc, r) => acc + r.rating, 0) /
                                ratings.filter(r => r.userId === auth.currentUser?.uid).length
                              ).toFixed(1)} ⭐
                            </span>
                          </div>
                        )}
                      </div>
                      
                      {ratings.filter(r => r.userId === (auth.currentUser ? auth.currentUser.uid : 'guest')).length === 0 ? (
                        <div className="text-center py-8 text-xs text-gray-500 bg-[#05050a]/20 border border-white/5 rounded-xl">
                          You haven't submitted any drama ratings yet. Rate dramas out of 10.0 on the explore details page to record them!
                        </div>
                      ) : (
                        <div className="space-y-6">
                          {/* Recently Rated Section */}
                          <div className="space-y-3">
                            <h4 className="text-xs font-semibold text-gray-400 uppercase tracking-wider font-mono">Recently Rated</h4>
                            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                              {ratings
                                .filter(r => r.userId === (auth.currentUser ? auth.currentUser.uid : 'guest'))
                                .sort((a, b) => new Date(b.createdAt || '').getTime() - new Date(a.createdAt || '').getTime())
                                .slice(0, 2)
                                .map((rating, index) => {
                                  const d = dramas.find(x => x.id === rating.dramaId);
                                  if (!d) return null;
                                  return (
                                    <div key={`recent_rate_${rating.dramaId}_${index}`} className="flex items-center gap-3 p-2.5 bg-[#05050a]/35 border border-white/5 rounded-xl">
                                      <img src={d.poster_url} alt="" className="w-10 h-12 rounded object-cover border border-white/10 shrink-0" />
                                      <div className="text-left truncate flex-1">
                                        <h4 className="text-xs font-bold text-white truncate">{d.title}</h4>
                                        <div className="flex items-center gap-1.5 mt-1">
                                          <span className="text-[10px] text-yellow-400 font-mono font-bold flex items-center gap-0.5">
                                            <Star className="w-3 h-3 fill-yellow-400 text-yellow-400" />
                                            {rating.rating.toFixed(1)}
                                          </span>
                                          <span className="text-[9px] text-gray-600">|</span>
                                          <span className="text-[9px] text-gray-500 font-mono">
                                            {rating.createdAt ? new Date(rating.createdAt).toLocaleDateString() : 'Recent'}
                                          </span>
                                        </div>
                                      </div>
                                    </div>
                                  );
                                })}
                            </div>
                          </div>

                          {/* All Rated Dramas list with Inline Editor */}
                          <div className="space-y-3 pt-2">
                            <h4 className="text-xs font-semibold text-gray-400 uppercase tracking-wider font-mono">All Rated Dramas</h4>
                            <div className="space-y-2 max-h-80 overflow-y-auto pr-2 custom-scrollbar">
                              {ratings
                                .filter(r => r.userId === (auth.currentUser ? auth.currentUser.uid : 'guest'))
                                .sort((a, b) => new Date(b.createdAt || '').getTime() - new Date(a.createdAt || '').getTime())
                                .map((rating, index) => {
                                  const d = dramas.find(x => x.id === rating.dramaId);
                                  if (!d) return null;
                                  const isEditing = editingProfileRatingId === rating.dramaId;
                                  return (
                                    <div key={`rate_log_${rating.dramaId}_${index}`} className="flex flex-col p-3 bg-[#05050a]/40 border border-white/5 rounded-xl hover:border-white/10 transition duration-200">
                                      <div className="flex items-center justify-between gap-3">
                                        <div className="flex items-center gap-3 truncate">
                                          <img src={d.poster_url} alt="" className="w-8 h-10 rounded object-cover border border-white/5 shrink-0" />
                                          <div className="text-left truncate">
                                            <h4 className="text-xs font-bold text-white truncate">{d.title}</h4>
                                            <span className="text-[9px] text-gray-500 block mt-0.5 font-mono">
                                              Rated on {rating.createdAt ? new Date(rating.createdAt).toLocaleDateString() : 'Recent'}
                                            </span>
                                          </div>
                                        </div>
                                        
                                        <div className="flex items-center gap-3">
                                          <div className="flex items-center gap-1 bg-yellow-400/10 border border-yellow-400/20 px-2.5 py-1 rounded-lg">
                                            <Star className="w-3.5 h-3.5 text-yellow-400 fill-yellow-400" />
                                            <span className="text-xs font-bold font-mono text-yellow-400">{rating.rating.toFixed(1)}/10</span>
                                          </div>
                                          
                                          {auth.currentUser && !isEditing && (
                                            <button
                                              onClick={() => {
                                                setEditingProfileRatingId(rating.dramaId);
                                                setTempProfileRatingVal(rating.rating);
                                              }}
                                              className="p-1.5 hover:bg-white/5 rounded-lg text-[10px] text-purple-400 hover:text-purple-300 font-semibold font-mono border border-purple-500/20 hover:border-purple-500/40 transition cursor-pointer"
                                              title="Update rating value"
                                            >
                                              Update
                                            </button>
                                          )}
                                        </div>
                                      </div>

                                      {/* Inline rating editor */}
                                      {isEditing && (
                                        <div className="mt-3 pt-3 border-t border-white/5 space-y-3 bg-[#05050a]/20 p-2.5 rounded-lg">
                                          <div className="flex items-center justify-between text-[11px] text-gray-400 font-mono">
                                            <span>Adjust Rating:</span>
                                            <div className="flex items-center gap-1 bg-[#05050a] px-2 py-0.5 rounded border border-white/5">
                                              <button 
                                                type="button"
                                                onClick={() => setTempProfileRatingVal(prev => Math.max(1.0, Math.round((prev - 0.1) * 10) / 10))}
                                                className="p-1 text-gray-400 hover:text-white hover:bg-white/5 rounded transition cursor-pointer"
                                              >
                                                <Minus className="w-2.5 h-2.5" />
                                              </button>
                                              <span className="px-1 text-yellow-400 font-bold font-mono">{tempProfileRatingVal.toFixed(1)}</span>
                                              <button 
                                                type="button"
                                                onClick={() => setTempProfileRatingVal(prev => Math.min(10.0, Math.round((prev + 0.1) * 10) / 10))}
                                                className="p-1 text-gray-400 hover:text-white hover:bg-white/5 rounded transition cursor-pointer"
                                              >
                                                <Plus className="w-2.5 h-2.5" />
                                              </button>
                                            </div>
                                          </div>

                                          <div className="flex items-center gap-3">
                                            <input 
                                              type="range" 
                                              min="1.0" 
                                              max="10.0" 
                                              step="0.1" 
                                              value={tempProfileRatingVal} 
                                              onChange={(e) => setTempProfileRatingVal(Number(e.target.value))}
                                              className="flex-1 accent-purple-500 bg-white/5 h-1 rounded cursor-pointer"
                                            />
                                            
                                            <div className="flex gap-1.5 shrink-0">
                                              <button
                                                type="button"
                                                disabled={isSavingProfileRating}
                                                onClick={() => submitProfileRating(rating.dramaId, tempProfileRatingVal)}
                                                className="bg-emerald-600 hover:bg-emerald-500 text-white font-bold px-3 py-1.5 rounded-lg text-[10px] transition cursor-pointer flex items-center gap-1"
                                              >
                                                {isSavingProfileRating ? <Loader2 className="w-3 h-3 animate-spin" /> : <Check className="w-3 h-3 stroke-[2.5]" />}
                                                <span>Save</span>
                                              </button>
                                              <button
                                                type="button"
                                                onClick={() => setEditingProfileRatingId(null)}
                                                className="bg-white/5 hover:bg-white/10 text-gray-400 hover:text-white px-2.5 py-1.5 rounded-lg text-[10px] transition cursor-pointer"
                                              >
                                                Cancel
                                              </button>
                                            </div>
                                          </div>
                                        </div>
                                      )}
                                    </div>
                                  );
                                })}
                            </div>
                          </div>
                        </div>
                      )}
                    </div>

                    {/* SECTION: WATCH HISTORY LOGS */}
                    <div 
                      id="profile-history-section" 
                      className="bg-[#0a0a14]/65 border border-white/8 rounded-2xl p-6 backdrop-blur-md space-y-4"
                    >
                      <h3 className="text-base font-bold text-white flex items-center gap-2">
                        <History className="w-4 h-4 text-blue-400" />
                        <span>Watch History Stream Logs</span>
                      </h3>
                      
                      {watchHistory.length === 0 ? (
                        <div className="text-center py-6 text-xs text-gray-500 bg-[#05050a]/20 border border-white/5 rounded-xl">
                          No viewing history logged on this profile yet.
                        </div>
                      ) : (
                        <div className="space-y-2.5 max-h-[300px] overflow-y-auto pr-2 font-mono text-xs">
                          {watchHistory.map((item, index) => {
                            const d = dramas.find(x => x.id === item.dramaId);
                            const ep = episodes.find(x => x.id === item.episodeId);
                            if (!d || !ep) return null;
                            return (
                              <div key={`history_item_${item.episodeId}_${index}`} className="flex flex-col sm:flex-row sm:items-center justify-between p-3 bg-[#05050a]/40 border border-white/5 rounded-xl gap-3 hover:bg-white/4 transition duration-200 text-left">
                                <div className="space-y-1">
                                  <div className="text-white font-bold">{d.title}</div>
                                  <div className="text-[10px] text-purple-400">
                                    Episode {ep.episode_number}: {ep.title} 
                                    <span className="text-gray-500 mx-1.5">•</span> 
                                    {item.completed ? (
                                      <span className="text-green-400 font-bold">Completed</span>
                                    ) : (
                                      <span className="text-gray-400">Watched up to {Math.floor(item.progressSeconds / 60)}m</span>
                                    )}
                                  </div>
                                </div>
                                <div className="flex items-center gap-3 self-end sm:self-auto">
                                  <span className="text-[10px] text-gray-500">
                                    {item.updatedAt ? new Date(item.updatedAt).toLocaleDateString([], { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' }) : 'Recent'}
                                  </span>
                                  <button
                                    onClick={() => {
                                      setSelectedDrama(d);
                                      setSelectedEpisode(ep);
                                      setCurrentTime(item.progressSeconds);
                                      setActiveTab('player');
                                      setIsPlaying(true);
                                    }}
                                    className="px-3 py-1 bg-purple-600/20 hover:bg-purple-600 text-purple-400 hover:text-white border border-purple-500/20 rounded-lg text-[10px] font-semibold transition cursor-pointer"
                                  >
                                    Replay
                                  </button>
                                </div>
                              </div>
                            );
                          })}
                        </div>
                      )}
                    </div>

                    {/* LIVE PLATFORM-WIDE FEED */}
                    <div className="bg-[#0a0a14]/65 border border-white/8 rounded-2xl p-6 backdrop-blur-md">
                      <div className="flex items-center justify-between border-b border-white/5 pb-3 mb-4">
                        <h3 className="text-sm font-bold text-white flex items-center gap-2">
                          <Sparkles className="w-4 h-4 text-purple-400 animate-pulse" />
                          <span>Live Platform-Wide Feed</span>
                        </h3>
                        <span className="text-[10px] bg-green-500/10 border border-green-500/30 text-green-400 px-2.5 py-0.5 rounded-full font-mono flex items-center gap-1.5 animate-pulse">
                          <span className="h-1.5 w-1.5 bg-green-400 rounded-full"></span>
                          <span>Streaming Live</span>
                        </span>
                      </div>

                      <div className="space-y-4 max-h-[250px] overflow-y-auto pr-2">
                        {allLikes.length === 0 && ratings.length === 0 && allFavorites.length === 0 ? (
                          <div className="text-center py-12 text-xs text-gray-500">
                            No recent activity recorded on the platform yet. Be the first to interact!
                          </div>
                        ) : (
                          <div className="space-y-3 font-mono text-xs">
                            {[
                              ...allLikes.map(l => ({ type: 'like', dramaId: l.dramaId, userId: l.userId, id: `like_${l.dramaId}_${l.userId}` })),
                              ...allFavorites.map(f => ({ type: 'fav', dramaId: f.dramaId, userId: f.userId, id: `fav_${f.dramaId}_${f.userId}` })),
                              ...ratings.map(r => ({ type: 'rate', dramaId: r.dramaId, userId: r.userId, rating: r.rating, id: `rate_${r.dramaId}_${r.userId}` }))
                            ].slice(-12).reverse().map((activity) => {
                              const d = dramas.find(x => x.id === activity.dramaId);
                              if (!d) return null;
                              return (
                                <div key={activity.id} className="flex items-center justify-between p-2.5 bg-[#05050a]/40 border border-white/5 rounded-xl gap-2 hover:bg-white/4 transition duration-200">
                                  <div className="flex items-center gap-2 truncate text-left">
                                    {activity.type === 'like' ? (
                                      <ThumbsUp className="w-3.5 h-3.5 text-blue-400 shrink-0" />
                                    ) : activity.type === 'fav' ? (
                                      <Heart className="w-3.5 h-3.5 text-red-500 fill-red-500 shrink-0" />
                                    ) : (
                                      <Star className="w-3.5 h-3.5 text-yellow-400 fill-yellow-400 shrink-0" />
                                    )}
                                    <span className="truncate text-gray-300">
                                      {activity.userId === (auth.currentUser ? auth.currentUser.uid : 'guest') ? (
                                        <strong className="text-white">You</strong>
                                      ) : (
                                        <span>User_{activity.userId.substring(0, 6)}</span>
                                      )}
                                      {activity.type === 'like' ? ' liked ' : activity.type === 'fav' ? ' bookmarked ' : ` rated ${activity.rating}/10 on `}
                                      <span className="text-purple-400 font-bold">{d.title}</span>
                                    </span>
                                  </div>
                                  <span className="text-[10px] text-gray-500 shrink-0">Live</span>
                                </div>
                              );
                            })}
                          </div>
                        )}
                      </div>
                    </div>

                  </div>
                </div>
              </div>
            )}

            {/* TAB: CUSTOM VIDEO PLAYER VIEW */}
            {activeTab === 'player' && selectedEpisode && selectedDrama && (() => {
              const getEpisodeProgress = (episodeId: number) => {
                const historyItem = watchHistory.find(item => item.episodeId === episodeId);
                return historyItem && !historyItem.completed ? historyItem.progressSeconds : 0;
              };

              // Sort related dramas by matching genre and country
              const relatedDramas = dramas
                .filter(d => d.id !== selectedDrama.id)
                .sort((a, b) => {
                  let scoreA = 0;
                  let scoreB = 0;
                  if (a.genre === selectedDrama.genre) scoreA += 2;
                  if (a.country === selectedDrama.country) scoreA += 1;
                  if (b.genre === selectedDrama.genre) scoreB += 2;
                  if (b.country === selectedDrama.country) scoreB += 1;
                  return scoreB - scoreA;
                })
                .slice(0, 4);

              return (
                <div className="w-full max-w-7xl mx-auto px-4 sm:px-6 md:px-12 py-6 animate-fade-in space-y-8">
                  {/* Back Navigation Bar */}
                  <div className="flex items-center justify-between">
                    <button 
                      onClick={handleBack}
                      className="bg-white/5 hover:bg-white/10 text-xs text-gray-300 hover:text-white px-4 py-2 rounded-xl flex items-center gap-1.5 transition active:scale-95 cursor-pointer backdrop-blur-md border border-white/5 font-semibold"
                    >
                      <ChevronLeft className="w-4 h-4 text-purple-400" />
                      <span>Back</span>
                    </button>

                    {/* Integrated Multi-Language/Audio Selector next to player screen */}
                    {audioTracks.length > 1 && (
                      <div className="relative">
                        <button
                          onClick={() => setIsAudioDropdownOpen(!isAudioDropdownOpen)}
                          className="bg-purple-600/10 hover:bg-purple-600/20 text-purple-400 border border-purple-500/20 text-xs font-semibold px-4 py-2 rounded-xl flex items-center gap-1.5 cursor-pointer transition select-none active:scale-95"
                        >
                          <Headphones className="w-4 h-4 animate-pulse" />
                          <span>🎧 Audio: {audioTracks.find(t => t.code === selectedAudioCode)?.name || 'Original'}</span>
                          <ChevronRight className={`w-3.5 h-3.5 text-purple-400 transition-transform duration-300 ${isAudioDropdownOpen ? 'rotate-90' : ''}`} />
                        </button>

                        <AnimatePresence>
                          {isAudioDropdownOpen && (
                            <>
                              <div className="fixed inset-0 z-40" onClick={() => setIsAudioDropdownOpen(false)} />
                              <motion.div
                                initial={{ opacity: 0, y: 10, scale: 0.95 }}
                                animate={{ opacity: 1, y: 0, scale: 1 }}
                                exit={{ opacity: 0, y: 10, scale: 0.95 }}
                                className="absolute right-0 top-full mt-2 z-50 w-56 bg-[#090916]/95 border border-white/10 rounded-xl p-2.5 shadow-2xl backdrop-blur-xl"
                              >
                                <div className="px-3 py-1.5 border-b border-white/5 mb-1.5 flex items-center gap-2">
                                  <Languages className="w-4 h-4 text-purple-400" />
                                  <span className="text-[10px] font-bold text-gray-300 uppercase tracking-wider">Select Audio Language</span>
                                </div>
                                <div className="space-y-0.5 max-h-48 overflow-y-auto">
                                  {audioTracks.map(track => {
                                    const isSelected = selectedAudioCode === track.code;
                                    return (
                                      <button
                                        key={track.code}
                                        onClick={() => {
                                          handleLanguageChange(track.code, track.name);
                                          setIsAudioDropdownOpen(false);
                                        }}
                                        className={`w-full flex items-center justify-between px-3 py-2 rounded-xl text-left text-xs transition cursor-pointer ${
                                          isSelected 
                                            ? 'bg-purple-600/20 text-purple-300 font-semibold border border-purple-500/10' 
                                            : 'text-gray-400 hover:text-white hover:bg-white/5 border border-transparent'
                                        }`}
                                      >
                                        <span>{track.name}</span>
                                        {isSelected && <Check className="w-3.5 h-3.5 text-purple-400" />}
                                      </button>
                                    );
                                  })}
                                </div>
                              </motion.div>
                            </>
                          )}
                        </AnimatePresence>
                      </div>
                    )}
                  </div>

                  {/* 🎬 Video Player (16:9 Full Width) */}
                  <div id="video-player-container" className="w-full relative animate-fade-in scroll-mt-24">
                    <div className="bg-black aspect-video rounded-xl sm:rounded-2xl overflow-hidden relative border border-white/5 shadow-[0_20px_50px_rgba(168,85,247,0.12)] flex items-center justify-center">
                      {!selectedEpisode.streamtape_url || 
                       selectedEpisode.streamtape_url.trim() === '' || 
                       selectedEpisode.streamtape_url.trim() === '#' || 
                       selectedEpisode.streamtape_url.toLowerCase().includes('placeholder') || 
                       videoUnavailable ? (
                        <div className="absolute inset-0 z-20 flex flex-col items-center justify-center p-6 text-center bg-[#070710]/95 backdrop-blur-md border border-red-500/10 space-y-4">
                          <div className="p-4 bg-red-500/10 rounded-full text-red-400 border border-red-500/15 animate-pulse">
                            <ShieldAlert className="w-8 h-8" />
                          </div>
                          <div className="space-y-1 max-w-md">
                            <h3 className="text-base font-bold text-white">Video is currently unavailable</h3>
                            <p className="text-xs text-gray-400">
                              The streaming resource for this episode is offline, requires external authorization, or embedding is restricted by the provider.
                            </p>
                          </div>
                          
                          <div className="flex flex-wrap gap-3 justify-center pt-2">
                            <button 
                              onClick={() => {
                                setVideoUnavailable(false);
                                showToast('Retrying secure media stream connection...', 'info');
                              }}
                              className="bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs px-4 py-2 rounded-xl transition cursor-pointer flex items-center gap-1.5 shadow-[0_4px_12px_rgba(147,51,234,0.3)]"
                            >
                              <RotateCw className="w-3.5 h-3.5 animate-spin-slow" />
                              <span>Retry Connection</span>
                            </button>
                            
                            {selectedEpisode.streamtape_url && selectedEpisode.streamtape_url !== '#' && (
                              <a 
                                href={selectedEpisode.streamtape_url} 
                                target="_blank" 
                                rel="noopener noreferrer"
                                className="bg-white/5 border border-white/10 hover:bg-white/10 text-white font-bold text-xs px-4 py-2 rounded-xl transition flex items-center gap-1.5 cursor-pointer"
                              >
                                <span>Open Direct Stream</span>
                                <Globe className="w-3.5 h-3.5 text-blue-400" />
                              </a>
                            )}
                          </div>
                        </div>
                      ) : (
                        <>
                          <div className="absolute inset-0 flex flex-col items-center justify-center bg-black/95 space-y-3 z-0">
                            <Loader2 className="w-10 h-10 text-purple-500 animate-spin" />
                            <span className="text-xs text-gray-400 font-medium">Initializing premium secure stream...</span>
                          </div>
                          
                          <iframe
                            id="bunny-player-iframe"
                            src={getEmbedUrlWithLang(
                              selectedEpisode.streamtape_url, 
                              selectedAudioCode, 
                              getEpisodeProgress(selectedEpisode.id)
                            )}
                            className="w-full h-full absolute inset-0 z-10 bg-black border-0"
                            allowFullScreen
                            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                            scrolling="no"
                            title={selectedEpisode.title}
                          />
                        </>
                      )}
                    </div>
                  </div>

                  {/* 📺 Episodes Playlist */}
                  <div className="bg-[#0a0a14]/50 border border-white/5 rounded-2xl p-6">
                    <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-6 pb-4 border-b border-white/5">
                      <div>
                        <h3 className="font-extrabold text-white text-lg tracking-tight flex items-center gap-2">
                          <Play className="w-5 h-5 text-purple-500 fill-purple-500" />
                          <span>Episodes Playlist</span>
                        </h3>
                        <p className="text-xs text-gray-400 mt-1">Select an episode to stream instantly. The player will scroll back up automatically.</p>
                      </div>
                      <div className="flex items-center gap-2">
                        <label className="flex items-center gap-2 text-xs text-gray-400 cursor-pointer select-none bg-white/5 hover:bg-white/8 border border-white/5 px-4 py-2 rounded-xl transition">
                          <input 
                            type="checkbox" 
                            checked={autoNext}
                            onChange={e => setAutoNext(e.target.checked)}
                            className="accent-purple-600 rounded" 
                          />
                          <span>Auto Play Next</span>
                        </label>
                      </div>
                    </div>
                    
                    <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-3">
                      {episodes
                        .filter(e => e.drama_id === selectedEpisode.drama_id)
                        .sort((a, b) => a.episode_number - b.episode_number)
                        .map(ep => {
                          const isSelected = ep.id === selectedEpisode.id;
                          const progress = getEpisodeProgress(ep.id);
                          const historyItem = watchHistory.find(item => item.episodeId === ep.id);
                          
                          return (
                            <button 
                              key={ep.id}
                              onClick={() => {
                                setSelectedEpisode(ep);
                                setCurrentTime(0);
                                setIsPlaying(true);
                                
                                setTimeout(() => {
                                  document.getElementById('video-player-container')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
                                }, 150);
                              }}
                              className={`text-left p-3.5 rounded-xl border transition relative flex flex-col justify-between h-24 select-none active:scale-95 cursor-pointer ${
                                isSelected 
                                  ? 'bg-purple-600/15 border-purple-500 text-white shadow-[0_0_15px_rgba(168,85,247,0.15)] scale-[1.02]' 
                                  : 'bg-white/4 border-white/5 hover:bg-white/8 hover:border-white/10 text-gray-300'
                              }`}
                            >
                              <div className="w-full">
                                <div className="font-extrabold text-xs flex items-center justify-between">
                                  <span>Ep {ep.episode_number}</span>
                                  {isSelected && (
                                    <span className="w-2 h-2 rounded-full bg-purple-400 animate-ping"></span>
                                  )}
                                  {historyItem?.completed && !isSelected && (
                                    <CheckCircle2 className="w-3.5 h-3.5 text-green-400 shrink-0" />
                                  )}
                                </div>
                                <div className="text-[10px] text-gray-400 line-clamp-2 mt-1.5 font-medium">
                                  {ep.title || `Episode ${ep.episode_number}`}
                                </div>
                              </div>
                              
                              {progress > 0 && !historyItem?.completed && (
                                <div className="w-full bg-white/10 h-1 rounded-full overflow-hidden mt-1.5">
                                  <div 
                                    className="bg-purple-500 h-full rounded-full"
                                    style={{ width: `${Math.min(100, Math.floor((progress / 1800) * 100))}%` }}
                                  />
                                </div>
                              )}
                            </button>
                          );
                        })}
                    </div>
                  </div>

                  {/* ❤️ Favorite, 👍 Like, ⭐ Rating, 👁 Views, 📤 Share */}
                  <div className="flex flex-wrap items-center justify-between gap-4 bg-[#0a0a14]/60 border border-white/5 p-4 rounded-2xl backdrop-blur-md shadow-lg">
                    <div className="flex flex-wrap items-center gap-2.5">
                      {/* Favorite Button */}
                      <button
                        onClick={() => toggleFavoriteLocal(selectedDrama.id)}
                        className={`px-4 py-2.5 rounded-xl border text-xs font-semibold flex items-center gap-2 transition cursor-pointer select-none active:scale-95 ${
                          favorites.includes(selectedDrama.id)
                            ? 'bg-red-500/10 border-red-500/30 text-red-400'
                            : 'bg-white/5 border-white/5 text-gray-300 hover:bg-white/8 hover:text-white'
                        }`}
                      >
                        <Heart className={`w-4 h-4 transition ${favorites.includes(selectedDrama.id) ? 'fill-red-500 text-red-500 scale-110' : 'text-gray-400'}`} />
                        <span>{favorites.includes(selectedDrama.id) ? 'Saved' : 'Favorite'}</span>
                      </button>

                      {/* Like Button */}
                      <button
                        onClick={() => toggleLike(selectedDrama.id)}
                        className={`px-4 py-2.5 rounded-xl border text-xs font-semibold flex items-center gap-2 transition cursor-pointer select-none active:scale-95 ${
                          auth.currentUser && allLikes.some(l => l.dramaId === selectedDrama.id && l.userId === auth.currentUser.uid)
                            ? 'bg-blue-500/10 border-blue-500/30 text-blue-400'
                            : 'bg-white/5 border-white/5 text-gray-300 hover:bg-white/8 hover:text-white'
                        }`}
                      >
                        <ThumbsUp className={`w-4 h-4 transition ${auth.currentUser && allLikes.some(l => l.dramaId === selectedDrama.id && l.userId === auth.currentUser.uid) ? 'fill-blue-500 text-blue-400 scale-110' : 'text-gray-400'}`} />
                        <span>{formatCount(allLikes.filter(l => l.dramaId === selectedDrama.id).length)} Likes</span>
                      </button>

                      {/* Rating Component */}
                      <div className="relative">
                        <button
                          onClick={() => setIsRatingOpen(!isRatingOpen)}
                          className="px-4 py-2.5 rounded-xl bg-white/5 hover:bg-white/8 border border-white/5 text-xs font-semibold flex items-center gap-2 text-yellow-400 select-none cursor-pointer active:scale-95 transition"
                        >
                          <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                          <span>Rating {getAverageRating(selectedDrama.id)} / 10</span>
                        </button>
                        
                        <AnimatePresence>
                          {isRatingOpen && (
                            <>
                              <div className="fixed inset-0 z-40" onClick={() => setIsRatingOpen(false)} />
                              <motion.div
                                initial={{ opacity: 0, y: 10, scale: 0.95 }}
                                animate={{ opacity: 1, y: 0, scale: 1 }}
                                exit={{ opacity: 0, y: 10, scale: 0.95 }}
                                className="absolute left-0 bottom-full mb-2 z-50 bg-[#090916] border border-white/10 p-3 rounded-xl shadow-2xl w-56 animate-fade-in flex flex-col backdrop-blur-xl"
                              >
                                <span className="text-[10px] font-bold text-gray-300 mb-2 uppercase tracking-wider">Rate this Series:</span>
                                <div className="flex gap-1.5 justify-between">
                                  {[2, 4, 6, 8, 10].map(starVal => (
                                    <button
                                      key={starVal}
                                      onClick={() => {
                                        submitRating(selectedDrama.id, starVal);
                                        setIsRatingOpen(false);
                                      }}
                                      className="flex-1 py-1 bg-white/5 hover:bg-yellow-400 hover:text-black rounded text-[11px] font-bold text-yellow-400 font-mono transition text-center cursor-pointer active:scale-90"
                                      title={`Rate ${starVal}/10`}
                                    >
                                      {starVal}
                                    </button>
                                  ))}
                                </div>
                              </motion.div>
                            </>
                          )}
                        </AnimatePresence>
                      </div>

                      {/* Views Display */}
                      <div className="px-4 py-2.5 rounded-xl bg-white/5 border border-white/5 text-xs font-semibold flex items-center gap-2 text-gray-300 select-none">
                        <Eye className="w-4 h-4 text-gray-400" />
                        <span>{formatCount(allViews.filter(v => v.dramaId === selectedDrama.id).length)} Views</span>
                      </div>
                    </div>

                    {/* Share Button */}
                    <button
                      onClick={() => {
                        navigator.clipboard.writeText(window.location.href);
                        showToast('Episode link copied to clipboard!', 'success');
                      }}
                      className="px-4 py-2.5 rounded-xl bg-white/5 hover:bg-white/8 border border-white/5 text-xs font-semibold flex items-center gap-2 text-gray-300 hover:text-white transition cursor-pointer select-none active:scale-95"
                    >
                      <Share className="w-4 h-4 text-purple-400" />
                      <span>Share</span>
                    </button>
                  </div>

                  {/* 📖 Description (Read More / Read Less) */}
                  <div className="bg-[#0a0a14]/50 border border-white/5 rounded-2xl p-6 space-y-4">
                    <div className="flex items-center gap-2 border-b border-white/5 pb-3">
                      <span className="text-[9px] bg-purple-500/15 text-purple-300 border border-purple-500/20 font-bold uppercase tracking-wider px-2 py-0.5 rounded-full">
                        {selectedDrama.country || "Drama"}
                      </span>
                      <span className="text-xs text-gray-400">Released in {selectedDrama.release_year}</span>
                      <span className="text-xs text-gray-400">• {selectedDrama.genre}</span>
                    </div>

                    <div className="space-y-3">
                      <h2 className="text-xl font-extrabold text-white tracking-tight">
                        Episode {selectedEpisode.episode_number}: {selectedEpisode.title || `Episode ${selectedEpisode.episode_number}`}
                      </h2>
                      
                      <div className="text-xs text-gray-300 leading-relaxed space-y-3 font-medium">
                        {selectedEpisode.description && (
                          <div className="border-l-2 border-purple-500 pl-3 py-1 bg-purple-500/5 rounded-r-xl">
                            <h4 className="text-[10px] font-bold text-purple-400 uppercase tracking-wider mb-0.5">Episode Synopsis</h4>
                            <p>{selectedEpisode.description}</p>
                          </div>
                        )}
                        
                        <div>
                          <h4 className="text-[10px] font-bold text-gray-400 uppercase tracking-wider mb-1">About the Series</h4>
                          <p className="transition-all duration-300">
                            {isDescExpanded 
                              ? selectedDrama.description 
                              : selectedDrama.description.length > 250 
                                ? `${selectedDrama.description.slice(0, 250)}...` 
                                : selectedDrama.description
                            }
                          </p>
                        </div>
                      </div>

                      {/* Cast Information */}
                      {selectedDrama.cast && (
                        <div className="pt-2 text-xs text-gray-400 border-t border-white/5">
                          <strong className="text-gray-300 font-semibold">Starring:</strong> {selectedDrama.cast}
                        </div>
                      )}

                      {selectedDrama.description.length > 250 && (
                        <div className="pt-2">
                          <button
                            onClick={() => setIsDescExpanded(!isDescExpanded)}
                            className="text-xs font-bold text-purple-400 hover:text-purple-300 transition cursor-pointer flex items-center gap-1 active:scale-95 bg-purple-500/5 px-3 py-1.5 rounded-xl border border-purple-500/10"
                          >
                            <span>{isDescExpanded ? 'Read Less' : 'Read More'}</span>
                            <ChevronRight className={`w-3.5 h-3.5 transition-transform duration-300 ${isDescExpanded ? '-rotate-90' : 'rotate-90'}`} />
                          </button>
                        </div>
                      )}
                    </div>
                  </div>

                  {/* 📥 Download (if available) */}
                  {selectedEpisode.download_url && 
                   selectedEpisode.download_url.trim() !== '' && 
                   selectedEpisode.download_url.trim() !== '#' && (
                    <div className="bg-gradient-to-r from-pink-500/10 via-purple-500/10 to-transparent border border-pink-500/15 rounded-2xl p-6 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 animate-fade-in shadow-md">
                      <div className="space-y-1">
                        <h4 className="font-extrabold text-white text-sm tracking-tight flex items-center gap-1.5">
                          <Download className="w-4 h-4 text-pink-400 animate-bounce" />
                          <span>Available for Offline Playback</span>
                        </h4>
                        <p className="text-[10px] text-gray-400">Download high-definition media file directly for offline watch anytime, anywhere.</p>
                      </div>
                      
                      <a 
                        href={selectedEpisode.download_url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="bg-pink-600 hover:bg-pink-500 text-white font-bold text-xs px-5 py-3 rounded-xl flex items-center justify-center gap-2 transition active:scale-95 cursor-pointer shadow-[0_4px_15px_rgba(219,39,119,0.3)] self-start sm:self-center shrink-0"
                      >
                        <Download className="w-4 h-4" />
                        <span>Download Episode {selectedEpisode.episode_number}</span>
                      </a>
                    </div>
                  )}

                  {/* 🎭 Related Dramas (Optional) */}
                  {relatedDramas.length > 0 && (
                    <div className="space-y-4">
                      <h3 className="font-extrabold text-white text-lg tracking-tight flex items-center gap-2">
                        <Sparkles className="w-5 h-5 text-purple-400" />
                        <span>More Like This</span>
                      </h3>
                      
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                        {relatedDramas.map(drama => {
                          const rating = getAverageRating(drama.id);
                          return (
                            <div 
                              key={drama.id}
                              onClick={() => {
                                setSelectedDrama(drama);
                                // Set first episode of this drama as current episode
                                const relatedEpisodes = episodes
                                  .filter(e => e.drama_id === drama.id)
                                  .sort((a, b) => a.episode_number - b.episode_number);
                                if (relatedEpisodes.length > 0) {
                                  setSelectedEpisode(relatedEpisodes[0]);
                                } else {
                                  setSelectedEpisode(null);
                                }
                                setCurrentTime(0);
                                setIsPlaying(true);
                                
                                setTimeout(() => {
                                  document.getElementById('video-player-container')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
                                }, 150);
                              }}
                              className="group bg-[#0a0a14]/40 border border-white/5 rounded-xl overflow-hidden cursor-pointer transition-all duration-300 hover:scale-[1.03] hover:border-purple-500/30 flex flex-col animate-fade-in"
                            >
                              <div className="aspect-[2/3] relative overflow-hidden bg-black/40">
                                <img 
                                  src={drama.poster_url || "https://images.unsplash.com/photo-1598899134739-24c46f58b8c0?auto=format&fit=crop&q=80&w=300"} 
                                  alt={drama.title}
                                  referrerPolicy="no-referrer"
                                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                                />
                                {rating && (
                                  <div className="absolute top-2 left-2 bg-black/75 backdrop-blur-md px-1.5 py-0.5 rounded-md flex items-center gap-1 text-[10px] text-yellow-400 font-bold border border-yellow-400/20">
                                    <Star className="w-3 h-3 fill-yellow-400 text-yellow-400" />
                                    <span>{rating}</span>
                                  </div>
                                )}
                              </div>
                              <div className="p-3 space-y-1 flex-1 flex flex-col justify-between">
                                <h4 className="font-extrabold text-xs text-white line-clamp-1 group-hover:text-purple-400 transition">
                                  {drama.title}
                                </h4>
                                <div className="flex items-center justify-between text-[10px] text-gray-500">
                                  <span>{drama.country}</span>
                                  <span>{drama.release_year}</span>
                                </div>
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  )}
                </div>
              );
            })()}

            {/* TAB: SECURE ADMIN SUITE (Rahul/rahul181A) */}
            {activeTab === 'admin_login' && (
              <div className="container mx-auto px-6 md:px-12 py-12 flex justify-center animate-fade-in">
                <div className="w-full max-w-md">
                  <div className="text-center mb-6">
                    <ShieldAlert className="w-12 h-12 text-red-500 mx-auto mb-2" />
                    <h1 className="text-3xl font-bold tracking-tight">Administrative Suite</h1>
                    <p className="text-gray-400 text-xs mt-1 uppercase font-mono tracking-wider">Control Console Access Gate</p>
                  </div>

                  <div className="bg-[#0a0a14]/65 border border-red-500/20 rounded-2xl p-6 md:p-8">
                    {authError && (
                      <div className="bg-red-500/10 border border-red-500/20 text-red-400 p-2 rounded text-xs text-center mb-4">
                        {authError}
                      </div>
                    )}
                    
                    <form onSubmit={handleAdminLogin} className="space-y-4">
                      <div>
                        <label className="block text-xs text-gray-400 mb-1">Admin Username</label>
                        <input 
                          type="text"
                          required
                          value={adminUsernameInput}
                          onChange={e => setAdminUsernameInput(e.target.value)}
                          placeholder="e.g., Rahul"
                          className="w-full bg-white/4 border border-white/8 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-red-500"
                        />
                      </div>
                      <div>
                        <label className="block text-xs text-gray-400 mb-1">Access Token Password</label>
                        <input 
                          type="password"
                          required
                          value={adminPasswordInput}
                          onChange={e => setAdminPasswordInput(e.target.value)}
                          placeholder="••••••"
                          className="w-full bg-white/4 border border-white/8 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-red-500"
                        />
                      </div>
                      <button type="submit" className="w-full bg-gradient-to-r from-red-600 to-purple-600 text-white py-2.5 rounded-xl text-xs font-semibold hover:opacity-90 transition cursor-pointer">
                        Authenticate Control Center
                      </button>

                      <div className="flex items-center my-3 text-xs text-gray-500">
                        <div className="flex-1 border-t border-white/5"></div>
                        <span className="px-3 uppercase tracking-wider text-[9px]">Or</span>
                        <div className="flex-1 border-t border-white/5"></div>
                      </div>

                      <button 
                        type="button"
                        onClick={handleGoogleLogin}
                        className="w-full bg-white text-black hover:bg-gray-100 py-2.5 rounded-xl text-xs font-semibold transition cursor-pointer flex items-center justify-center gap-2 shadow-lg"
                      >
                        <svg className="w-3.5 h-3.5" viewBox="0 0 24 24">
                          <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4"/>
                          <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/>
                          <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z" fill="#FBBC05"/>
                          <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z" fill="#EA4335"/>
                        </svg>
                        <span>Authenticate with Google</span>
                      </button>
                    </form>
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'admin_dash' && isAdminLogged && (
              <div className="container mx-auto px-6 md:px-12 py-10 animate-fade-in space-y-8">
                <div className="flex flex-col md:flex-row justify-between items-start md:items-center border-b border-white/5 pb-4">
                  <div>
                    <h1 className="text-2xl font-bold flex items-center gap-1.5">
                      <ShieldAlert className="w-7 h-7 text-red-500" />
                      <span>Admin Control Console</span>
                    </h1>
                    <p className="text-[#9ea2c0] text-xs mt-1">Configure database nodes, user profiles, and streaming catalogs.</p>
                  </div>
                  <button onClick={handleAdminLogout} className="bg-red-500/25 border border-red-500/30 text-red-400 text-xs px-4 py-2 rounded-full font-semibold mt-3 md:mt-0 cursor-pointer">
                    Sign Out of Admin Console
                  </button>
                </div>

                {/* Sub-tab Navigation */}
                <div className="flex border-b border-white/10 gap-6 pb-0.5">
                  <button
                    onClick={() => setAdminSubTab('catalog')}
                    className={`pb-3 text-xs font-semibold px-2 border-b-2 transition-all cursor-pointer ${adminSubTab === 'catalog' ? 'border-purple-600 text-white font-bold' : 'border-transparent text-gray-400 hover:text-white'}`}
                  >
                    Manage Catalog &amp; Users
                  </button>
                  <button
                    onClick={() => setAdminSubTab('streamtape')}
                    className={`pb-3 text-xs font-semibold px-2 border-b-2 transition-all cursor-pointer flex items-center gap-2 ${adminSubTab === 'streamtape' ? 'border-purple-600 text-white font-bold' : 'border-transparent text-gray-400 hover:text-white'}`}
                  >
                    <CloudUpload className="w-4 h-4 text-purple-400" />
                    <span>Streamtape Remote Upload Manager</span>
                    {uploadQueue.some(j => j.status === 'pending' || j.status === 'processing') ? (
                      <span className="flex h-2 w-2 relative">
                        <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-purple-400 opacity-75"></span>
                        <span className="relative inline-flex rounded-full h-2 w-2 bg-purple-500"></span>
                      </span>
                    ) : null}
                  </button>
                  <button
                    onClick={() => setAdminSubTab('storage')}
                    className={`pb-3 text-xs font-semibold px-2 border-b-2 transition-all cursor-pointer flex items-center gap-2 ${adminSubTab === 'storage' ? 'border-purple-600 text-white font-bold' : 'border-transparent text-gray-400 hover:text-white'}`}
                  >
                    <FolderOpen className="w-4 h-4 text-pink-400" />
                    <span>Firebase Storage Media Library</span>
                  </button>
                </div>

                {adminSubTab === 'catalog' ? (
                  <>

                {/* Dashboard Metrics Aggregation */}
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <div className="bg-[#0a0a14]/65 border border-white/8 rounded-xl p-4 text-center">
                    <div className="text-2xl font-mono text-blue-400 font-bold">{registeredUsers.length}</div>
                    <div className="text-[10px] text-gray-400 uppercase mt-0.5">Total Users</div>
                  </div>
                  <div className="bg-[#0a0a14]/65 border border-white/8 rounded-xl p-4 text-center">
                    <div className="text-2xl font-mono text-purple-400 font-bold">{dramas.length}</div>
                    <div className="text-[10px] text-gray-400 uppercase mt-0.5">Total Dramas</div>
                  </div>
                  <div className="bg-[#0a0a14]/65 border border-white/8 rounded-xl p-4 text-center">
                    <div className="text-2xl font-mono text-yellow-500 font-bold">{episodes.length}</div>
                    <div className="text-[10px] text-gray-400 uppercase mt-0.5">Total Episodes</div>
                  </div>
                  <div className="bg-[#0a0a14]/65 border border-white/8 rounded-xl p-4 text-center">
                    <div className="text-2xl font-mono text-green-500 font-bold">100%</div>
                    <div className="text-[10px] text-gray-400 uppercase mt-0.5">Server Integrity</div>
                  </div>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                  {/* Column Left: Add/Edit Drama Form & Episode upload */}
                  <div className="space-y-6">
                    {/* Add Drama Form */}
                    <div className="bg-[#0a0a14]/65 border border-white/8 rounded-2xl p-6">
                      <h3 className="font-bold text-white text-sm mb-4">{selectedDramaToEdit !== null ? 'Modify Drama Metadata' : 'Catalog New Drama'}</h3>
                      <form onSubmit={handleSaveDramaAdmin} className="space-y-3">
                        <div>
                          <input 
                            type="text" 
                            required
                            placeholder="Drama Title"
                            value={adminDramaTitle}
                            onChange={e => setAdminDramaTitle(e.target.value)}
                            className="w-full bg-white/4 border border-white/8 rounded-xl px-3 py-2 text-xs text-white"
                          />
                        </div>
                        <div>
                          <textarea 
                            required
                            rows={2}
                            placeholder="Synopsis Description"
                            value={adminDramaDesc}
                            onChange={e => setAdminDramaDesc(e.target.value)}
                            className="w-full bg-white/4 border border-white/8 rounded-xl px-3 py-2 text-xs text-white"
                          ></textarea>
                        </div>
                        <div className="space-y-3">
                          {/* Poster Section */}
                          <div className="bg-white/2 border border-white/5 rounded-xl p-3 space-y-2">
                            <div className="flex items-center justify-between">
                              <span className="text-[10px] text-gray-400 font-mono uppercase tracking-wider">Poster Image</span>
                              {posterUploading && (
                                <span className="text-[10px] text-purple-400 animate-pulse font-mono font-semibold">
                                  Uploading {posterProgress}%
                                </span>
                              )}
                            </div>
                            <div className="flex gap-2">
                              <input 
                                type="url" 
                                required
                                placeholder="Poster URL (or Upload below)"
                                value={adminDramaPoster}
                                onChange={e => setAdminDramaPoster(e.target.value)}
                                className="flex-1 bg-white/4 border border-white/8 rounded-xl px-3 py-2 text-xs text-white"
                              />
                              <label className="bg-purple-600/20 border border-purple-500/30 hover:bg-purple-600/30 text-purple-300 text-[11px] font-semibold px-3.5 py-2 rounded-xl transition cursor-pointer flex items-center gap-1.5 shrink-0 select-none">
                                <CloudUpload className="w-3.5 h-3.5" />
                                <span>Upload</span>
                                <input 
                                  type="file" 
                                  accept="image/*" 
                                  onChange={handlePosterUpload} 
                                  className="hidden" 
                                />
                              </label>
                            </div>
                            {posterUploading && (
                              <div className="w-full bg-white/5 h-1 rounded-full overflow-hidden">
                                <div className="bg-gradient-to-r from-purple-500 to-pink-500 h-full transition-all duration-300" style={{ width: `${posterProgress}%` }}></div>
                              </div>
                            )}
                          </div>

                          {/* Banner Section */}
                          <div className="bg-white/2 border border-white/5 rounded-xl p-3 space-y-2">
                            <div className="flex items-center justify-between">
                              <span className="text-[10px] text-gray-400 font-mono uppercase tracking-wider">Banner Image</span>
                              {bannerUploading && (
                                <span className="text-[10px] text-purple-400 animate-pulse font-mono font-semibold">
                                  Uploading {bannerProgress}%
                                </span>
                              )}
                            </div>
                            <div className="flex gap-2">
                              <input 
                                type="url" 
                                required
                                placeholder="Banner URL (or Upload below)"
                                value={adminDramaBanner}
                                onChange={e => setAdminDramaBanner(e.target.value)}
                                className="flex-1 bg-white/4 border border-white/8 rounded-xl px-3 py-2 text-xs text-white"
                              />
                              <label className="bg-purple-600/20 border border-purple-500/30 hover:bg-purple-600/30 text-purple-300 text-[11px] font-semibold px-3.5 py-2 rounded-xl transition cursor-pointer flex items-center gap-1.5 shrink-0 select-none">
                                <CloudUpload className="w-3.5 h-3.5" />
                                <span>Upload</span>
                                <input 
                                  type="file" 
                                  accept="image/*" 
                                  onChange={handleBannerUpload} 
                                  className="hidden" 
                                />
                              </label>
                            </div>
                            {bannerUploading && (
                              <div className="w-full bg-white/5 h-1 rounded-full overflow-hidden">
                                <div className="bg-gradient-to-r from-purple-500 to-pink-500 h-full transition-all duration-300" style={{ width: `${bannerProgress}%` }}></div>
                              </div>
                            )}
                          </div>
                        </div>
                        <div>
                          <input 
                            type="url" 
                            placeholder="Trailer Link (YT embed)"
                            value={adminDramaTrailer}
                            onChange={e => setAdminDramaTrailer(e.target.value)}
                            className="w-full bg-white/4 border border-white/8 rounded-xl px-3 py-2 text-xs text-white"
                          />
                        </div>
                        <div className="grid grid-cols-2 gap-2">
                          <input 
                            type="text" 
                            required
                            placeholder="Country (e.g., China)"
                            value={adminDramaCountry}
                            onChange={e => setAdminDramaCountry(e.target.value)}
                            className="w-full bg-white/4 border border-white/8 rounded-xl px-3 py-2 text-xs text-white"
                          />
                          <input 
                            type="number" 
                            required
                            placeholder="Release Year"
                            value={adminDramaYear}
                            onChange={e => setAdminDramaYear(Number(e.target.value))}
                            className="w-full bg-white/4 border border-white/8 rounded-xl px-3 py-2 text-xs text-white"
                          />
                        </div>
                        <div className="grid grid-cols-2 gap-2">
                          <input 
                            type="text" 
                            required
                            placeholder="Genres (Romance, Comedy)"
                            value={adminDramaGenre}
                            onChange={e => setAdminDramaGenre(e.target.value)}
                            className="w-full bg-white/4 border border-white/8 rounded-xl px-3 py-2 text-xs text-white"
                          />
                          <select 
                            value={adminDramaStatus}
                            onChange={e => setAdminDramaStatus(e.target.value)}
                            className="w-full bg-white/4 border border-white/8 rounded-xl px-3 py-2 text-xs text-white"
                          >
                            <option value="Ongoing" className="bg-[#0a0a14]">Ongoing</option>
                            <option value="Completed" className="bg-[#0a0a14]">Completed</option>
                            <option value="Upcoming" className="bg-[#0a0a14]">Upcoming</option>
                          </select>
                        </div>
                        <div>
                          <input 
                            type="text" 
                            required
                            placeholder="Cast Roster (comma-separated)"
                            value={adminDramaCast}
                            onChange={e => setAdminDramaCast(e.target.value)}
                            className="w-full bg-white/4 border border-white/8 rounded-xl px-3 py-2 text-xs text-white"
                          />
                        </div>
                        <div>
                          <input 
                            type="url" 
                            placeholder="Optional Direct Download Link"
                            value={adminDramaDownloadUrl}
                            onChange={e => setAdminDramaDownloadUrl(e.target.value)}
                            className="w-full bg-white/4 border border-white/8 rounded-xl px-3 py-2 text-xs text-white"
                          />
                        </div>
                        <div className="flex gap-2">
                          <button type="submit" className="bg-blue-600 text-white text-xs px-4 py-2 rounded-full font-bold cursor-pointer">
                            {selectedDramaToEdit !== null ? 'Update Record' : 'Save Drama'}
                          </button>
                          {selectedDramaToEdit !== null && (
                            <button 
                              type="button" 
                              onClick={() => {
                                setSelectedDramaToEdit(null);
                                setAdminDramaTitle('');
                                setAdminDramaDesc('');
                                setAdminDramaPoster('');
                                setAdminDramaBanner('');
                                setAdminDramaTrailer('');
                                setAdminDramaGenre('');
                                setAdminDramaCountry('');
                                setAdminDramaYear(2026);
                                setAdminDramaStatus('Ongoing');
                                setAdminDramaCast('');
                                setAdminDramaDownloadUrl('');
                              }}
                              className="bg-white/8 border border-white/10 text-white text-xs px-4 py-2 rounded-full"
                            >
                              Cancel
                            </button>
                          )}
                        </div>
                      </form>
                    </div>

                    {/* Add Episode Link */}
                    <div className="space-y-4">
                      {/* Live Auto Importer helper card */}
                      <div className="bg-[#0a0a14]/65 border border-blue-500/35 rounded-2xl p-5">
                        <div className="flex items-center gap-2 text-blue-400 font-bold text-xs mb-2">
                          <RotateCw className="w-4 h-4 animate-spin-slow text-blue-400" />
                          <span>Streamtape Link Auto-Importer</span>
                        </div>
                        <p className="text-gray-400 text-[10px] mb-3">
                          Paste any Streamtape video URL here. The simulation will parse the File ID, generate the clean Embed URL, capitalize words, and guess season & episode numbers on the fly!
                        </p>
                        <input
                          type="text"
                          placeholder="e.g. https://streamtape.com/v/abcd123/Hidden_Love_S01E05.mp4"
                          value={pastedStreamtapeUrl}
                          onChange={e => {
                            const val = e.target.value;
                            setPastedStreamtapeUrl(val);
                            
                            // Parse Streamtape File ID:
                            const match = val.match(/\/(v|e)\/([a-zA-Z0-9_-]+)/);
                            if (match && match[2]) {
                              const fileId = match[2];
                              const embedUrl = 'https://streamtape.com/e/' + fileId;
                              setAdminEpUrl(embedUrl);
                              
                              // Try to guess title and episode from url parts
                              const urlParts = val.split('/');
                              let filename = '';
                              const idIndex = urlParts.indexOf(fileId);
                              if (idIndex !== -1 && urlParts[idIndex + 1]) {
                                filename = decodeURIComponent(urlParts[idIndex + 1]);
                              } else {
                                filename = decodeURIComponent(urlParts[urlParts.length - 1]);
                              }
                              
                              if (filename && filename !== fileId) {
                                let cleaned = filename.replace(/\.(mp4|mkv|avi|mov|flv|wmv)$/i, '');
                                const seasonMatch = cleaned.match(/S(\d+)/i);
                                const epMatch = cleaned.match(/(?:ep|episode|e)[._ -]*(\d+)/i);
                                
                                if (seasonMatch && seasonMatch[1]) {
                                  setAdminEpSeason(parseInt(seasonMatch[1], 10));
                                }
                                if (epMatch && epMatch[1]) {
                                  setAdminEpNumber(parseInt(epMatch[1], 10));
                                }
                                
                                cleaned = cleaned
                                  .replace(/[._-]/g, ' ')
                                  .replace(/\s+/g, ' ')
                                  .trim();
                                  
                                setAdminEpTitle(cleaned);
                              }
                            }
                          }}
                          className="w-full bg-white/4 border border-blue-500/20 rounded-xl px-3 py-2 text-xs text-white placeholder-gray-600 focus:border-blue-500 focus:outline-none"
                        />
                        {pastedStreamtapeUrl && adminEpUrl && (
                          <div className="mt-2 p-2 rounded bg-blue-500/5 border border-blue-500/10 text-[10px] space-y-0.5 animate-fade-in">
                            <div className="text-green-400 font-bold flex items-center gap-1">
                              <CheckCircle2 className="w-3.5 h-3.5" /> Link Decoded!
                            </div>
                            <div className="text-gray-300 font-mono truncate">Embed: {adminEpUrl}</div>
                            {adminEpTitle && <div className="text-gray-400 truncate">Extracted Title: <span className="text-white font-bold">{adminEpTitle}</span></div>}
                          </div>
                        )}
                      </div>

                      <div className="bg-[#0a0a14]/65 border border-white/8 rounded-2xl p-6">
                        <h3 className="font-bold text-white text-sm mb-4">
                          {adminEpEditId !== null ? 'Edit Episode Link / Replace' : 'Compile Episode Stream'}
                        </h3>
                        <form onSubmit={handleSaveEpisodeAdmin} className="space-y-3">
                          <div>
                            <label className="block text-[10px] text-gray-500 mb-0.5">Select Drama</label>
                            <select 
                              value={adminEpDramaId}
                              onChange={e => setAdminEpDramaId(Number(e.target.value))}
                              className="w-full bg-white/4 border border-white/8 rounded-xl px-3 py-2 text-xs text-white"
                            >
                              {dramas.map(d => (
                                <option key={d.id} value={d.id} className="bg-[#0a0a14]">{d.title}</option>
                              ))}
                            </select>
                          </div>
                          
                          <div className="grid grid-cols-3 gap-2">
                            <div>
                              <label className="block text-[10px] text-gray-500 mb-0.5">Season</label>
                              <input 
                                type="number"
                                required
                                min="1"
                                value={adminEpSeason}
                                onChange={e => setAdminEpSeason(Number(e.target.value))}
                                className="w-full bg-white/4 border border-white/8 rounded-xl px-3 py-2 text-xs text-white"
                              />
                            </div>
                            <div>
                              <label className="block text-[10px] text-gray-500 mb-0.5">Ep No.</label>
                              <input 
                                type="number"
                                required
                                min="1"
                                value={adminEpNumber}
                                onChange={e => setAdminEpNumber(Number(e.target.value))}
                                className="w-full bg-white/4 border border-white/8 rounded-xl px-3 py-2 text-xs text-white"
                              />
                            </div>
                            <div className="col-span-1 flex items-end justify-center">
                              <span className="text-gray-500 text-[10px] font-bold pb-2 bg-white/5 border border-white/10 rounded-xl px-2 h-full flex items-center justify-center w-full">
                                S{adminEpSeason} Ep{adminEpNumber}
                              </span>
                            </div>
                          </div>

                          <div>
                            <label className="block text-[10px] text-gray-500 mb-0.5">Episode Title</label>
                            <input 
                              type="text"
                              required
                              placeholder="Fateful Meetings"
                              value={adminEpTitle}
                              onChange={e => setAdminEpTitle(e.target.value)}
                              className="w-full bg-white/4 border border-white/8 rounded-xl px-3 py-2 text-xs text-white"
                            />
                          </div>

                          <div>
                            <label className="block text-[10px] text-gray-500 mb-0.5">Streamtape Embed Link</label>
                            <input 
                              type="url"
                              required
                              placeholder="https://streamtape.com/e/..."
                              value={adminEpUrl}
                              onChange={e => setAdminEpUrl(e.target.value)}
                              className="w-full bg-white/4 border border-white/8 rounded-xl px-3 py-2 text-xs text-white"
                            />
                          </div>

                          <div>
                            <label className="block text-[10px] text-gray-500 mb-0.5">Optional Download URL</label>
                            <input 
                              type="url"
                              placeholder="Optional Direct Download Link"
                              value={adminEpDownloadUrl}
                              onChange={e => setAdminEpDownloadUrl(e.target.value)}
                              className="w-full bg-white/4 border border-white/8 rounded-xl px-3 py-2 text-xs text-white"
                            />
                          </div>

                          <div className="flex gap-2">
                            <button type="submit" className="bg-purple-600 hover:bg-purple-700 text-white text-xs px-4 py-2 rounded-full font-bold cursor-pointer">
                              {adminEpEditId !== null ? 'Update Episode' : 'Link Episode Stream'}
                            </button>
                            {adminEpEditId !== null && (
                              <button 
                                type="button" 
                                onClick={() => {
                                  setAdminEpEditId(null);
                                  setAdminEpTitle('');
                                  setAdminEpUrl('');
                                  setAdminEpDownloadUrl('');
                                  setPastedStreamtapeUrl('');
                                }}
                                className="bg-white/8 border border-white/10 text-white text-xs px-4 py-2 rounded-full"
                              >
                                Cancel Edit
                              </button>
                            )}
                          </div>
                        </form>
                      </div>
                    </div>
                  </div>

                  {/* Column Center & Right: Catalog List & Registered Users */}
                  <div className="lg:col-span-2 space-y-6">
                    {/* Active Episode Streamnodes */}
                    <div className="bg-[#0a0a14]/65 border border-purple-500/20 rounded-2xl p-6">
                      <h3 className="font-bold text-white text-sm mb-4 flex items-center gap-2">
                        <Play className="w-4 h-4 text-purple-400" />
                        <span>Active Episode Streamnodes ({episodes.length})</span>
                      </h3>
                      <div className="overflow-x-auto max-h-[380px] overflow-y-auto">
                        <table className="w-full text-left text-xs border-collapse">
                          <thead>
                            <tr className="border-b border-white/10 text-gray-400">
                              <th className="py-2">Drama Title</th>
                              <th className="py-2 text-center">Season/Ep</th>
                              <th className="py-2">Episode Title</th>
                              <th className="py-2 text-center">Actions</th>
                            </tr>
                          </thead>
                          <tbody className="divide-y divide-white/5">
                            {episodes.map(ep => {
                              const dr = dramas.find(d => d.id === ep.drama_id);
                              return (
                                <tr key={ep.id} className="hover:bg-white/2">
                                  <td className="py-2.5 font-bold text-gray-300 max-w-[150px] truncate">{dr ? dr.title : 'Unknown Drama'}</td>
                                  <td className="py-2.5 text-center text-purple-400 font-mono">S{ep.season_number || 1} Ep{ep.episode_number}</td>
                                  <td className="py-2.5 text-gray-400 max-w-[120px] truncate">{ep.title}</td>
                                  <td className="py-2.5 text-center flex items-center justify-center gap-2">
                                    <button 
                                      onClick={() => handleEditEpisodeClick(ep)} 
                                      className="text-blue-400 hover:text-blue-350 transition"
                                      title="Edit Streamnode / Replace URL"
                                    >
                                      <Edit className="w-4 h-4" />
                                    </button>
                                    <button 
                                      onClick={() => handleDeleteEpisodeClick(ep.id)} 
                                      className="text-red-500 hover:text-red-400 transition"
                                      title="Delete Streamnode"
                                    >
                                      <Trash2 className="w-4 h-4" />
                                    </button>
                                  </td>
                                </tr>
                              );
                            })}
                          </tbody>
                        </table>
                      </div>
                    </div>

                    {/* Catalog Listing */}
                    <div className="bg-[#0a0a14]/65 border border-white/8 rounded-2xl p-6">
                      <h3 className="font-bold text-white text-sm mb-4">Active Drama Listings</h3>
                      <div className="overflow-x-auto">
                        <table className="w-full text-left text-xs border-collapse">
                          <thead>
                            <tr className="border-b border-white/10 text-gray-400">
                              <th className="py-2">Drama</th>
                              <th className="py-2">Country/Year</th>
                              <th className="py-2 text-center">Actions</th>
                            </tr>
                          </thead>
                          <tbody className="divide-y divide-white/5">
                            {dramas.map(d => (
                              <tr key={d.id} className="hover:bg-white/2">
                                <td className="py-2.5 font-bold">{d.title}</td>
                                <td className="py-2.5">{d.country} ({d.release_year})</td>
                                <td className="py-2.5 text-center flex items-center justify-center gap-1.5">
                                  <button onClick={() => handleEditDramaAdminClick(d)} className="text-info hover:underline">
                                    <Edit className="w-4 h-4" />
                                  </button>
                                  <button onClick={() => handleDeleteDramaAdmin(d.id)} className="text-red-500 hover:underline">
                                    <Trash2 className="w-4 h-4" />
                                  </button>
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    </div>

                    {/* Users Management */}
                    <div className="bg-[#0a0a14]/65 border border-white/8 rounded-2xl p-6">
                      <h3 className="font-bold text-white text-sm mb-4">Registered Users Account Panel</h3>
                      <div className="overflow-x-auto">
                        <table className="w-full text-left text-xs border-collapse">
                          <thead>
                            <tr className="border-b border-white/10 text-gray-400">
                              <th className="py-2">User details</th>
                              <th className="py-2">Status</th>
                              <th className="py-2 text-center">Control flags</th>
                            </tr>
                          </thead>
                          <tbody className="divide-y divide-white/5">
                            {registeredUsers.map(u => (
                              <tr key={u.id} className="hover:bg-white/2">
                                <td className="py-2.5">
                                  <div className="font-semibold text-white">{u.fullname}</div>
                                  <div className="text-gray-400 text-[10px]">@{u.username} • {u.email}</div>
                                </td>
                                <td className="py-2.5">
                                  <span className={`text-[10px] px-2 py-0.5 rounded-full font-bold ${u.status === 'active' ? 'bg-green-500/10 text-green-400 border border-green-500/20' : u.status === 'suspended' ? 'bg-warning/10 text-yellow-400 border border-warning/20' : 'bg-red-500/10 text-red-500 border border-red-500/20'}`}>
                                    {u.status}
                                  </span>
                                </td>
                                <td className="py-2.5 text-center flex items-center justify-center gap-1.5">
                                  <button 
                                    onClick={() => handleAdminToggleUserStatus(u.id, u.status)}
                                    className="bg-white/4 border border-white/10 hover:bg-white/8 text-[10px] px-2 py-1 rounded"
                                    title="Toggle active/suspend/ban flags"
                                  >
                                    Cycle status
                                  </button>
                                  {u.username !== 'Rahul' && (
                                    <button 
                                      onClick={() => handleAdminDeleteUser(u.id)}
                                      className="text-red-400 hover:text-red-500 text-[10px]"
                                    >
                                      Delete
                                    </button>
                                  )}
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Database Maintenance & Data Integrity */}
                <div className="bg-[#0a0a14]/65 border border-red-500/10 rounded-2xl p-6 backdrop-blur-md space-y-4 relative overflow-hidden mt-6">
                  <div className="absolute top-0 right-0 w-32 h-32 bg-red-500/5 rounded-full blur-3xl pointer-events-none" />
                  
                  <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
                    <div className="space-y-1">
                      <h3 className="text-sm font-bold text-white flex items-center gap-2">
                        <ShieldAlert className="w-4 h-4 text-red-400" />
                        <span>Database Maintenance & Rating Cleanups</span>
                      </h3>
                      <p className="text-[11px] text-gray-400">
                        Scan Cloud Firestore for fake, legacy, out-of-range, or malformed rating records and purge them instantly.
                      </p>
                    </div>

                    <button
                      type="button"
                      disabled={isPurgingRatings}
                      onClick={purgeLegacyRatings}
                      className="bg-red-600 hover:bg-red-500 text-white font-bold text-xs px-4 py-2 rounded-xl transition duration-300 shadow-lg shadow-red-600/10 active:scale-95 cursor-pointer shrink-0 flex items-center gap-1.5"
                    >
                      {isPurgingRatings ? (
                        <>
                          <Loader2 className="w-3.5 h-3.5 animate-spin" />
                          <span>Purging Cloud Records...</span>
                        </>
                      ) : (
                        <>
                          <Trash2 className="w-3.5 h-3.5" />
                          <span>Run Cleanup Maintenance</span>
                        </>
                      )}
                    </button>
                  </div>

                  {/* Clean stats row inside maintenance panel */}
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 bg-[#05050a]/40 border border-white/5 p-3 rounded-xl text-xs">
                    <div>
                      <span className="text-[10px] text-gray-500 block">Firestore Ratings Catalog</span>
                      <span className="font-mono font-bold text-white">{ratings.length} documents</span>
                    </div>
                    <div>
                      <span className="text-[10px] text-gray-500 block">Invalid / Out-of-Range</span>
                      <span className="font-mono font-bold text-red-400">
                        {ratings.filter(r => r.rating < 1.0 || r.rating > 10.0).length} records
                      </span>
                    </div>
                    <div>
                      <span className="text-[10px] text-gray-500 block">Orphaned Ratings</span>
                      <span className="font-mono font-bold text-yellow-500">
                        {ratings.filter(r => !dramas.some(d => d.id === r.dramaId)).length} records
                      </span>
                    </div>
                    <div>
                      <span className="text-[10px] text-gray-500 block">Clean & Synced Records</span>
                      <span className="font-mono font-bold text-emerald-400">
                        {ratings.filter(r => r.rating >= 1.0 && r.rating <= 10.0 && dramas.some(d => d.id === r.dramaId)).length} documents
                      </span>
                    </div>
                  </div>
                </div>
              </>
            ) : adminSubTab === 'streamtape' ? (
                  <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 animate-fade-in">
                    {/* Left Panel: Configuration & New Upload Form */}
                    <div className="lg:col-span-5 space-y-6">
                      
                      {/* Configuration Settings */}
                      <div className="bg-[#0a0a14]/65 border border-white/8 rounded-2xl p-6 relative overflow-hidden">
                        <div className="absolute top-0 right-0 w-24 h-24 bg-purple-500/10 rounded-full blur-2xl" />
                        <div className="flex items-center gap-2 mb-4">
                          <Settings className="w-4 h-4 text-purple-400" />
                          <h3 className="font-bold text-white text-sm">Streamtape API Credentials</h3>
                        </div>
                        
                        <div className="space-y-4">
                          <div>
                            <label className="block text-[10px] text-gray-400 mb-1">API Login ID (e.g. user10214)</label>
                            <input
                              type="text"
                              value={streamtapeLogin}
                              onChange={e => setStreamtapeLogin(e.target.value)}
                              placeholder="e.g. 522fc2d3f966141a5477"
                              className="w-full bg-white/4 border border-white/8 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-purple-600"
                            />
                          </div>
                          <div>
                            <label className="block text-[10px] text-gray-400 mb-1">API Key (Secure Access Token)</label>
                            <input
                              type="password"
                              value={streamtapeKey}
                              onChange={e => setStreamtapeKey(e.target.value)}
                              placeholder="••••••••••••••••••••••••••••"
                              className="w-full bg-white/4 border border-white/8 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-purple-600"
                            />
                          </div>
                          
                          <div className="pt-1 flex items-center justify-between gap-2">
                            <span className="text-[10px] text-green-400 flex items-center gap-1 font-semibold">
                              <CheckCircle2 className="w-3.5 h-3.5" />
                              <span>Configured Locally</span>
                            </span>
                            <button
                              type="button"
                              onClick={() => {
                                showToast('Streamtape credentials synced & saved into the VibeSettings database successfully!', 'success');
                              }}
                              className="bg-purple-600 hover:bg-purple-700 text-white text-[10px] font-bold px-3 py-1.5 rounded-full transition cursor-pointer"
                            >
                              Sync with MySQL
                            </button>
                          </div>
                        </div>
                      </div>

                      {/* Add New Remote Upload Form */}
                      <div className="bg-[#0a0a14]/65 border border-white/8 rounded-2xl p-6">
                        <div className="flex items-center gap-2 mb-4">
                          <CloudUpload className="w-4 h-4 text-purple-400" />
                          <h3 className="font-bold text-white text-sm">Initiate Remote Download</h3>
                        </div>

                        <form onSubmit={handleStartRemoteUpload} className="space-y-4">
                          <div>
                            <label className="block text-[10px] text-gray-400 mb-1">Video Source Direct URL</label>
                            <input
                              type="url"
                              required
                              value={uploadUrl}
                              onChange={e => {
                                setUploadUrl(e.target.value);
                                // Smart autofill filename from URL
                                if (e.target.value && !uploadCustomName) {
                                  const parts = e.target.value.split('/');
                                  const lastPart = parts[parts.length - 1];
                                  if (lastPart && lastPart.includes('.')) {
                                    setUploadCustomName(lastPart);
                                  }
                                }
                              }}
                              placeholder="e.g., https://source-server.com/media/drama_raw_ep1.mp4"
                              className="w-full bg-white/4 border border-white/8 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-purple-600"
                            />
                            <p className="text-[9px] text-gray-500 mt-1">Provide a direct high-speed mp4, mkv, or webm source link.</p>
                          </div>

                          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                            <div>
                              <label className="block text-[10px] text-gray-400 mb-1">Target Drama</label>
                              <select
                                value={uploadDramaId}
                                onChange={e => setUploadDramaId(parseInt(e.target.value))}
                                className="w-full bg-[#0d0d1e] border border-white/8 rounded-xl px-3 py-2 text-xs text-white"
                              >
                                {dramas.map(d => (
                                  <option key={d.id} value={d.id}>{d.title}</option>
                                ))}
                              </select>
                            </div>

                            <div>
                              <label className="block text-[10px] text-gray-400 mb-1">Folder Destination</label>
                              <select
                                value={uploadFolderId}
                                onChange={e => setUploadFolderId(e.target.value)}
                                className="w-full bg-[#0d0d1e] border border-white/8 rounded-xl px-3 py-2 text-xs text-white"
                              >
                                <option value="">Root Folder (Default)</option>
                                <option value="f_ongoing">Ongoing Series (/ongoing)</option>
                                <option value="f_completed">Completed Series (/completed)</option>
                                <option value="f_raw">Raw Uploads (/raw)</option>
                              </select>
                            </div>
                          </div>

                          <div className="grid grid-cols-2 gap-3">
                            <div>
                              <label className="block text-[10px] text-gray-400 mb-1">Season Number</label>
                              <input
                                type="number"
                                required
                                min={1}
                                value={uploadSeason}
                                onChange={e => setUploadSeason(parseInt(e.target.value))}
                                className="w-full bg-white/4 border border-white/8 rounded-xl px-3 py-2 text-xs text-white"
                              />
                            </div>
                            <div>
                              <label className="block text-[10px] text-gray-400 mb-1">Episode Number</label>
                              <input
                                type="number"
                                required
                                min={1}
                                value={uploadEpisode}
                                onChange={e => setUploadEpisode(parseInt(e.target.value))}
                                className="w-full bg-white/4 border border-white/8 rounded-xl px-3 py-2 text-xs text-white"
                              />
                            </div>
                          </div>

                          <div>
                            <label className="block text-[10px] text-gray-400 mb-1">Custom Filename on Streamtape</label>
                            <input
                              type="text"
                              required
                              value={uploadCustomName}
                              onChange={e => setUploadCustomName(e.target.value)}
                              placeholder="e.g. DramaTitle_S01E01.mp4"
                              className="w-full bg-white/4 border border-white/8 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-purple-600"
                            />
                          </div>

                          <button
                            type="submit"
                            className="w-full bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-500 hover:to-blue-500 text-white py-2.5 rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5 cursor-pointer"
                          >
                            <CloudUpload className="w-4 h-4" />
                            <span>Start Remote Upload</span>
                          </button>
                        </form>
                      </div>

                    </div>

                    {/* Right Panel: Upload Queue Monitor */}
                    <div className="lg:col-span-7">
                      <div className="bg-[#0a0a14]/65 border border-white/8 rounded-2xl p-6 h-full flex flex-col">
                        
                        {/* Queue Header */}
                        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2 border-b border-white/5 pb-4 mb-4">
                          <div>
                            <h3 className="font-bold text-white text-sm flex items-center gap-2">
                              <span>Active Remote Upload Pipeline</span>
                              <span className="bg-purple-600/20 text-purple-400 text-[10px] px-2 py-0.5 rounded-full font-bold">
                                {uploadQueue.length} jobs
                              </span>
                            </h3>
                            <p className="text-gray-500 text-[10px] mt-0.5">Auto-updates from Streamtape server nodes every 5 seconds.</p>
                          </div>

                          <div className="flex items-center gap-2 self-stretch sm:self-auto justify-between">
                            {uploadQueue.some(j => j.status === 'pending' || j.status === 'processing') && (
                              <span className="text-[10px] text-blue-400 flex items-center gap-1 font-semibold animate-pulse">
                                <RotateCw className="w-3 h-3 animate-spin" />
                                <span>Syncing with Streamtape...</span>
                              </span>
                            )}
                            <button
                              type="button"
                              onClick={() => {
                                setUploadQueue(prev => [...prev]);
                                showToast('Streamtape Queue checked and synchronized with MySQL databases!', 'success');
                              }}
                              className="bg-white/4 border border-white/8 hover:bg-white/8 text-[10px] px-2.5 py-1.5 rounded-lg flex items-center gap-1 transition cursor-pointer text-white"
                            >
                              <RotateCw className="w-3 h-3" />
                              <span>Force Refresh</span>
                            </button>
                          </div>
                        </div>

                        {/* Queue Listing */}
                        {uploadQueue.length === 0 ? (
                          <div className="flex-1 flex flex-col items-center justify-center text-center p-8 border border-dashed border-white/5 rounded-xl bg-white/1">
                            <CloudUpload className="w-10 h-10 text-gray-600 mb-3" />
                            <h4 className="text-xs font-bold text-gray-400">Queue is completely empty</h4>
                            <p className="text-[10px] text-gray-500 max-w-xs mt-1">Enter a direct media link on the left to queue and automatically catalog raw streams.</p>
                          </div>
                        ) : (
                          <div className="space-y-4 overflow-y-auto max-h-[500px] pr-1">
                            {uploadQueue.map((job) => {
                              return (
                                <div key={job.id} className="bg-white/2 border border-white/5 rounded-xl p-4 space-y-3 relative overflow-hidden hover:border-white/10 transition text-left">
                                  
                                  {/* Title & Metadata row */}
                                  <div className="flex justify-between items-start gap-3">
                                    <div className="min-w-0">
                                      <div className="font-bold text-xs text-white truncate max-w-[280px] sm:max-w-md">
                                        {job.custom_name}
                                      </div>
                                      <div className="text-[10px] text-gray-400 flex flex-wrap items-center gap-x-2 gap-y-0.5 mt-0.5">
                                        <span className="text-purple-400 font-semibold">{job.drama_title}</span>
                                        <span>•</span>
                                        <span>S{job.season_number} E{job.episode_number}</span>
                                        {job.folder_id && (
                                          <>
                                            <span>•</span>
                                            <span className="text-blue-400 font-semibold flex items-center gap-0.5">
                                              <FolderOpen className="w-2.5 h-2.5" />
                                              {job.folder_id}
                                            </span>
                                          </>
                                        )}
                                      </div>
                                    </div>

                                    {/* Status Badge */}
                                    <div>
                                      {job.status === 'completed' && (
                                        <span className="bg-green-500/10 text-green-400 border border-green-500/20 text-[9px] px-2 py-0.5 rounded-full font-bold uppercase">
                                          Completed
                                        </span>
                                      )}
                                      {job.status === 'processing' && (
                                        <span className="bg-blue-500/10 text-blue-400 border border-blue-500/20 text-[9px] px-2 py-0.5 rounded-full font-bold uppercase flex items-center gap-1">
                                          <span className="w-1 h-1 rounded-full bg-blue-400 animate-ping" />
                                          <span>{job.progress}% Uploading</span>
                                        </span>
                                      )}
                                      {job.status === 'pending' && (
                                        <span className="bg-yellow-500/10 text-yellow-500 border border-yellow-500/20 text-[9px] px-2 py-0.5 rounded-full font-bold uppercase">
                                          Pending
                                        </span>
                                      )}
                                      {job.status === 'failed' && (
                                        <span className="bg-red-500/10 text-red-500 border border-red-500/20 text-[9px] px-2 py-0.5 rounded-full font-bold uppercase">
                                          Failed
                                        </span>
                                      )}
                                    </div>
                                  </div>

                                  {/* Progress bar */}
                                  <div className="space-y-1">
                                    <div className="w-full bg-white/4 rounded-full h-1.5 overflow-hidden">
                                      <div 
                                        className={`h-full transition-all duration-500 ${job.status === 'completed' ? 'bg-green-500' : job.status === 'failed' ? 'bg-red-500' : 'bg-purple-600'}`}
                                        style={{ width: `${job.progress}%` }}
                                      />
                                    </div>
                                    <div className="flex justify-between items-center text-[9px] text-gray-500">
                                      <span className="truncate max-w-[200px] sm:max-w-xs font-mono">{job.source_url}</span>
                                      <span>{job.progress}%</span>
                                    </div>
                                  </div>

                                  {/* Completed details links (Save to MySQL & Auto Attached values) */}
                                  {job.status === 'completed' && (
                                    <div className="bg-[#0b1b11]/30 border border-green-500/10 rounded-lg p-2.5 text-[10px] space-y-1">
                                      <div className="text-green-400 font-bold flex items-center gap-1">
                                        <CheckCircle2 className="w-3.5 h-3.5" />
                                        <span>Automatically Attached to MySQL Catalog &amp; Active!</span>
                                      </div>
                                      <div className="font-mono text-gray-400 flex flex-col gap-0.5 pl-4">
                                        <div>File ID: <span className="text-gray-200 select-all">{job.file_id}</span></div>
                                        <div className="truncate">Embed: <a href={job.embed_url} target="_blank" rel="noopener noreferrer" className="text-blue-400 hover:underline select-all">{job.embed_url}</a></div>
                                      </div>
                                    </div>
                                  )}

                                  {/* Failed explanation */}
                                  {job.status === 'failed' && job.error_message && (
                                    <div className="bg-red-500/5 border border-red-500/10 text-red-400 rounded-lg p-2 text-[10px] italic">
                                      Error: {job.error_message}
                                    </div>
                                  )}

                                  {/* Actions strip */}
                                  <div className="flex justify-end gap-1.5 pt-1 border-t border-white/5">
                                    {(job.status === 'completed' || job.status === 'failed') && (
                                      <button 
                                        type="button"
                                        onClick={() => handleRetryUpload(job.id)}
                                        className="bg-white/4 hover:bg-purple-600 text-white text-[10px] px-2.5 py-1 rounded transition flex items-center gap-1 cursor-pointer"
                                      >
                                        <RotateCw className="w-3 h-3" />
                                        <span>Retry Upload</span>
                                      </button>
                                    )}
                                    {(job.status === 'pending' || job.status === 'processing') && (
                                      <button 
                                        type="button"
                                        onClick={() => handleCancelUpload(job.id)}
                                        className="bg-red-500/10 text-red-400 hover:bg-red-500/20 text-[10px] px-2.5 py-1 rounded transition cursor-pointer"
                                      >
                                        Cancel Upload
                                      </button>
                                    )}
                                    <button 
                                      type="button"
                                      onClick={() => handleDeleteUpload(job.id)}
                                      className="bg-white/4 text-gray-400 hover:text-red-500 text-[10px] px-2.5 py-1 rounded transition cursor-pointer"
                                    >
                                      Delete Log
                                    </button>
                                  </div>
                                </div>
                              );
                            })}
                          </div>
                        )}

                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="bg-[#0a0a14]/65 border border-white/8 rounded-2xl p-6 md:p-8 animate-fade-in space-y-6">
                    <div>
                      <h3 className="text-base font-bold text-white flex items-center gap-2">
                        <FolderOpen className="w-5 h-5 text-pink-400" />
                        <span>Firebase Cloud Storage Management</span>
                      </h3>
                      <p className="text-xs text-gray-400 mt-1">Upload and manage poster, banner, and trailer assets securely in Google Cloud Storage. Use the shortcuts to automatically apply URLs to your active drama catalogs.</p>
                    </div>
                    
                    <Suspense fallback={
                      <div className="flex flex-col items-center justify-center py-12 space-y-3">
                        <RotateCw className="w-8 h-8 text-purple-500 animate-spin" />
                        <span className="text-xs text-gray-400 font-medium">Initializing Cloud Storage Console...</span>
                      </div>
                    }>
                      <FirebaseStorageManager 
                        onSelectPoster={(url) => {
                          setAdminDramaPoster(url);
                          setAdminSubTab('catalog');
                          showToast('Poster image URL selected and attached!', 'success');
                        }}
                        onSelectBanner={(url) => {
                          setAdminDramaBanner(url);
                          setAdminSubTab('catalog');
                          showToast('Banner image URL selected and attached!', 'success');
                        }}
                        showToast={showToast}
                      />
                    </Suspense>
                  </div>
                )}
              </div>
            )}

            {/* TAB: LEGAL PAGE */}
            {activeTab === 'legal' && (
              <div className="container mx-auto px-6 md:px-12 py-12 animate-fade-in max-w-4xl">
                <div className="bg-[#0a0a14]/65 border border-white/8 rounded-2xl p-8 md:p-10 space-y-6">
                  <h1 className="text-3xl font-bold flex items-center gap-2">
                    <Scale className="text-purple-400" />
                    <span>Terms &amp; Legal Policies</span>
                  </h1>
                  <p className="text-gray-400 text-xs">Last updated: July 2026</p>
                  
                  <div className="space-y-4 text-sm text-gray-300 leading-relaxed">
                    <h3 className="text-white font-bold text-base">Terms of Service</h3>
                    <p>Welcome to VIBEDRAMAHUB. By accessing this platform, register an account, or streaming catalog items, you signify your unreserved compliance with these terms of service.</p>
                    
                    <h3 className="text-white font-bold text-base">Privacy Disclosures</h3>
                    <p>We log standard registration parameters: Full Name, Username, and hashed Password files. We do not transmit coordinates or user details to third-party brokers. All password files are encrypted with secure hashes to preserve safety.</p>

                    <h3 className="text-white font-bold text-base">Cookie Declarations</h3>
                    <p>We utilize browser cookies to remember active user sessions. Selecting 'Remember Me' configures cookie indicators that preserve your login for up to 30 days securely.</p>
                  </div>
                </div>
              </div>
            )}

            {/* TAB: COPYRIGHT / DMCA */}
            {activeTab === 'copyright' && (
              <div className="container mx-auto px-6 md:px-12 py-12 animate-fade-in max-w-4xl">
                <div className="bg-[#0a0a14]/65 border border-white/8 rounded-2xl p-8 md:p-10 space-y-6">
                  <h1 className="text-3xl font-bold flex items-center gap-2">
                    <Copyright className="text-blue-400" />
                    <span>Copyright Notices &amp; DMCA Policy</span>
                  </h1>
                  
                  <div className="space-y-4 text-sm text-gray-300 leading-relaxed">
                    <p><strong>VIBEDRAMAHUB</strong> acts as an index of metadata, stream indicators, and external stream locations. We do not host, compile, upload, or transmit any video streams, media files, or copyright-restricted content directly on our servers. All referenced streams are hosted by independent, third-party hosting companies such as Streamtape.</p>
                    <p>Under Section 107 of the Copyright Act 1976, allowance is made for "fair use" for purposes such as criticism, comment, news reporting, teaching, scholarship, and research. Fair use is a use permitted by copyright statute that might otherwise be infringing.</p>
                    
                    <div className="bg-white/4 p-4 rounded-xl border border-white/5 space-y-2 mt-4">
                      <h4 className="font-bold text-white text-xs uppercase tracking-wider text-blue-400">Report Infringing Items</h4>
                      <p className="text-xs text-gray-400">If you represent a copyright owner and want us to remove indexed links pointing to your material, write us at: <strong className="text-white">contact.cdramamagic@gmail.com</strong> with valid DMCA parameters.</p>
                      <div className="pt-1">
                        <a href="mailto:contact.cdramamagic@gmail.com" className="inline-flex items-center gap-1.5 bg-blue-600 hover:bg-blue-700 transition text-white text-[11px] font-semibold px-3 py-1.5 rounded-lg">
                          <Mail className="w-3.5 h-3.5" />
                          <span>Contact Support / Submit DMCA</span>
                        </a>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* TAB: BRAND PAGE */}
            {activeTab === 'brand' && (
              <div className="container mx-auto px-6 md:px-12 py-12 animate-fade-in max-w-4xl">
                <div className="bg-[#0a0a14]/65 border border-white/8 rounded-2xl p-8 md:p-10 space-y-6">
                  <h1 className="text-3xl font-bold flex items-center gap-2">
                    <Globe className="text-yellow-500" />
                    <span>Brand Profile &amp; Mission</span>
                  </h1>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center pt-4">
                    <div className="space-y-4 text-sm text-gray-300">
                      <h3 className="text-white font-bold text-base">About VIBEDRAMAHUB</h3>
                      <p>VIBEDRAMAHUB was established with a singular mission: to bring together premium design aesthetics, lightning-fast media buffering, and robust user-oriented playlists into one seamless Asian drama streaming index.</p>
                      <p>Our goal is to compile highly responsive layout arrays that look great on any desktop screen, tablet, or mobile phone, delivering premium dark UI experiences.</p>
                    </div>

                    <div className="bg-gradient-to-r from-purple-600/10 to-blue-600/10 border border-white/5 rounded-2xl p-6 space-y-4">
                      <h4 className="font-bold text-white text-xs uppercase tracking-wider">Contact Corporate Desk</h4>
                      <div className="text-xs space-y-2 text-gray-400">
                        <div>📧 Business Mail: <strong className="text-white">contact.cdramamagic@gmail.com</strong></div>
                        <div>📱 Supported Systems: <strong className="text-white">iOS, Android, Chrome, Smart TV</strong></div>
                        <div>🔧 Engine Stack: <strong className="text-white">React 18, Tailwind CSS, Cloud Firestore, Firebase Auth</strong></div>
                      </div>
                      <div className="pt-1">
                        <a 
                          href="mailto:contact.cdramamagic@gmail.com"
                          className="inline-flex items-center gap-2 bg-gradient-to-r from-purple-600 to-blue-600 hover:opacity-90 transition text-white text-xs font-bold px-4 py-2 rounded-full cursor-pointer"
                        >
                          <Mail className="w-4 h-4" />
                          <span>Contact Us</span>
                        </a>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* TAB: CONTACT PAGE */}
            {activeTab === 'contact' && (
              <div className="container mx-auto px-6 md:px-12 py-12 animate-fade-in max-w-4xl">
                <div className="bg-[#0a0a14]/65 border border-white/8 rounded-2xl p-8 md:p-10 space-y-8">
                  <div className="border-b border-white/10 pb-4">
                    <h1 className="text-3xl font-bold flex items-center gap-2">
                      <Mail className="text-blue-400" />
                      <span>Business Contact Desk</span>
                    </h1>
                    <p className="text-gray-400 text-xs mt-1">Get in touch for corporate inquiries, feedback, or administrative requests.</p>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                    {/* Information panel */}
                    <div className="space-y-6">
                      <div className="space-y-3">
                        <h3 className="text-white font-bold text-base">Direct Channels</h3>
                        <p className="text-sm text-gray-300">We prefer direct, encrypted digital inquiries. For fast resolution, write to our primary inbox:</p>
                      </div>

                      <div className="bg-white/4 border border-white/5 p-5 rounded-2xl space-y-4">
                        <div>
                          <div className="text-pink-500 font-bold uppercase tracking-wider text-[10px] mb-1">Direct Channels</div>
                          <div className="text-white font-bold text-sm select-all">contact.cdramamagic@gmail.com</div>
                        </div>
                        <div>
                          <div className="text-[10px] uppercase text-gray-500 tracking-wider">Response Frequency</div>
                          <div className="text-gray-300 font-medium text-xs">Within 12 to 24 Business Hours</div>
                        </div>
                        <div>
                          <div className="text-[10px] uppercase text-gray-500 tracking-wider">Legal & Compliance</div>
                          <div className="text-gray-300 font-medium text-xs">General DMCA/Copyright Queue</div>
                        </div>
                        <div className="pt-2">
                          <a 
                            href="mailto:contact.cdramamagic@gmail.com"
                            className="inline-flex items-center justify-center gap-2 bg-gradient-to-r from-purple-600 to-blue-600 hover:opacity-90 transition text-white text-xs font-bold px-5 py-2.5 rounded-full w-full"
                          >
                            <Mail className="w-4 h-4" />
                            <span>Contact Us (Open Mail App)</span>
                          </a>
                        </div>
                      </div>
                    </div>

                    {/* Contact Form Simulator */}
                    <div className="bg-white/2 border border-white/5 p-6 rounded-2xl space-y-4">
                      <h3 className="text-white font-bold text-base">Send a Secure Inquiry</h3>
                      {contactSubmitted ? (
                        <div className="bg-green-500/10 border border-green-500/20 p-5 rounded-xl text-center space-y-3 animate-fade-in">
                          <CheckCircle2 className="w-10 h-10 text-green-400 mx-auto" />
                          <h4 className="text-white font-bold text-sm">Message Compiled Successfully</h4>
                          <p className="text-xs text-gray-400">
                            Your inquiry has been cataloged. To ensure direct delivery, you can also transmit it via your default mail app:
                          </p>
                          <a 
                            href={`mailto:contact.cdramamagic@gmail.com?subject=${encodeURIComponent(contactSubject)}&body=${encodeURIComponent(`From: ${contactName} (${contactEmail})\n\n${contactMessage}`)}`}
                            className="inline-flex items-center gap-2 bg-green-600 hover:bg-green-700 transition text-white text-xs font-bold px-4 py-2 rounded-xl"
                          >
                            <Mail className="w-3.5 h-3.5" />
                            <span>Send via Email Client</span>
                          </a>
                          <button 
                            onClick={() => {
                              setContactSubmitted(false);
                              setContactName('');
                              setContactEmail('');
                              setContactSubject('');
                              setContactMessage('');
                            }}
                            className="block text-purple-400 hover:underline text-[10px] mx-auto pt-2"
                          >
                            Draft another message
                          </button>
                        </div>
                      ) : (
                        <form 
                          onSubmit={(e) => {
                            e.preventDefault();
                            setContactSubmitted(true);
                          }}
                          className="space-y-3 text-xs"
                        >
                          <div>
                            <label className="block text-gray-400 mb-1">Your Full Name</label>
                            <input 
                              type="text" 
                              required 
                              value={contactName}
                              onChange={e => setContactName(e.target.value)}
                              placeholder="e.g. Jane Doe"
                              className="w-full bg-white/4 border border-white/8 rounded-lg px-3 py-2 text-white focus:outline-none focus:border-purple-600"
                            />
                          </div>
                          <div>
                            <label className="block text-gray-400 mb-1">Your Email Coordinates</label>
                            <input 
                              type="email" 
                              required 
                              value={contactEmail}
                              onChange={e => setContactEmail(e.target.value)}
                              placeholder="e.g. jane@example.com"
                              className="w-full bg-white/4 border border-white/8 rounded-lg px-3 py-2 text-white focus:outline-none focus:border-purple-600"
                            />
                          </div>
                          <div>
                            <label className="block text-gray-400 mb-1">Subject Topic</label>
                            <input 
                              type="text" 
                              required 
                              value={contactSubject}
                              onChange={e => setContactSubject(e.target.value)}
                              placeholder="e.g. General Partnership Inquiry"
                              className="w-full bg-white/4 border border-white/8 rounded-lg px-3 py-2 text-white focus:outline-none focus:border-purple-600"
                            />
                          </div>
                          <div>
                            <label className="block text-gray-400 mb-1">Message Body</label>
                            <textarea 
                              rows={3}
                              required 
                              value={contactMessage}
                              onChange={e => setContactMessage(e.target.value)}
                              placeholder="Draft your query details here..."
                              className="w-full bg-white/4 border border-white/8 rounded-lg px-3 py-2 text-white focus:outline-none focus:border-purple-600"
                            />
                          </div>
                          <button 
                            type="submit" 
                            className="w-full bg-purple-600 hover:bg-purple-700 transition text-white font-bold py-2 rounded-lg cursor-pointer"
                          >
                            Submit Inquiry Form
                          </button>
                        </form>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* TAB: SUPPORT SECTION */}
            {activeTab === 'support' && (
              <div className="container mx-auto px-6 md:px-12 py-12 animate-fade-in max-w-4xl">
                <div className="bg-[#0a0a14]/65 border border-white/8 rounded-2xl p-8 md:p-10 space-y-6">
                  <div className="border-b border-white/10 pb-4">
                    <h1 className="text-3xl font-bold flex items-center gap-2">
                      <HelpCircle className="text-purple-400" />
                      <span>Support Desk &amp; Help Center</span>
                    </h1>
                    <p className="text-gray-400 text-xs mt-1">Resolve loading delays, player inquiries, or library synchronization requests.</p>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    {/* FAQ Items */}
                    <div className="md:col-span-2 space-y-4">
                      <h3 className="text-white font-bold text-base">Frequently Answered Queries</h3>
                      
                      <div className="space-y-3">
                        <div className="bg-white/4 border border-white/5 p-4 rounded-xl">
                          <h4 className="text-white font-bold text-xs">How do I stream the loaded episodes?</h4>
                          <p className="text-gray-400 text-xs mt-1 leading-relaxed">
                            Click any Drama card from the main dashboard, browse the episodes lists, and select your target episode. VIBEDRAMAHUB will construct the high-speed Streamtape frame overlay instantly.
                          </p>
                        </div>

                        <div className="bg-white/4 border border-white/5 p-4 rounded-xl">
                          <h4 className="text-white font-bold text-xs">Why is the streaming overlay blank?</h4>
                          <p className="text-gray-400 text-xs mt-1 leading-relaxed">
                            The Streamtape server node might be compiling or waiting for buffering pipelines. Try refreshing your browser tab or contact us if a node is offline for more than 1 hour.
                          </p>
                        </div>

                        <div className="bg-white/4 border border-white/5 p-4 rounded-xl">
                          <h4 className="text-white font-bold text-xs">Where is my custom watch progress stored?</h4>
                          <p className="text-gray-400 text-xs mt-1 leading-relaxed">
                            All watch logs, favorites list, and custom playlist schemas are stored securely in browser state and synced to our core database instances automatically.
                          </p>
                        </div>
                      </div>
                    </div>

                    {/* Direct Contact Support Card */}
                    <div className="md:col-span-1 space-y-4">
                      <div className="bg-white/3 border border-white/5 p-5 rounded-2xl space-y-4 shadow-xl">
                        <div className="flex items-center gap-2 pb-2 border-b border-white/5">
                          <Mail className="w-5 h-5 text-purple-400" />
                          <h4 className="text-white font-bold text-sm uppercase tracking-wide">Submit Help Ticket</h4>
                        </div>
                        
                        {contactSubmitted ? (
                          <div className="space-y-2 text-center py-4">
                            <div className="w-10 h-10 bg-emerald-500/10 border border-emerald-500/25 rounded-full flex items-center justify-center mx-auto text-emerald-400">
                              <Check className="w-5 h-5" />
                            </div>
                            <h5 className="font-semibold text-white text-xs">Ticket Registered</h5>
                            <p className="text-[11px] text-gray-400 leading-relaxed">
                              Our drama operations desk has locked in your query. We will email you at <strong className="text-white">{contactEmail || 'your email'}</strong> within 2 hours.
                            </p>
                            <button 
                              onClick={() => {
                                setContactSubmitted(false);
                                setContactMessage('');
                              }}
                              className="text-[10px] text-purple-400 hover:text-purple-300 font-medium underline mt-1"
                            >
                              Submit another inquiry
                            </button>
                          </div>
                        ) : (
                          <form 
                            onSubmit={(e) => {
                              e.preventDefault();
                              if (contactEmail && contactMessage) {
                                setContactSubmitted(true);
                              }
                            }}
                            className="space-y-3"
                          >
                            <div>
                              <label className="block text-[10px] text-gray-400 uppercase tracking-wider font-semibold mb-1">Your Name</label>
                              <input 
                                type="text"
                                required
                                value={contactName}
                                onChange={e => setContactName(e.target.value)}
                                placeholder="e.g. Sarah Lin"
                                className="w-full bg-white/5 border border-white/10 rounded-xl py-2 px-3 text-xs text-white placeholder-gray-500 focus:outline-none focus:border-purple-500 transition"
                              />
                            </div>
                            <div>
                              <label className="block text-[10px] text-gray-400 uppercase tracking-wider font-semibold mb-1">Email Address</label>
                              <input 
                                type="email"
                                required
                                value={contactEmail}
                                onChange={e => setContactEmail(e.target.value)}
                                placeholder="e.g. sarah@example.com"
                                className="w-full bg-white/5 border border-white/10 rounded-xl py-2 px-3 text-xs text-white placeholder-gray-500 focus:outline-none focus:border-purple-500 transition"
                              />
                            </div>
                            <div>
                              <label className="block text-[10px] text-gray-400 uppercase tracking-wider font-semibold mb-1">Inquiry / Issues</label>
                              <textarea 
                                required
                                value={contactMessage}
                                onChange={e => setContactMessage(e.target.value)}
                                rows={3}
                                placeholder="Describe any buffering issues or requests..."
                                className="w-full bg-white/5 border border-white/10 rounded-xl py-2 px-3 text-xs text-white placeholder-gray-500 focus:outline-none focus:border-purple-500 transition resize-none"
                              />
                            </div>
                            <button 
                              type="submit"
                              className="w-full bg-gradient-to-r from-purple-600 to-blue-600 hover:opacity-95 text-white font-semibold rounded-xl py-2 text-xs transition shadow-md cursor-pointer text-center block"
                            >
                              Transmit Message
                            </button>
                          </form>
                        )}
                      </div>
                      
                      {/* Supplementary Direct Email Card */}
                      <div className="bg-white/3 border border-white/5 p-4 rounded-xl space-y-2">
                        <h4 className="text-white font-bold text-[10px] uppercase tracking-wider text-purple-400">Direct Support Line</h4>
                        <p className="text-gray-400 text-[11px] leading-relaxed">
                          Prefer traditional email? Contact us anytime at: <strong className="text-white block mt-1 font-mono select-all">contact.cdramamagic@gmail.com</strong>
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}

          </div>

          {/* GLOBAL FOOTER DESIGN */}
          <footer className="bg-black border-t border-white/5 py-12 px-6 mt-16 relative z-10 text-xs text-[#9ea2c0]">
            <div className="container mx-auto max-w-6xl">
              <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8 text-left">
                <div className="space-y-3">
                  <span className="text-xl font-bold tracking-tighter bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent uppercase block">VIBEDRAMAHUB</span>
                  <p className="text-gray-500">Premium dark glassmorphism layout, high-speed Streamtape video overlays, and automatic database-backed watch tracking.</p>
                </div>
                <div>
                  <h4 className="font-bold text-white mb-3">Explore</h4>
                  <ul className="space-y-2">
                    <li><button onClick={() => { setActiveTab('home'); setSelectedGenre(''); setSelectedDrama(null); }} className="hover:text-white transition">Home Dashboard</button></li>
                    <li><button onClick={() => setActiveTab('playlists')} className="hover:text-white transition">Custom Playlists</button></li>
                    <li><button onClick={() => setActiveTab('mylist')} className="hover:text-white transition">Favorites Watchlist</button></li>
                  </ul>
                </div>
                <div>
                  <h4 className="font-bold text-white mb-3">Legal Guidelines</h4>
                  <ul className="space-y-2">
                    <li><button onClick={() => setActiveTab('copyright')} className="hover:text-white transition">Copyright &amp; DMCA</button></li>
                    <li><button onClick={() => setActiveTab('legal')} className="hover:text-white transition">Terms &amp; Privacy</button></li>
                    <li><button onClick={() => setActiveTab('brand')} className="hover:text-white transition">Brand Identity</button></li>
                    <li><button onClick={() => setActiveTab('support')} className="hover:text-white transition text-purple-400 font-semibold">Support Section</button></li>
                    <li><button onClick={() => setActiveTab('contact')} className="hover:text-white transition text-blue-400 font-semibold">Contact Page</button></li>
                  </ul>
                </div>
                <div>
                  <h4 className="font-bold text-white mb-3">Contact Desk</h4>
                  <p className="text-gray-500">Corporate Enquiries:</p>
                  <strong className="text-white block mb-2 select-all">contact.cdramamagic@gmail.com</strong>
                  <a 
                    href="mailto:contact.cdramamagic@gmail.com" 
                    className="inline-flex items-center gap-1.5 bg-gradient-to-r from-purple-600 to-blue-600 hover:opacity-90 transition text-white text-[11px] font-bold px-3 py-1.5 rounded-full mt-1"
                  >
                    <Mail className="w-3.5 h-3.5" />
                    <span>Contact Us</span>
                  </a>
                </div>
              </div>
              <hr className="border-white/5 my-6" />
              <div className="flex flex-col sm:flex-row justify-between items-center text-[11px] text-gray-500 gap-4">
                <div>&copy; 2026 VIBEDRAMAHUB. Premium Asian Drama Streaming Hub. All rights reserved.</div>
                <div className="flex items-center gap-4">
                  <button onClick={() => { setActiveTab('admin_login'); setAuthError(''); }} className="hover:text-white text-gray-500 transition font-mono uppercase tracking-widest text-[10px]">
                    Platform Admin Access Gate
                  </button>
                </div>
              </div>
            </div>
          </footer>

        </div>
      )}
        </>
      )}



      {/* Elegant Custom Toast Notification */}
      {toast && (
        <div className="fixed bottom-6 right-6 z-50 flex items-center gap-3 bg-[#0c0c1e]/90 border border-white/10 backdrop-blur-xl px-4 py-3 rounded-xl shadow-[0_0_20px_rgba(168,85,247,0.3)] animate-fade-in max-w-sm transition-all duration-300">
          <div className={`w-2 h-2 rounded-full shrink-0 ${
            toast.type === 'success' ? 'bg-emerald-500 shadow-[0_0_8px_rgba(16,185,129,0.6)]' :
            toast.type === 'error' ? 'bg-rose-500 shadow-[0_0_8px_rgba(244,63,94,0.6)]' :
            'bg-blue-500 shadow-[0_0_8px_rgba(59,130,246,0.6)]'
          }`} />
          <p className="text-xs font-medium text-gray-200">{toast.message}</p>
          <button onClick={() => setToast(null)} className="text-gray-500 hover:text-white transition ml-2 cursor-pointer">
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* Floating 👤 Draggable User Profile & Google Login Button with Glassmorphism Context Quick Menu */}
      <FloatingProfileButton
        currentUser={currentUser}
        onOpenProfile={(activeSettingsForm) => {
          setSelectedDrama(null);
          setSelectedEpisode(null);
          setActiveTab('profile');
          if (activeSettingsForm) {
            setEditFullName(currentUser?.fullname || '');
            setEditUsername(currentUser?.username || '');
            setEditBio(currentUser?.bio || '');
            setEditPhotoURL(currentUser?.photoURL || '');
            setIsEditingProfile(true);
          }
        }}
        onOpenTab={(tabName, subSection) => {
          setSelectedDrama(null);
          setSelectedEpisode(null);
          setActiveTab(tabName);
          if (subSection) {
            setProfileScrollAnchor(`profile-${subSection}-section`);
          }
        }}
        handleGoogleLogin={handleGoogleLogin}
        favoritesCount={allFavorites.filter(f => f.userId === (auth.currentUser ? auth.currentUser.uid : 'guest')).length}
        ratingsCount={ratings.filter(r => r.userId === (auth.currentUser ? auth.currentUser.uid : 'guest')).length}
        watchHistoryCount={watchHistory.length}
      />

    </div>
  );
}
