import { initializeApp } from 'firebase/app';
import { 
  initializeFirestore, 
  collection, 
  doc, 
  getDocs, 
  getDocFromServer,
  setDoc, 
  writeBatch,
  query,
  where,
  deleteDoc,
  addDoc
} from 'firebase/firestore';
import { 
  getAuth, 
  setPersistence,
  browserLocalPersistence,
  signInWithEmailAndPassword, 
  signOut, 
  onAuthStateChanged,
  createUserWithEmailAndPassword
} from 'firebase/auth';
import { getStorage } from 'firebase/storage';

// Import Firebase config dynamically
import firebaseConfigData from '../../firebase-applet-config.json';

const firebaseConfig = {
  apiKey: firebaseConfigData.apiKey,
  authDomain: firebaseConfigData.authDomain,
  projectId: firebaseConfigData.projectId,
  storageBucket: firebaseConfigData.storageBucket,
  messagingSenderId: firebaseConfigData.messagingSenderId,
  appId: firebaseConfigData.appId
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

// Initialize Firestore with custom settings (forcing long polling) and custom database ID if available
const db = firebaseConfigData.firestoreDatabaseId 
  ? initializeFirestore(app, { experimentalForceLongPolling: true }, firebaseConfigData.firestoreDatabaseId)
  : initializeFirestore(app, { experimentalForceLongPolling: true });

// Validate Connection to Firestore on startup as per critical constraint
async function testConnection() {
  try {
    await getDocFromServer(doc(db, 'test', 'connection'));
  } catch (error) {
    if (error instanceof Error && (error.message.includes('the client is offline') || error.message.includes('unavailable'))) {
      console.warn("Please check your Firebase configuration or network connection. Firestore is operating in offline mode.");
    } else {
      console.error("Firestore connection test failed:", error);
    }
  }
}
testConnection();

// Initialize Auth
const auth = getAuth(app);
setPersistence(auth, browserLocalPersistence).catch((err) => {
  console.error("Firebase Auth persistence setup failed:", err);
});

// Initialize Storage
const storage = getStorage(app);

export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  }
}

export function handleFirestoreError(error: any, operationType: OperationType, path: string | null) {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid || null,
      email: auth.currentUser?.email || null,
      emailVerified: auth.currentUser?.emailVerified || null,
      isAnonymous: auth.currentUser?.isAnonymous || null,
      tenantId: auth.currentUser?.tenantId || null,
      providerInfo: auth.currentUser?.providerData?.map(provider => ({
        providerId: provider.providerId,
        email: provider.email,
      })) || []
    },
    operationType,
    path
  };
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

// Seed Data
const initialDramas = [
  {
    id: 1,
    title: 'Hidden Love',
    description: "A beautiful story about a young girl who falls in love with her older brother's roommate, which develops into an endearing romance over several years of growth and support.",
    poster_url: 'https://images.unsplash.com/photo-1522075469751-3a6694fb2f61?q=80&w=600',
    banner_url: 'https://images.unsplash.com/photo-1517604931442-7e0c8ed2963c?q=80&w=1200',
    trailer_url: 'https://www.youtube.com/embed/9Z3f0vU_y2U',
    genre: 'Romance, Comedy',
    country: 'China',
    release_year: 2023,
    status: 'Completed',
    cast: 'Zhao Lusi, Chen Zheyuan, Victor Ma'
  },
  {
    id: 2,
    title: 'The King: Eternal Monarch',
    description: 'A modern-day Korean emperor passes through a mysterious portal and into a parallel world, where he encounters a feisty police detective to solve a historical conspiracy.',
    poster_url: 'https://images.unsplash.com/photo-1536440136628-849c177e76a1?q=80&w=600',
    banner_url: 'https://images.unsplash.com/photo-1535016120720-40c646be5580?q=80&w=1200',
    trailer_url: 'https://www.youtube.com/embed/g8fS3kpxhio',
    genre: 'Mystery, Romance, Action',
    country: 'South Korea',
    release_year: 2020,
    status: 'Completed',
    cast: 'Lee Min-ho, Kim Go-eun, Woo Do-hwan'
  },
  {
    id: 3,
    title: 'Sweet Home',
    description: 'As humans turn into savage monsters and wreak terror, one troubled teenager and his neighbors fight to survive and to hold on to their humanity.',
    poster_url: 'https://images.unsplash.com/photo-1618336753974-aae8e04506aa?q=80&w=600',
    banner_url: 'https://images.unsplash.com/photo-1509198397868-475647b2a1e5?q=80&w=1200',
    trailer_url: 'https://www.youtube.com/embed/4O6S839N4p4',
    genre: 'Action, Mystery',
    country: 'South Korea',
    release_year: 2020,
    status: 'Ongoing',
    cast: 'Song Kang, Lee Jin-wook, Lee Si-young'
  }
];

const initialEpisodes = [
  { id: 101, drama_id: 1, episode_number: 1, title: 'First Meeting', streamtape_url: 'https://streamtape.com/e/abc123first_ep' },
  { id: 102, drama_id: 1, episode_number: 2, title: 'The Growing Friendship', streamtape_url: 'https://streamtape.com/e/abc123second_ep' },
  { id: 103, drama_id: 1, episode_number: 3, title: 'The Silent Supporter', streamtape_url: 'https://streamtape.com/e/abc123third_ep' },
  { id: 201, drama_id: 2, episode_number: 1, title: 'A Parallel Universe', streamtape_url: 'https://streamtape.com/e/theking_ep1' },
  { id: 202, drama_id: 2, episode_number: 2, title: 'Meeting the Detective', streamtape_url: 'https://streamtape.com/e/theking_ep2' },
  { id: 301, drama_id: 3, episode_number: 1, title: 'The Green Home Monster', streamtape_url: 'https://streamtape.com/e/sweethome_ep1' }
];

const initialReviews = [
  { dramaId: 1, username: 'klove99', fullname: 'Sarah Lin', text: 'Absolutely adorable drama! The chemistry between the leads is incredible. Must watch for romance fans!', rating: 10, createdAt: '2026-07-08' },
  { dramaId: 2, username: 'mysteryguy', fullname: 'Alex Carter', text: 'Intriguing plot and parallel worlds. Lee Min-ho delivers an amazing performance.', rating: 9, createdAt: '2026-07-09' }
];

// Helper to seed Firestore if empty
export async function seedDatabaseIfEmpty() {
  try {
    const dramasSnap = await getDocs(collection(db, 'dramas'));
    if (dramasSnap.empty) {
      console.log('Seeding dramas into Firestore...');
      const batch = writeBatch(db);
      for (const drama of initialDramas) {
        const dramaDocRef = doc(db, 'dramas', String(drama.id));
        batch.set(dramaDocRef, drama);
      }
      await batch.commit();
    }

    const epsSnap = await getDocs(collection(db, 'episodes'));
    if (epsSnap.empty) {
      console.log('Seeding episodes into Firestore...');
      const batch = writeBatch(db);
      for (const ep of initialEpisodes) {
        const epDocRef = doc(db, 'episodes', String(ep.id));
        batch.set(epDocRef, ep);
      }
      await batch.commit();
    }

    const reviewsSnap = await getDocs(collection(db, 'reviews'));
    if (reviewsSnap.empty) {
      console.log('Seeding reviews into Firestore...');
      for (const review of initialReviews) {
        await addDoc(collection(db, 'reviews'), review);
      }
    }

    console.log('Firebase Seeding completed successfully!');
  } catch (error) {
    console.error('Error seeding Firebase:', error);
  }
}

export { db, auth, storage };
