import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence, useMotionValue } from 'motion/react';
import { 
  User, 
  LogOut, 
  Heart, 
  Star, 
  Play, 
  Settings, 
  History,
  Key
} from 'lucide-react';
import { auth } from '../lib/firebase';
import { signOut } from 'firebase/auth';

interface FloatingProfileButtonProps {
  currentUser: any;
  onOpenProfile: (activeSettingsForm?: boolean) => void;
  onOpenTab: (tabName: string, subSection?: string) => void;
  handleGoogleLogin: () => void;
  favoritesCount: number;
  ratingsCount: number;
  watchHistoryCount: number;
}

export const FloatingProfileButton: React.FC<FloatingProfileButtonProps> = ({
  currentUser,
  onOpenProfile,
  onOpenTab,
  handleGoogleLogin,
  favoritesCount,
  ratingsCount,
  watchHistoryCount
}) => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);
  const constraintsRef = useRef<HTMLDivElement>(null);

  // Initialize coordinates from Local Storage or default bottom-right position
  const initialPos = (() => {
    try {
      const saved = localStorage.getItem('vibe_floating_pos');
      if (saved) {
        const parsed = JSON.parse(saved);
        return {
          x: Math.max(10, Math.min(parsed.x, window.innerWidth - 180)),
          y: Math.max(10, Math.min(parsed.y, window.innerHeight - 80))
        };
      }
    } catch (e) {
      console.warn("localStorage is not available for FloatingProfileButton position:", e);
    }
    return { x: window.innerWidth - 180, y: window.innerHeight - 100 };
  })();

  const x = useMotionValue(initialPos.x);
  const y = useMotionValue(initialPos.y);

  // Handle window resizing to keep the button within bounds
  useEffect(() => {
    const handleResize = () => {
      const currentX = x.get();
      const currentY = y.get();
      const validX = Math.max(10, Math.min(currentX, window.innerWidth - 180));
      const validY = Math.max(10, Math.min(currentY, window.innerHeight - 80));
      x.set(validX);
      y.set(validY);
    };

    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, [x, y]);

  // Click outside menu listener to close it
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(event.target as Node)) {
        setIsMenuOpen(false);
      }
    };

    if (isMenuOpen) {
      document.addEventListener('mousedown', handleClickOutside);
    }
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, [isMenuOpen]);

  // Handle Drag Ending: Save position to Local Storage
  const handleDragEnd = () => {
    try {
      localStorage.setItem(
        'vibe_floating_pos', 
        JSON.stringify({ x: x.get(), y: y.get() })
      );
    } catch (e) {
      console.warn("localStorage setItem failed for FloatingProfileButton position:", e);
    }
  };

  // Right Click / Context Menu Handler
  const handleContextMenu = (e: React.MouseEvent) => {
    e.preventDefault();
    if (currentUser) {
      setIsMenuOpen(prev => !prev);
    }
  };

  // Mobile Long Press Timer
  const longPressTimer = useRef<any>(null);
  
  const handleTouchStart = () => {
    if (!currentUser) return;
    longPressTimer.current = setTimeout(() => {
      setIsMenuOpen(true);
    }, 600);
  };

  const handleTouchEnd = () => {
    if (longPressTimer.current) {
      clearTimeout(longPressTimer.current);
    }
  };

  const handleLogout = async () => {
    try {
      await signOut(auth);
      setIsMenuOpen(false);
    } catch (err) {
      console.error("Logout error:", err);
    }
  };

  const menuPositionClass = () => {
    const isUpperHalf = y.get() < window.innerHeight / 2;
    const isLeftHalf = x.get() < window.innerWidth / 2;

    const vertClass = isUpperHalf ? 'top-14' : 'bottom-14';
    const horizClass = isLeftHalf ? 'left-0' : 'right-0';

    return `${vertClass} ${horizClass}`;
  };

  return (
    <>
      {/* Full screen boundary reference covering the screen (pointer-events-none) */}
      <div 
        ref={constraintsRef} 
        id="draggable-boundaries"
        className="fixed inset-0 pointer-events-none z-[999]"
      >
        <motion.div
          drag
          dragConstraints={constraintsRef}
          dragElastic={0.05}
          dragMomentum={false}
          onDragEnd={handleDragEnd}
          style={{
            position: 'fixed',
            left: 0,
            top: 0,
            x,
            y,
            touchAction: 'none'
          }}
          className="pointer-events-auto select-none flex flex-col items-end gap-1.5"
          onContextMenu={handleContextMenu}
          onTouchStart={handleTouchStart}
          onTouchEnd={handleTouchEnd}
          onTouchMove={handleTouchEnd}
        >
          {/* Main Floating Pill Button */}
          <motion.div
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className={`flex items-center gap-2.5 p-1.5 pr-4 pl-1.5 rounded-full cursor-pointer transition-all duration-300 shadow-2xl backdrop-blur-xl border ${
              currentUser 
                ? 'bg-slate-950/85 border-purple-500/25 shadow-purple-950/20 hover:border-purple-500/40' 
                : 'bg-[#120822]/90 border-blue-500/25 shadow-blue-950/30 hover:border-blue-500/40 animate-pulse'
            }`}
            onClick={(e) => {
              if (isMenuOpen) {
                setIsMenuOpen(false);
              } else {
                if (currentUser) {
                  onOpenProfile();
                } else {
                  handleGoogleLogin();
                }
              }
            }}
          >
            {currentUser ? (
              <>
                {currentUser.photoURL ? (
                  <img 
                    src={currentUser.photoURL} 
                    alt="User" 
                    className="w-8 h-8 rounded-full object-cover border border-purple-500/45 shrink-0" 
                    referrerPolicy="no-referrer"
                  />
                ) : (
                  <div className="w-8 h-8 rounded-full bg-gradient-to-br from-purple-600 to-indigo-600 flex items-center justify-center text-xs font-bold text-white shrink-0 shadow-inner">
                    {currentUser.fullname ? currentUser.fullname[0].toUpperCase() : 'U'}
                  </div>
                )}
                <div className="flex flex-col text-left leading-none">
                  <span className="text-white text-xs font-semibold max-w-[85px] truncate block">
                    {currentUser.fullname}
                  </span>
                  <span className="text-[9px] text-purple-300 font-mono">
                    @{currentUser.username}
                  </span>
                </div>
              </>
            ) : (
              <>
                <div className="w-8 h-8 rounded-full bg-gradient-to-br from-blue-500 to-teal-500 flex items-center justify-center text-white shrink-0 shadow-inner shadow-teal-300/25">
                  <Key className="w-4 h-4 text-white" />
                </div>
                <div className="flex flex-col text-left leading-none pr-0.5">
                  <span className="text-white text-xs font-bold uppercase tracking-wider">
                    Sign In
                  </span>
                  <span className="text-[8px] text-teal-400 font-medium font-mono">
                    Google Sync
                  </span>
                </div>
              </>
            )}
          </motion.div>

          {/* Quick Right-Click/Long-Press Menu */}
          <AnimatePresence>
            {isMenuOpen && currentUser && (
              <motion.div
                ref={menuRef}
                initial={{ opacity: 0, scale: 0.9, y: 5 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.9, y: 5 }}
                transition={{ duration: 0.15, ease: 'easeOut' }}
                className={`absolute w-48 bg-[#0b0c15]/95 backdrop-blur-2xl border border-white/10 rounded-2xl p-2.5 shadow-2xl shadow-black/80 z-[1000] flex flex-col gap-1 ${menuPositionClass()}`}
              >
                <div className="px-2 py-1.5 border-b border-white/5 mb-1.5 flex flex-col">
                  <span className="text-[10px] text-purple-400 font-bold uppercase tracking-widest font-mono">Quick Control</span>
                  <span className="text-[9px] text-gray-500">Long press / Right click</span>
                </div>

                <button
                  onClick={() => {
                    onOpenProfile();
                    setIsMenuOpen(false);
                  }}
                  className="w-full text-left py-1.5 px-2.5 rounded-xl hover:bg-white/5 transition text-gray-300 hover:text-white text-xs flex items-center gap-2"
                >
                  <User className="w-3.5 h-3.5 text-blue-400" />
                  <span>My Profile</span>
                </button>

                <button
                  onClick={() => {
                    onOpenTab('profile', 'favorites');
                    setIsMenuOpen(false);
                  }}
                  className="w-full text-left py-1.5 px-2.5 rounded-xl hover:bg-white/5 transition text-gray-300 hover:text-white text-xs flex items-center justify-between"
                >
                  <div className="flex items-center gap-2">
                    <Heart className="w-3.5 h-3.5 text-red-500 fill-red-500/20" />
                    <span>Favorites</span>
                  </div>
                  <span className="text-[9px] bg-red-500/10 border border-red-500/20 text-red-400 px-1.5 py-0.2 rounded font-mono">
                    {favoritesCount}
                  </span>
                </button>

                <button
                  onClick={() => {
                    onOpenTab('profile', 'ratings');
                    setIsMenuOpen(false);
                  }}
                  className="w-full text-left py-1.5 px-2.5 rounded-xl hover:bg-white/5 transition text-gray-300 hover:text-white text-xs flex items-center justify-between"
                >
                  <div className="flex items-center gap-2">
                    <Star className="w-3.5 h-3.5 text-yellow-400 fill-yellow-400/20" />
                    <span>My Ratings</span>
                  </div>
                  <span className="text-[9px] bg-yellow-400/10 border border-yellow-400/20 text-yellow-400 px-1.5 py-0.2 rounded font-mono">
                    {ratingsCount}
                  </span>
                </button>

                <button
                  onClick={() => {
                    onOpenTab('home', 'continue-watching');
                    setIsMenuOpen(false);
                  }}
                  className="w-full text-left py-1.5 px-2.5 rounded-xl hover:bg-white/5 transition text-gray-300 hover:text-white text-xs flex items-center justify-between"
                >
                  <div className="flex items-center gap-2">
                    <Play className="w-3.5 h-3.5 text-green-400" />
                    <span>Continue Watching</span>
                  </div>
                  <span className="text-[9px] bg-green-400/10 border border-green-500/20 text-green-400 px-1.5 py-0.2 rounded font-mono">
                    {watchHistoryCount}
                  </span>
                </button>

                <button
                  onClick={() => {
                    onOpenProfile(true); // Open settings editor card
                    setIsMenuOpen(false);
                  }}
                  className="w-full text-left py-1.5 px-2.5 rounded-xl hover:bg-white/5 transition text-gray-300 hover:text-white text-xs flex items-center gap-2"
                >
                  <Settings className="w-3.5 h-3.5 text-slate-400" />
                  <span>Settings</span>
                </button>

                <div className="h-[1px] bg-white/5 my-1.5" />

                <button
                  onClick={handleLogout}
                  className="w-full text-left py-1.5 px-2.5 rounded-xl hover:bg-red-500/10 transition text-red-400 hover:text-red-300 text-xs flex items-center gap-2"
                >
                  <LogOut className="w-3.5 h-3.5" />
                  <span>Logout</span>
                </button>
              </motion.div>
            )}
          </AnimatePresence>
        </motion.div>
      </div>
    </>
  );
};
