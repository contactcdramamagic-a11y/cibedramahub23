import React, { useState, useEffect, useRef } from 'react';
import { 
  ref, 
  uploadBytesResumable, 
  getDownloadURL, 
  deleteObject, 
  listAll 
} from 'firebase/storage';
import { 
  collection, 
  addDoc, 
  getDocs, 
  deleteDoc, 
  doc, 
  query, 
  orderBy, 
  onSnapshot 
} from 'firebase/firestore';
import { storage, db } from '../lib/firebase';
import { 
  Upload, 
  File, 
  Image as ImageIcon, 
  Trash2, 
  Copy, 
  Check, 
  RefreshCw, 
  ExternalLink, 
  FileText, 
  Film, 
  Sparkles, 
  Cloud, 
  CheckCircle, 
  AlertCircle 
} from 'lucide-react';

interface FirebaseStorageManagerProps {
  onSelectPoster?: (url: string) => void;
  onSelectBanner?: (url: string) => void;
  showToast?: (message: string, type: 'success' | 'error' | 'info') => void;
}

interface UploadingFile {
  id: string;
  name: string;
  progress: number;
  status: 'uploading' | 'success' | 'error';
  error?: string;
}

interface StoredFile {
  id: string;
  name: string;
  url: string;
  size: string;
  type: string;
  uploadedAt: string;
}

export const FirebaseStorageManager: React.FC<FirebaseStorageManagerProps> = ({ 
  onSelectPoster, 
  onSelectBanner,
  showToast 
}) => {
  const [filesList, setFilesList] = useState<StoredFile[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [uploadingFiles, setUploadingFiles] = useState<UploadingFile[]>([]);
  const [dragActive, setDragActive] = useState<boolean>(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [syncing, setSyncing] = useState<boolean>(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Load files in real-time from Firestore database
  useEffect(() => {
    const q = query(collection(db, 'storage_files'), orderBy('uploadedAt', 'desc'));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const items: StoredFile[] = [];
      snapshot.forEach((doc) => {
        items.push({ id: doc.id, ...doc.data() } as StoredFile);
      });
      setFilesList(items);
      setLoading(false);
    }, (error) => {
      console.error("Error loading stored files:", error);
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  // Format file sizes helper
  const formatBytes = (bytes: number, decimals = 2) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const dm = decimals < 0 ? 0 : decimals;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
  };

  // Drag and drop event handlers
  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === 'dragenter' || e.type === 'dragover') {
      setDragActive(true);
    } else if (e.type === 'dragleave') {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);

    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFilesUpload(Array.from(e.dataTransfer.files));
    }
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      handleFilesUpload(Array.from(e.target.files));
    }
  };

  // Upload files to Firebase Storage and document in Firestore
  const handleFilesUpload = async (files: File[]) => {
    files.forEach((file) => {
      const uploadId = Math.random().toString(36).substring(2, 9);
      const newUpload: UploadingFile = {
        id: uploadId,
        name: file.name,
        progress: 0,
        status: 'uploading'
      };

      setUploadingFiles((prev) => [newUpload, ...prev]);

      // Create storage reference
      const storageRef = ref(storage, `uploads/${Date.now()}_${file.name}`);
      const uploadTask = uploadBytesResumable(storageRef, file);

      uploadTask.on(
        'state_changed',
        (snapshot) => {
          const progress = Math.round((snapshot.bytesTransferred / snapshot.totalBytes) * 100);
          setUploadingFiles((prev) =>
            prev.map((item) => (item.id === uploadId ? { ...item, progress } : item))
          );
        },
        (error) => {
          console.error("Upload failed:", error);
          setUploadingFiles((prev) =>
            prev.map((item) =>
              item.id === uploadId ? { ...item, status: 'error', error: error.message } : item
            )
          );
          if (showToast) showToast(`Failed to upload ${file.name}: ${error.message}`, 'error');
        },
        async () => {
          try {
            const downloadUrl = await getDownloadURL(uploadTask.snapshot.ref);

            // Document metadata in Firestore
            await addDoc(collection(db, 'storage_files'), {
              name: file.name,
              url: downloadUrl,
              size: formatBytes(file.size),
              type: file.type,
              uploadedAt: new Date().toISOString()
            });

            setUploadingFiles((prev) =>
              prev.map((item) => (item.id === uploadId ? { ...item, status: 'success', progress: 100 } : item))
            );

            // Auto remove success after a few seconds
            setTimeout(() => {
              setUploadingFiles((prev) => prev.filter((item) => item.id !== uploadId));
            }, 4000);

            if (showToast) showToast(`Successfully uploaded ${file.name}!`, 'success');
          } catch (err: any) {
            console.error("Error saving document:", err);
            setUploadingFiles((prev) =>
              prev.map((item) => (item.id === uploadId ? { ...item, status: 'error', error: err.message } : item))
            );
          }
        }
      );
    });
  };

  // Copy to clipboard utility
  const copyToClipboard = (text: string, fileId: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(fileId);
    if (showToast) showToast('URL copied to clipboard!', 'success');
    setTimeout(() => setCopiedId(null), 2000);
  };

  // Delete file from storage and database
  const handleDeleteFile = async (file: StoredFile) => {
    if (!window.confirm(`Are you sure you want to permanently delete "${file.name}"?`)) return;

    try {
      // 1. Delete from Firebase Storage if it's stored there
      // We try to decode the path from downloadURL or extract it safely
      try {
        const decodedUrl = decodeURIComponent(file.url);
        const match = decodedUrl.match(/\/o\/(.+?)\?/);
        if (match && match[1]) {
          const storagePath = match[1];
          const fileRef = ref(storage, storagePath);
          await deleteObject(fileRef);
        }
      } catch (err) {
        console.warn("Storage deletion warning (might be external link):", err);
      }

      // 2. Delete document from Firestore
      await deleteDoc(doc(db, 'storage_files', file.id));
      if (showToast) showToast('File deleted successfully!', 'success');
    } catch (err: any) {
      console.error("Error deleting file:", err);
      if (showToast) showToast(`Failed to delete file: ${err.message}`, 'error');
    }
  };

  // Scan & sync storage files directly from storage directory
  const handleScanAndSync = async () => {
    setSyncing(true);
    try {
      const listRef = ref(storage, 'uploads');
      const res = await listAll(listRef);
      
      let syncCount = 0;
      // Get currently documented URLs to avoid duplicates
      const currentUrls = new Set(filesList.map(f => f.url));

      for (const itemRef of res.items) {
        const url = await getDownloadURL(itemRef);
        if (!currentUrls.has(url)) {
          // Document it
          await addDoc(collection(db, 'storage_files'), {
            name: itemRef.name,
            url: url,
            size: 'Unknown (Synced)',
            type: 'image/jpeg', // Default fallback
            uploadedAt: new Date().toISOString()
          });
          syncCount++;
        }
      }

      if (showToast) {
        if (syncCount > 0) {
          showToast(`Synchronized ${syncCount} untracked storage files successfully!`, 'success');
        } else {
          showToast('Everything is already in sync!', 'info');
        }
      }
    } catch (err: any) {
      console.error("Sync error:", err);
      if (showToast) showToast(`Sync failed: ${err.message}`, 'error');
    } finally {
      setSyncing(false);
    }
  };

  // Determine Icon for file type
  const getFileIcon = (type: string) => {
    if (type.startsWith('image/')) return <ImageIcon className="w-6 h-6 text-pink-400" />;
    if (type.startsWith('video/')) return <Film className="w-6 h-6 text-purple-400" />;
    if (type.startsWith('text/')) return <FileText className="w-6 h-6 text-blue-400" />;
    return <File className="w-6 h-6 text-gray-400" />;
  };

  return (
    <div className="space-y-6">
      {/* Upload Section */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Upload Dropzone */}
        <div className="lg:col-span-2">
          <div
            onDragEnter={handleDrag}
            onDragOver={handleDrag}
            onDragLeave={handleDrag}
            onDrop={handleDrop}
            onClick={() => fileInputRef.current?.click()}
            className={`h-48 border-2 border-dashed rounded-2xl flex flex-col items-center justify-center p-6 text-center cursor-pointer transition-all duration-300 ${
              dragActive 
                ? 'border-purple-500 bg-purple-500/10 scale-[0.99] shadow-[0_0_20px_rgba(147,51,234,0.15)]' 
                : 'border-white/10 bg-[#07070f] hover:border-white/20 hover:bg-white/3'
            }`}
          >
            <input
              ref={fileInputRef}
              type="file"
              multiple
              accept="image/*,video/*"
              className="hidden"
              onChange={handleFileSelect}
            />
            <div className="p-4 bg-purple-600/10 rounded-full mb-3 text-purple-400 border border-purple-500/15">
              <Upload className="w-6 h-6 animate-bounce" />
            </div>
            <h3 className="font-semibold text-sm text-white">Drag & Drop Media Files here</h3>
            <p className="text-[10px] text-gray-400 mt-1 max-w-xs">
              Supports JPG, PNG, WEBP, GIF, and MP4. Files will be uploaded to your secure Google Cloud Storage bucket.
            </p>
          </div>
        </div>

        {/* Uploading Queue Status */}
        <div className="bg-[#07070f] border border-white/8 rounded-2xl p-4 flex flex-col justify-between h-48">
          <div className="overflow-y-auto max-h-36 space-y-3 scrollbar-thin">
            <h4 className="text-[10px] font-bold text-gray-400 uppercase tracking-wider flex items-center gap-1.5 mb-2">
              <Cloud className="w-3.5 h-3.5 text-blue-400" />
              <span>Current Upload Queue</span>
            </h4>
            
            {uploadingFiles.length === 0 ? (
              <div className="text-center py-6 text-xs text-gray-500 italic">
                No active uploads
              </div>
            ) : (
              uploadingFiles.map((file) => (
                <div key={file.id} className="text-xs space-y-1">
                  <div className="flex justify-between items-center gap-2">
                    <span className="text-white truncate max-w-[150px] font-mono text-[10px]">{file.name}</span>
                    <span className={`text-[10px] font-bold ${
                      file.status === 'success' ? 'text-green-400' : file.status === 'error' ? 'text-red-400' : 'text-purple-400'
                    }`}>
                      {file.status === 'success' && <CheckCircle className="w-3.5 h-3.5 inline mr-1" />}
                      {file.status === 'error' && <AlertCircle className="w-3.5 h-3.5 inline mr-1" />}
                      {file.status === 'uploading' ? `${file.progress}%` : file.status.toUpperCase()}
                    </span>
                  </div>
                  <div className="w-full bg-white/5 rounded-full h-1.5 overflow-hidden">
                    <div 
                      className={`h-full transition-all duration-300 ${
                        file.status === 'success' ? 'bg-green-500' : file.status === 'error' ? 'bg-red-500' : 'bg-gradient-to-r from-purple-500 to-pink-500'
                      }`}
                      style={{ width: `${file.progress}%` }}
                    />
                  </div>
                </div>
              ))
            )}
          </div>
          <div className="border-t border-white/5 pt-2 flex justify-between items-center text-[9px] text-gray-400">
            <span>Powered by Firebase Storage</span>
            <button 
              onClick={handleScanAndSync}
              disabled={syncing}
              className="text-purple-400 hover:text-purple-300 flex items-center gap-1 cursor-pointer transition disabled:opacity-50"
            >
              <RefreshCw className={`w-3 h-3 ${syncing ? 'animate-spin' : ''}`} />
              <span>Scan bucket</span>
            </button>
          </div>
        </div>

      </div>

      {/* Media Catalog List */}
      <div className="space-y-4">
        <div className="flex justify-between items-center">
          <h2 className="text-sm font-bold uppercase tracking-wider text-white flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-pink-500 animate-pulse" />
            <span>Storage Cloud Library ({filesList.length} files)</span>
          </h2>
        </div>

        {loading ? (
          <div className="flex flex-col items-center justify-center py-20 gap-3">
            <RefreshCw className="w-8 h-8 text-purple-500 animate-spin" />
            <span className="text-xs text-gray-400">Loading your cloud storage index...</span>
          </div>
        ) : filesList.length === 0 ? (
          <div className="border border-white/5 bg-[#07070f] rounded-2xl py-16 text-center">
            <ImageIcon className="w-12 h-12 text-gray-600 mx-auto mb-3" />
            <h3 className="font-semibold text-white text-sm">No uploaded media found</h3>
            <p className="text-xs text-gray-500 max-w-sm mx-auto mt-1">
              Drag-and-drop your images above to populate your private Firebase Storage container.
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
            {filesList.map((file) => (
              <div 
                key={file.id} 
                className="group relative bg-[#070710]/80 border border-white/5 hover:border-purple-500/30 rounded-xl overflow-hidden transition-all duration-300 flex flex-col h-full"
              >
                {/* Media Preview Stage */}
                <div className="aspect-video w-full bg-black/40 relative flex items-center justify-center overflow-hidden border-b border-white/5">
                  {file.type.startsWith('image/') ? (
                    <img 
                      src={file.url} 
                      alt={file.name} 
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                      referrerPolicy="no-referrer"
                    />
                  ) : (
                    getFileIcon(file.type)
                  )}
                  <div className="absolute top-2 right-2 bg-black/60 px-2 py-0.5 rounded text-[8px] font-mono text-gray-400">
                    {file.size}
                  </div>
                </div>

                {/* Details pane */}
                <div className="p-3 flex-1 flex flex-col justify-between space-y-3">
                  <div>
                    <h4 className="font-mono text-[10px] text-white font-medium truncate" title={file.name}>
                      {file.name}
                    </h4>
                    <p className="text-[9px] text-gray-400 mt-0.5">
                      Uploaded {new Date(file.uploadedAt).toLocaleDateString()}
                    </p>
                  </div>

                  {/* Actions Grid */}
                  <div className="space-y-1.5">
                    {/* Copy URL */}
                    <button 
                      onClick={() => copyToClipboard(file.url, file.id)}
                      className="w-full bg-white/5 border border-white/8 hover:bg-white/10 text-white text-[9px] font-bold py-1.5 rounded-lg flex items-center justify-center gap-1 transition cursor-pointer"
                    >
                      {copiedId === file.id ? (
                        <>
                          <Check className="w-3 h-3 text-green-400" />
                          <span>Copied URL!</span>
                        </>
                      ) : (
                        <>
                          <Copy className="w-3 h-3 text-purple-400" />
                          <span>Copy public link</span>
                        </>
                      )}
                    </button>

                    {/* Quick selection bindings */}
                    {(onSelectPoster || onSelectBanner) && (
                      <div className="grid grid-cols-2 gap-1.5">
                        {onSelectPoster && (
                          <button
                            onClick={() => {
                              onSelectPoster(file.url);
                              if (showToast) showToast('Set as Poster URL!', 'info');
                            }}
                            className="bg-purple-600/15 border border-purple-600/20 hover:bg-purple-600/30 text-purple-300 text-[9px] font-bold py-1 rounded-lg transition cursor-pointer"
                          >
                            Set Poster
                          </button>
                        )}
                        {onSelectBanner && (
                          <button
                            onClick={() => {
                              onSelectBanner(file.url);
                              if (showToast) showToast('Set as Banner URL!', 'info');
                            }}
                            className="bg-pink-600/15 border border-pink-600/20 hover:bg-pink-600/30 text-pink-300 text-[9px] font-bold py-1 rounded-lg transition cursor-pointer"
                          >
                            Set Banner
                          </button>
                        )}
                      </div>
                    )}

                    {/* Delete asset */}
                    <button 
                      onClick={() => handleDeleteFile(file)}
                      className="w-full bg-red-500/10 border border-red-500/20 hover:bg-red-500/25 text-red-400 text-[9px] font-bold py-1 rounded-lg flex items-center justify-center gap-1 transition cursor-pointer"
                    >
                      <Trash2 className="w-3 h-3" />
                      <span>Delete permanently</span>
                    </button>
                  </div>
                </div>

              </div>
            ))}
          </div>
        )}
      </div>

    </div>
  );
};
