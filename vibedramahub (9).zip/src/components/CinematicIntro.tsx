import React, { useEffect, useRef, useState } from 'react';
import { SkipForward } from 'lucide-react';

interface CinematicIntroProps {
  onComplete: () => void;
}

export const CinematicIntro: React.FC<CinematicIntroProps> = ({ onComplete }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [isExiting, setIsExiting] = useState(false);
  const [showSkip, setShowSkip] = useState(false);

  useEffect(() => {
    // Show skip button after a short delay (1 second) to maintain immersion first
    const timer = setTimeout(() => {
      setShowSkip(true);
    }, 1000);

    // Auto-complete the intro after 4.5 seconds
    const endTimer = setTimeout(() => {
      handleExit();
    }, 4500);

    return () => {
      clearTimeout(timer);
      clearTimeout(endTimer);
    };
  }, []);

  const handleExit = () => {
    setIsExiting(true);
    setTimeout(() => {
      onComplete();
    }, 600); // Allow time for CSS fade-out animation to finish
  };

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationId: number;
    let width = (canvas.width = window.innerWidth);
    let height = (canvas.height = window.innerHeight);

    // Handle Resize
    const handleResize = () => {
      if (!canvas) return;
      width = canvas.width = window.innerWidth;
      height = canvas.height = window.innerHeight;
    };
    window.addEventListener('resize', handleResize);

    // Particles/Dust system
    const particleCount = 45;
    const particles: Array<{
      x: number;
      y: number;
      radius: number;
      color: string;
      speedY: number;
      speedX: number;
      opacity: number;
      fadeSpeed: number;
      isFadingIn: boolean;
    }> = [];

    const createParticle = (initBottom = false) => {
      const isPurple = Math.random() > 0.5;
      return {
        x: Math.random() * width,
        y: initBottom ? height + Math.random() * 20 : Math.random() * height,
        radius: Math.random() * 2.5 + 0.8,
        color: isPurple ? '168, 85, 247' : '59, 130, 246', // Purple-500, Blue-500
        speedY: -(Math.random() * 0.4 + 0.1),
        speedX: (Math.random() - 0.5) * 0.2,
        opacity: initBottom ? 0 : Math.random() * 0.5,
        fadeSpeed: Math.random() * 0.008 + 0.003,
        isFadingIn: initBottom,
      };
    };

    // Initialize particles
    for (let i = 0; i < particleCount; i++) {
      particles.push(createParticle(false));
    }

    // Sweeping beam targets
    let startTime = Date.now();

    // Render loop
    const render = () => {
      const elapsed = Date.now() - startTime;
      
      // Black background
      ctx.fillStyle = '#000000';
      ctx.fillRect(0, 0, width, height);

      // Create sweeping ambient light beams using Radial Gradients
      // Beam 1: Purple sweeping diagonally from bottom-left to top-right
      const purpleBeamX = width * 0.2 + Math.sin(elapsed * 0.001) * (width * 0.2);
      const purpleBeamY = height * 0.8 - Math.cos(elapsed * 0.0008) * (height * 0.3);
      const purpleBeamRadius = Math.min(width, height) * 0.55;

      const purpleGrad = ctx.createRadialGradient(
        purpleBeamX,
        purpleBeamY,
        0,
        purpleBeamX,
        purpleBeamY,
        purpleBeamRadius
      );
      purpleGrad.addColorStop(0, 'rgba(147, 51, 234, 0.16)');
      purpleGrad.addColorStop(0.5, 'rgba(147, 51, 234, 0.05)');
      purpleGrad.addColorStop(1, 'rgba(0, 0, 0, 0)');

      ctx.fillStyle = purpleGrad;
      ctx.fillRect(0, 0, width, height);

      // Beam 2: Blue sweeping diagonally from right to left
      const blueBeamX = width * 0.8 - Math.sin(elapsed * 0.0009) * (width * 0.2);
      const blueBeamY = height * 0.2 + Math.cos(elapsed * 0.0012) * (height * 0.3);
      const blueBeamRadius = Math.min(width, height) * 0.6;

      const blueGrad = ctx.createRadialGradient(
        blueBeamX,
        blueBeamY,
        0,
        blueBeamX,
        blueBeamY,
        blueBeamRadius
      );
      blueGrad.addColorStop(0, 'rgba(59, 130, 246, 0.14)');
      blueGrad.addColorStop(0.5, 'rgba(59, 130, 246, 0.04)');
      blueGrad.addColorStop(1, 'rgba(0, 0, 0, 0)');

      ctx.fillStyle = blueGrad;
      ctx.fillRect(0, 0, width, height);

      // Center flash / lens glow flare
      if (elapsed > 2000) {
        // Slow center lens glow build-up
        const flashIntensity = Math.min(0.2, (elapsed - 2000) / 2000) * (1 + Math.sin(elapsed * 0.01) * 0.05);
        const centerGrad = ctx.createRadialGradient(
          width / 2,
          height / 2,
          0,
          width / 2,
          height / 2,
          Math.min(width, height) * 0.4
        );
        centerGrad.addColorStop(0, `rgba(168, 85, 247, ${flashIntensity})`);
        centerGrad.addColorStop(0.3, `rgba(59, 130, 246, ${flashIntensity * 0.5})`);
        centerGrad.addColorStop(1, 'rgba(0,0,0,0)');
        ctx.fillStyle = centerGrad;
        ctx.fillRect(0, 0, width, height);
      }

      // Draw and update particles
      particles.forEach((p, index) => {
        // Draw
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.radius, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(${p.color}, ${p.opacity})`;
        ctx.shadowBlur = 10;
        ctx.shadowColor = `rgba(${p.color}, ${p.opacity * 0.6})`;
        ctx.fill();
        ctx.shadowBlur = 0; // reset shadow for performance

        // Move
        p.y += p.speedY;
        p.x += p.speedX;

        // Fade logic
        if (p.isFadingIn) {
          p.opacity += p.fadeSpeed;
          if (p.opacity >= 0.6) {
            p.opacity = 0.6;
            p.isFadingIn = false;
          }
        } else {
          // Slowly fade out as it climbs
          p.opacity -= p.fadeSpeed * 0.4;
        }

        // Replace if out of bounds or completely faded
        if (p.y < -10 || p.opacity <= 0 || p.x < -10 || p.x > width + 10) {
          particles[index] = createParticle(true);
        }
      });

      animationId = requestAnimationFrame(render);
    };

    render();

    return () => {
      cancelAnimationFrame(animationId);
      window.removeEventListener('resize', handleResize);
    };
  }, []);

  return (
    <div 
      className={`fixed inset-0 z-[9999] bg-[#000000] flex flex-col items-center justify-center select-none overflow-hidden transition-all duration-[600ms] ease-out ${
        isExiting ? 'opacity-0 scale-105 pointer-events-none' : 'opacity-100 scale-100'
      }`}
    >
      {/* Background Cinematic Canvas */}
      <canvas ref={canvasRef} className="absolute inset-0 w-full h-full pointer-events-none" />

      {/* Subtle cinematic sweeping flare lines (overlay) */}
      <div className="absolute inset-0 pointer-events-none flex items-center justify-center opacity-40">
        <div className="w-[150%] h-[1px] bg-gradient-to-r from-transparent via-purple-500 to-transparent rotate-[-15deg] blur-[2px] animate-pulse-slow" />
        <div className="w-[150%] h-[1px] bg-gradient-to-r from-transparent via-blue-500 to-transparent rotate-[10deg] blur-[3px] animate-pulse-slow opacity-60" />
      </div>

      {/* Main Cinematic Logo Container */}
      <div className="text-center relative z-10 max-w-lg px-6 flex flex-col items-center justify-center">
        {/* Animated ambient backdrop halo glow */}
        <div className="absolute w-64 h-64 bg-purple-600/10 rounded-full filter blur-[100px] animate-pulse-slow" />
        
        <h1 
          className="text-4xl md:text-6xl font-black tracking-widest bg-gradient-to-r from-purple-400 via-white to-blue-400 bg-clip-text text-transparent uppercase font-sans animate-logo-entrance select-none"
          style={{
            filter: 'drop-shadow(0 0 20px rgba(168, 85, 247, 0.45)) drop-shadow(0 0 45px rgba(59, 130, 246, 0.3))'
          }}
        >
          VIBEDRAMAHUB
        </h1>
        
        <p className="text-[#9ea2c0]/65 text-[10px] md:text-xs font-mono tracking-[0.4em] uppercase mt-4 opacity-0 animate-fade-in-delayed select-none">
          Streaming Redefined
        </p>
      </div>

      {/* Skip Intro Button */}
      {showSkip && (
        <button
          onClick={handleExit}
          className="absolute top-6 right-6 z-20 flex items-center gap-1.5 bg-black/40 border border-white/10 backdrop-blur-md px-4 py-2 rounded-full text-xs font-semibold text-gray-300 hover:text-white hover:bg-white/10 hover:border-white/20 transition-all cursor-pointer select-none shadow-lg animate-fade-in"
        >
          <span>Skip Intro</span>
          <SkipForward className="w-3.5 h-3.5" />
        </button>
      )}
    </div>
  );
};
